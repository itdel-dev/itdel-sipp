function buatHalamanAdmin(pos, gBuku, gKaset, gPengguna,artikel, gPeminjaman, gPemesanan, histPeminjaman){
        var tengah = new Ext.Panel({
            title: 'Layar Administrasi',
            region: 'center',
            html: 'Center',
            collapsible: true,
            split: true,
            layout: 'fit',
            width: 765,
            items:[
                new Ext.TabPanel({
                    activeTab: 0,
                    id: 'panelTengah',
                    items:[{items: gPemesanan, title: 'Pemesanan Bahan Pustaka'}, {items: gPeminjaman, title: 'Peminjaman Bahan Pustaka'}, {items: gBuku, title: 'Buku'},{items: gKaset, title: 'CD/DVD'},{items: gPengguna, title: 'Pengguna'}, {items:histPeminjaman, title: 'Sejarah Peminjaman'}, {title: 'Artikel', id: 'panel-artikel', preventBodyReset: true}]
                })
            ]
        });
		//button yang digunakan untuk panel tambah data baru
                var btTambahPeminjaman = new Ext.Button({minWidth:300, height:50,text:'Tambah Peminjaman'});
                btTambahPeminjaman.on('click',function(){
                    var form = showPinjamLangsung(baseUrl + 'transaksi/pinjam_langsung');
                    form.show();
                });
		var btAddArticle = new Ext.Button({minWidth:300, height:50,text:'Tambah Artikel'});
		btAddArticle.on('click',function(){
                    var form = showAddArticle(baseUrl + 'artikel/tambah_artikel/'+Cookies.get('id'));
                    //var form = showAddArticle(baseUrl + 'debug/tambah/');
                    form.show();
		});
		var btAddUser = new Ext.Button({minWidth:300, height:50 ,text:'Tambah Pengguna'});
		btAddUser.on('click',function(){
                    var form = showAddUser(baseUrl + 'pengguna/tambah_pengguna_biasa');
                    form.show();
		});
		var btAddAdmin = new Ext.Button({minWidth:300, height:50 ,text:'Tambah Admin'});
		btAddAdmin.on('click',function(){
                    //Ext.Msg.alert('test');
                    var form = showAddAdmin(baseUrl + 'pengguna/tambah_admin');
                    form.show();
		});
		var btAddBook = new Ext.Button({minWidth:300, height:50 ,text:'Tambah Buku'});
		btAddBook.on('click',function(){
                    var form = showAddBook(baseUrl + 'buku/tambah_buku');
                    //var form = showAddBook(baseUrl + 'debug/tambah');
                    //alert(baseUrl + 'buku/tambah_buku');
                    form.show();
		});
		var btAddCD = new Ext.Button({minWidth:300, height:50 ,text:'Tambah CD/DVD'});
		btAddCD.on('click',function(){
                    //var form = showAddCD('');
                    var form = showAddCD(baseUrl+'kaset/tambah');
                    form.show();
		});
		var paneTambahBaru = new Ext.Panel({title: 'Tambah Data Baru',items:[btTambahPeminjaman,btAddArticle,btAddUser,btAddAdmin,btAddBook,btAddCD]});
		//Tangani penekanan untuk setiap tombol
                artikel.items.each(function(item, nomor){
                item.on('click', function(){
                    Ext.getCmp('panelTengah').setActiveTab(6);
                    Ext.getCmp('panel-artikel').setTitle('Artikel: ' + item.getText());
                    idArtikel = nomor+1;
                    idArtikel = item.getId();
                    Ext.getCmp('panel-artikel').getEl().load({url: baseUrl + 'artikel/ambil/'+idArtikel, method: 'get'});
                });
            });
        //informasi akun
        var paneInfoPengguna = buatInformasiAkun();
        //daftarkan tombol info pinjam dan info pesan
        setAksiTombolAkun('tombol-info-pinjam', 'pengguna/ambil_daftar_pinjam/' + Cookies.get('id'), 'Peminjaman Bahan Pustaka');
        setAksiTombolAkun('tombol-info-pesan', 'pengguna/ambil_daftar_pesan/' + Cookies.get('id') + '/1', 'Pemesanan Bahan Pustaka');
        setAksiTombolAkun('tombol-info-pesan-cepat', 'pengguna/ambil_daftar_pesan/' + Cookies.get('id') + '/4', 'Pemesanan yang belum diambil');
        var kiri = new Ext.Panel({
            title: 'Fungsi Admin',
            region: 'west',
            layout: 'accordion',
            collapsible: true,
            split: true,
            width: '30%',
            items:[paneInfoPengguna, paneTambahBaru, artikel]
        });
        /*
         * Buat tombol navigasi dan daftarkan event untuk untuk setiap tombol navigasi sesuai dengan kegunaan.
         * Event yang diterima setiap tombol adalah event 'click'
         */
        //tombol home untuk kembali ke home
        var btHome = buatLinkButton('Beranda', baseUrl + 'lib/admin');
        //Link menuju web akademik
        var btAka =  buatLinkButton('Web Akademik', 'http://akademik.del.ac.id');
        //Link menuju web mail
        var btMail = buatLinkButton('Web Mail', 'http://mail.del.ac.id');
        //Link menuju Web PI Del
        var btPidel = buatLinkButton('Web PI Del', 'http://www.pidel.org');
        //Link menuju Web Students
        var btStudent = buatLinkButton('Web Student', 'http://students.del.ac.id');
        var btTentangPerpus = buatLinkTtgPerpus();
        //tombol Links terdiri dari beberapa tombol navigasi untuk pindah ke web lain
        var btLinks = new Ext.Button({minWidth:100, text:'Web Links', menu:[btAka,btMail, btPidel, btStudent]});
	//var btLogOut = new Ext.Button({minWidth:100, text:'Log Out'});
        var btGantiPass = new Ext.Button({minWidth:100, text: 'Ganti Password', hidden: false, id: 'ganti-pass', handler:function(){showChangePassForm(baseUrl + 'pengguna/ganti_pass')}});
        var btLogOut = new Ext.Button({minWidth:100, text:'Keluar', id: 'keluar', handler:function(){
            //pengguna akan logout
            var id = Cookies.get('id');
            Cookies.set('pengguna', null);
            var logoutPath = baseUrl + 'pengguna/logout/';
            ajaxReqParams(logoutPath,function(){showWeb(baseUrl)},function(res){alert(res.responseText);},{id: id});}
        });
        var tb = new Ext.Toolbar({
            items:[btHome,'-', btLinks,'-', btTentangPerpus, '-', btGantiPass, '-', btLogOut]
        });
        var atas = new Ext.Panel({
            title: 'Link navigasi',
            region: 'north',
            collapsible: true,
            split: true,
            layout: 'fit',
            tbar: tb
        });
        var viewport = new Ext.Panel({
            layout: 'border',
            renderTo: pos,
            width: 1050,
            height: 710,
            items:[tengah, kiri, atas]
        });

        return viewport;
    }