function buatGridPeminjaman(path, ps){
    var data = buatStore('data', 'jumlah', ['ID_Referensi_Kategori','ID_Pengguna','Rencana_Kembali', 'Jenis_Kategori', 'id_bar', 'Nama'], path, true);
    data.setDefaultSort('Tgl_Transaksi');
    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header: 'Rencana Kembali', dataIndex: 'Rencana_Kembali'},
                {header:'Kategori', dataIndex: 'Jenis_Kategori'},
                {header: 'ID Barang', dataIndex: 'id_bar'},
                {header: 'Peminjam', dataIndex: 'Nama'},
                {header: 'ID Kategori', dataIndex: 'ID_Referensi_Kategori', hidden: true},
                {header: 'ID Peminjam', dataIndex: 'ID_Pengguna', hidden: true}]
    });

    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['Nama', 'Peminjam'], ['Rencana_Kembali', 'Kembali'], ['Kategori', 'Kategori'], ['id_bar', 'ID Barang']]
        });
    var tb = buatToolbar('Peminjaman', 'ID Barang', data, store, ps);

    var grid = buatGrid('panel-grid-peminjaman-admin', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
        var record = grid.getStore().getAt(rowIndex);  // Get the Record
        tampilWindowKembali(record.get('ID_Pengguna'), record.get('ID_Referensi_Kategori'), record.get('id_bar'));
    });
    data.load({start:0});
    return grid;
}