Ext.QuickTips.init();

function showAddUser(path){
    var textNI = new Ext.form.TextField({
        fieldLabel : 'Nomor Induk',
        name : 'induk',
        id: 'indukID',
        width : 100
    });
    var textNama = new Ext.form.TextField({
        fieldLabel : 'Nama',
        name : 'nama'
    });
    var textEmail = new Ext.form.TextField({
        fieldLabel: 'Email',
        name: 'email',
        id: 'emailID',
        width:200
    });
    var textNoHP= new Ext.form.TextField({
        fieldLabel : 'No. HP',
        name : 'nohp'
    });
    var textAlamat = new Ext.form.TextArea({
        fieldLabel:'Alamat',
        name : 'alamat',
        height : 50,
        width : 200
    });
    var textBatasBuku = new Ext.form.TextField({
        fieldLabel: 'Batas Buku',
        name: 'jumlahbuku',
        id:'jlhID',
        width:50
    });
    var doSubmit = function (){
        //alert('clicked');
        Ext.getCmp('addUser-form').getForm().submit({
           success:function(form, action){
                Ext.example.msg('Sukses','User Berhasil di tambah');
				Ext.getCmp('addUser-form').getForm().reset();
				Ext.getCmp('window-tambah-user').destroy();
            },
            failure:function(form, action){
                Ext.example.msg('Gagal',action.result.msg);
                if(action.result.error == 1){
                    Ext.getCmp('indukID').setValue('');
                    Ext.getCmp('indukID').focus(true);
                }else if(action.result.error == 3){
                    Ext.getCmp('emailID').focus(true);
                }else if (action.result.error == 4){
                    Ext.getCmp('jlhID').focus(true);
                }else if (action.result.error ==2){
                    Ext.getCmp('indukID').focus(true);
                } else {
                    Ext.getCmp('window-tambah-user').destroy();
                }
                
            }
        });
    }
    var formAddNewUser = new Ext.FormPanel({
        frame: true,
        url:path,
        id: 'addUser-form',
        labelAlign: 'left',
        labelWidth: 100,
        width:350,
        waitMsgTarget: true,
        items: [
            new Ext.form.FieldSet({
            autoHeight: true,
            defaultType: 'textfield',
            items: [textNI,textNama,textEmail,textAlamat,textNoHP,textBatasBuku],
                buttons: [{
                    text:'Ok',
                    handler: doSubmit
                },{
                    text: 'Cancel',
                    handler: function(){
                        winAddNewUser.destroy();
                    }
                }]
             })]
    });

    var winAddNewUser = new Ext.Window({
        title: 'Tambah User Baru',
        id:'window-tambah-user',
        layout:'vbox',
        width:365,
        height:295,
        resizable :false,
        closeAction:'hide',
        plain: true,
        modal: true,
        items: [formAddNewUser]
    });
    return winAddNewUser;
}