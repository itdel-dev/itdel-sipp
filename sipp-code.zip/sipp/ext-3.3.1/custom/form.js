function buatText(label, nama, id, w){
    var text = new Ext.form.TextField({
        fieldLabel : label,
        name : nama,
        id: id,
        width : w
    });
    return text;
}
function buatFormPengguna(){
    var textNI = buatText('Nomor Induk', 'induk', 'indukID', 100);
    var textNama = buatText('Nama', 'nama', null, null);
    var textEmail = buatText('Email', 'email', 'emailID', 200);
    var textNoHP= buatText('No. HP', 'nohp');
    var textAlamat = new Ext.form.TextArea({
        fieldLabel:'Alamat',
        name : 'alamat',
        height : 50,
        width : 200
    });
    var textBatasBuku = buatText('Batas Buku', 'jumlahbuku', 'jlhBuku', 50);
    var formAddNewUser = new Ext.form.FormPanel({
        frame: true,
        id: 'addUser-form',
        labelAlign: 'left',
        labelWidth: 100,
        width:350,
        height: 450,
        autoScroll: true,
        waitMsgTarget: true,
        items: [textNI,textNama,textEmail,textAlamat,textNoHP,textBatasBuku]
    });
    var win = buatPopUp('fit', 'Form Rubah Pengguna', true, formAddNewUser, null);
    return win;
}