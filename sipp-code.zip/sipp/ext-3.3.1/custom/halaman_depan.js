
function rubahNotifikasi(opr, total){
    var text;
    var span;

    text = total + " Pesanan yang disetujui";
    span = (total > 0 ? "<span style='font-weight: bold'>" + text + '</span>' : text);
    Ext.getCmp('tombol-notifikasi').setText(span);   
}
function bersihkanKomponen(){
    Ext.getCmp('submit').setText('Masuk');
    Ext.getCmp('info-pengguna').hide();
    Cookies.set('pengguna', null);
    Cookies.set('id', null);
    hancurkanWindowInfo();
    Ext.getCmp('ganti-pass').hide();
    selesaiUpdate();
    Ext.getCmp('panel-notifikasi').hide();
    Ext.getCmp('tombol-notifikasi').hide();
    Ext.getCmp('bt-pengembalian').hide();
    Ext.getCmp('bt-pemberitahuan').setText("Pemberitahuan");
}
function loadIsiPanel(no, text, path, cara){
    Ext.getCmp('panelTengah').setActiveTab(no);
    Ext.getCmp('panelTengah').getItem(no).setTitle(text);
    Ext.getCmp('panelTengah').getItem(no).getEl().load({url: path, method: cara});
}
function mulaiUpdate(){
    
    var mgrPath = baseUrl + 'notifikasi/lihat_notifikasi/' + Cookies.get('id');
    var update = function(){
        var suc = function(res){
            var obj = Ext.decode(res.responseText);
            var text = '';
            var i = 0;
            for (i=0; i<obj.jumlah; i++){
                text += '<li>' + obj.notifikasi[i].kategori + ' dengan id ' + obj.notifikasi[i].id_kat +' yang ' + Cookies.get('nama_pengguna') + ' pesan telah tersedia' + '</li><hr>';
            }
            Ext.getCmp('panel-notifikasi').body.dom.innerHTML = text;
            rubahNotifikasi(true, cast_angka(obj.jumlah));
        }
        var fail = function(res){
            Ext.example.msg('Notifikasi', res.responseText);
        }
        ajaxReq(mgrPath, suc, fail);
    }
        Ext.TaskMgr.start({
            run: update,
            interval: 10000
        });
}
function showPengembalian(){
    var path = baseUrl + 'notifikasi/lihat_pengembalian/'+Cookies.get('id');
    Ext.getCmp('bt-pemberitahuan').hideMenu();
    ajaxReq(path, function(res){
        var obj = Ext.decode(res.responseText);
            var text = '';
            var i = 0;
            for (i=0; i<obj.jumlah; i++){
                text += '<li>' + obj.notifikasi[i].keterangan + '</li><hr>';
            }
            if (obj.jumlah > 0){
                Ext.getCmp('bt-pengembalian').setText("<span style='font-weight: bold'>Pengembalian bahan pustaka</span>");
                Ext.getCmp('bt-pemberitahuan').setText("<span style='font-weight: bold'>Pemberitahuan</span>");
            }
        Ext.getCmp('panel-notifikasi').body.dom.innerHTML = text;
        Ext.getCmp('panel-notifikasi').expand(true);
    },function(res){
        Ext.example.msg('Notifikasi', res.responseText);
    });
}
function selesaiUpdate(){
    Ext.TaskMgr.stopAll();
}
function buatHalamanDepan(pos, login, tab1, tab2, artikel, log){
        jumlah = 0;
        var judul = Ext.getCmp('1').getText();
        var btGantiPass = new Ext.Button({minWidth:100, text: 'Ganti Password', hidden: true, id: 'ganti-pass', handler:function(){showChangePassForm(baseUrl + 'pengguna/ganti_pass')}});
        var idArtikel;
        //atur data untuk layar rating buku, rating tidak akan di reload secara otomatis
        var listStore = buatStore('data', 'total',['Judul', 'Pengarang', 'Bahasa', 'jumlah'] , baseUrl + 'buku/get_rating', false);
        listStore.load();
        var listView = new Ext.list.ListView({store: listStore, emptyText: 'Tidak ada buku', columnSort: false, columns: [{header: 'Judul Buku', width: .4, dataIndex: 'Judul'},{header: 'Pengarang', width: .3, dataIndex: 'Pengarang'},{header: 'Bahasa', width: .2, dataIndex: 'Bahasa'},{header: 'Frekuensi Peminjaman', dataIndex: 'jumlah'}]});
        var panelView = new Ext.Panel({title: '10 Bahan pustaka yang paling banyak dipinjam', items:listView});
        var listBukuStore = buatStore('data', 'jumlah', ['Judul', 'Pengarang', 'Penerbit', 'Klasifikasi'], baseUrl + 'buku/get_buku_baru', false);
        listBukuStore.load();
        var listVbb = new Ext.list.ListView({store: listBukuStore, emptyText: 'Tidak ada bahan pustaka baru',
                columns:[
                {header: 'Judul Bahan Pustaka',width: 0.25,dataIndex: 'Judul'},
                {header: 'Pengarang', width: .25, dataIndex: 'Pengarang'},
                {header: 'Penerbit', width: .25, dataIndex: 'Penerbit'},
                {header: 'Klasifikasi', dataIndex: 'Klasifikasi'}]
        });
        var tengah = new Ext.Panel({
            title: 'Layar Perpustakaan',
            region: 'center',
            collapsible: true,
            split: true,
            layout: 'fit',
            width: 765,
            items:[
                new Ext.TabPanel({
                    activeTab: 0,
                    id:'panelTengah',
                    items:[{items: tab1, title: 'Buku'},{items: tab2, title: 'CD/DVD'}, {preventBodyReset: false, autoLoad: baseUrl + '/artikel/ambil/1', id: 'container-artikel', title: 'Artikel: '+judul},
                    {title: 'Rating bahan pustaka', preventBodyReset: false, items:panelView, id:'panel-rating-buku'},{title: 'Pengumuman: Bahan Pustaka Baru', items: listVbb, id: 'panel-barang-baru'}]
                })
            ]
        });
        Ext.getCmp('container-artikel').on('titlechange', function(p, title){
            //eksekusi script yang akan menaikan counter jumlah lihat artikel
            var judulArt = title.split(':')[1];
            var path = baseUrl + 'pengguna/lihat_artikel';
            var params = {judul:judulArt}
            ajaxReqParams(path, null, null, params);
        });
        //panel accordion
        var paneInfoPengguna = buatInformasiAkun();

        paneInfoPengguna.hide();
        //daftarkan tombol info pinjam dan info pesan
        setAksiTombolAkun('tombol-info-pinjam', 'pengguna/ambil_daftar_pinjam/' + Cookies.get('id'), 'Peminjaman Bahan Pustaka');
        setAksiTombolAkun('tombol-info-pesan', 'pengguna/ambil_daftar_pesan/' + Cookies.get('id') + '/1', 'Pemesanan Bahan Pustaka');
        setAksiTombolAkun('tombol-info-pesan-cepat', 'pengguna/ambil_daftar_pesan/' + Cookies.get('id') + '/4', 'Pemesanan yang belum diambil');
        //Daftarkan setiap tombol pada artikel sehingga menerima event
        artikel.items.each(function(item){
                item.on('click', function(){
                    idArtikel = item.getId();
                    loadIsiPanel(2, 'Artikel: ' + item.getText(), baseUrl + 'artikel/ambil/'+idArtikel, 'get');
                });
            });
        
        //Buat panel notifikasi kemudian tambahkan kedalam panel Panel info lainnya
        var panelNotifikasi = new Ext.Panel({
            title: 'Notifikasi dari admin',
            id: 'panel-notifikasi',
            layout: 'fit',
            preventBodyReset: false,
            hidden: true
        });

        var kiri = new Ext.Panel({
            title: 'Informasi Lain',
            region: 'west',
            id: 'west-panel',
            layout: 'accordion',
            collapsible: true,
            split: true,
            width: '30%',
            items:[paneInfoPengguna, artikel, panelNotifikasi]
        });
        
        /*
         * Buat tombol navigasi dan daftarkan event untuk untuk setiap tombol navigasi sesuai dengan kegunaan.
         * Event yang diterima setiap tombol adalah event 'click'
         */
        //tombol home untuk kembali ke home
        var btHome = buatLinkButton('Beranda', baseUrl); 
        //Link menuju web akademik
        var btAka =  buatLinkButton('Web Akademik', 'http://akademik.del.ac.id');
        //Link menuju web mail
        var btMail = buatLinkButton('Web Mail', 'http://mail.del.ac.id');
        //Link menuju Web PI Del
        var btPidel = buatLinkButton('Web PI Del', 'http://www.pidel.org');
        //Link menuju Web Students
        var btStudent = buatLinkButton('Web Student', 'http://students.del.ac.id');
        var btLinks = new Ext.Button({minWidth:100, text:'Link-Link lain', menu:[btAka,btMail, btPidel, btStudent]});
        var btTentangPerpus = buatLinkTtgPerpus();
        //var btContact = buatLinkButton('Tentang Perpus', baseUrl + "userguide");
        //buat tombol notifikasi
        var tbNotif = new Ext.Button({hidden: true, minWidth:100, text: '0 Pesanan yang disetujui', id: 'tombol-notifikasi', handler:function(){
                //rubahNotifikasi(true, 1);
                panelNotifikasi.expand(true);
        }});
        var btLog = new Ext.Button({minWidth:100, text:log, id: 'submit', handler:function(){
            if (Ext.getCmp('submit').getText() == 'Masuk'){
                //pengguna akan login
                login.show();
                Ext.getCmp('nameID').focus(false,500);
            } else {
                //pengguna akan logout
                bersihkanKomponen();
                //kirim pemberitahuan ke server
                var logoutPath = baseUrl + 'pengguna/logout/';
                ajaxReqParams(logoutPath, function(){Ext.example.msg('Notifikasi Logout', 'Anda telah berhasil logout')}, function(res){alert(res.responseText)}, {id: Cookies.get('id')});
            }
        }});
        var btBukuBaru = new Ext.Button({text: 'Buku Baru', id:'bt-buku-baru',  width: 150, handler:function(){
                Ext.getCmp('bt-pemberitahuan').hideMenu();
                Ext.getCmp('panelTengah').setActiveTab(4);
                //loadIsiPanel(4, 'Pemberitahuan: Buku Baru', baseUrl+'/buku/get_buku_baru', 'get');
                listBukuStore.reload();
        }});
        var btRatingBuku = new Ext.Button({text: 'Rating Buku', id:'bt-rating-buku', width: 150, handler: function(){
                Ext.getCmp('bt-pemberitahuan').hideMenu();
                Ext.getCmp('panelTengah').setActiveTab(3);
        }});
        var btPengembalian = new Ext.Button({text: 'Pengembalian bahan pustaka', width: 150, id: 'bt-pengembalian', hidden: true, handler: function(){
                showPengembalian();
        }});
        var btPeng = new Ext.Button({text: 'Pemberitahuan', id: 'bt-pemberitahuan', menu: [btBukuBaru, btRatingBuku, btPengembalian]});
        var tb = new Ext.Toolbar({
            items:[btHome,'-', btLinks,'-',btTentangPerpus,'-',btLog, '-', btGantiPass, '-', tbNotif, '-', btPeng]
        });
        var atas = new Ext.Panel({
            title: 'Link navigasi',
            region: 'north',
            collapsible: true,
            split: true,
            layout: 'fit',
            tbar: tb
        });
        var viewport = new Ext.Panel({
            layout: 'border',
            id: 'body-page',
            renderTo: pos,
            width: 1050,
            height: 710,
            items:[tengah, kiri, atas]
        });
        if(log == 'Keluar'){
            paneInfoPengguna.show();
            btGantiPass.show();
            tbNotif.show();
            panelNotifikasi.show();
            Ext.getCmp('bt-pengembalian').show();
        }
        if (Cookies.get('id') != null){
            mulaiUpdate();
            showPengembalian();
        }
        return viewport;
    }