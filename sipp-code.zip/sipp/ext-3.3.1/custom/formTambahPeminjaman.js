Ext.QuickTips.init();
function showPinjamLangsung(path){
    var val = new Date();
    val = val.add(Date.DAY, 5);
    val = val.format('Y-m-d');
    var textNI = new Ext.form.TextField({
        fieldLabel : 'Nomor Induk',
        name : 'nomorInduk',
        width: 100
    });
    var textIdBuku = new Ext.form.TextField({
        fieldLabel : 'ID Buku',
        name : 'idBuku',
        width : 100
    });
    var cmbJumlah = new Ext.form.ComboBox({
        fieldLabel: 'Jumlah',
        name: 'jumlah',
        id: 'jumlahID',
        width:50,
        typeAhead: true,
        forceSelection: true,
        value:'1',
        triggerAction: 'all',
        mode: 'local',
        store: new Ext.data.ArrayStore({
            fields: [
                'jumlahId',
                'displayText'
            ],
            data: [[1, '1'], [2, '2'], [3, '3'], [4, '4']]
        }),
        valueField: 'jumlahId',
        displayField: 'displayText'
    });
    var cmbJenis= new Ext.form.ComboBox({
        fieldLabel: 'Jenis',
        name: 'jenis',
        id: 'jenisID',
        width:100,
        typeAhead: true,
        forceSelection: true,
        value:'Buku',
        triggerAction: 'all',
        mode: 'local',
        store: new Ext.data.ArrayStore({
            fields: ['jenisId','displayText'],
            data: [[1, 'Buku'], [2, 'CD/DVD']]
        }),
        valueField: 'jenisId',
        displayField: 'displayText'
    });
    var formPinjamLangsung = new Ext.form.FormPanel({
        frame: true,
        labelAlign: 'left',
        id: 'form-pinjam-langsung',
        width:420,
        labelWidth: 180,
        waitMsgTarget: true,
        items: [
            new Ext.form.FieldSet({
            autoHeight: true,
            items: [textNI,textIdBuku,cmbJumlah,cmbJenis,new Ext.form.DateField({
                fieldLabel: 'Tanggal Pengembalian Buku',
                name: 'tglKembali',
                id: 'tglKembaliID',
                format: 'Y-m-d',
                value : val,
                width : 200
              })],
            buttons: [{
                text:'Ok',
                handler: function(){
                    var tmp = Ext.getCmp('tglKembaliID').getValue();
                    tmp = tmp.format('Y-m-d');
                    Ext.getCmp('form-pinjam-langsung').getForm().submit({
                        url: path,
                        method: 'post',
                        success: function(f, r){
                            Ext.example.msg('Notifikasi', r.result.msg);
                            winPinjamLangsung.destroy();
                        },
                        failure: function (f, r){
                            Ext.example.msg('Notifikasi Error', r.result.msg);
                            winPinjamLangsung.destroy();
                        }
                    });
                }
            },{
                text: 'Cancel',
                handler: function(){
                    winPinjamLangsung.destroy();
                }
            }]
        })]
    });
    
    var winPinjamLangsung = new Ext.Window({
        title: 'Peminjaman Langsung',
        layout:'vbox',
        resizable:false,
        width:438,
        height:218,
        closeAction:'close',
        plain: true,
        modal: true,
        items: [formPinjamLangsung]
    });
    return winPinjamLangsung;
}