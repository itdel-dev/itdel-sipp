function buatGridAdmin(posUser, ps){
    var data = new Ext.data.Store({
        reader: new Ext.data.JsonReader({
            root: rootAdmin,
            totalProperty: totalAdmin,
            fields: ['ID', 'Username', 'Status', 'Email', 'Batas_Buku']
        }),
        proxy: new Ext.data.HttpProxy({
            url: posUser,
            method: 'POST'
        }),
        remoteSort: true
    });
    data.setDefaultSort('Nama'); //default sort adalah ascending

    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header: 'ID', dataIndex: 'ID', width: 60, hidden: false},
                {header: 'Nama', dataIndex: 'Username', width:240},
                {header: 'Status', dataIndex: 'Status', width: 80},
                {header: 'Email', dataIndex: 'Email', id:'email'},
                {header: 'Batas Buku', dataIndex: 'Batas_Buku'}]
    });

    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['Nama', 'Nama'], ['Status', 'Status']]
        });

    var tb = buatToolbar('Admin', 'Nama', data, store, ps);

    var grid = buatGrid('panel-grid-admin', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
            var record = grid.getStore().getAt(rowIndex);  // Get the Record
            var data = record.get('ID');
            var teks;
            var path = baseUrl + 'pengguna/status_trans/'+data;
            ajaxReq(path, function(res){
                teks = res.responseText;
                //load data yang akan ditampilkan dari server
                path = baseUrl + 'pengguna/detailBuku/' + data;
                var scBack = function (response){
                    var hasil = response.responseText;
                    showDetailUser(hasil, teks, data);
                }
                ajaxReq(path, scBack, function(response){Ext.Msg.alert(response.responseText)});
            });

    });

    data.load({start:0});
    return grid;
}