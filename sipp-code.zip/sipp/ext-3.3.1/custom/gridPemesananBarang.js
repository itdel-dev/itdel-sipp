function buatGridPemesanan(path, ps){
    var data = buatStore('data', 'jumlah', ['ID', 'Nama', 'Jenis_Kategori', 'Nomor', 'Tgl_Transaksi', 'status'], path, true);
    data.setDefaultSort('Tgl_Transaksi');
    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header: 'ID Pemesanan', dataIndex: 'ID', hidden: true},
                {header: 'Nama', dataIndex: 'Nama'},
                {header:'Jenis', dataIndex: 'Jenis_Kategori'},
                {header: 'Master', dataIndex: 'Nomor'},
                {header: 'Tanggal', dataIndex: 'Tgl_Transaksi'},
                {header: 'Status', dataIndex: 'status'}]
    });

    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['Nama', 'Nama'], ['Jenis_Kategori', 'Jenis'], ['Nomor', 'Master'], ['Tgl_Transaksi', 'Tanggal']]
        });
    var tb = buatToolbar('Pemesanan', 'Nama', data, store, ps);
    var grid = buatGrid('panel-grid-pemesanan-admin', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
        var record = grid.getStore().getAt(rowIndex);  // Get the Record
        var data = record.get('status');
        if (data == 'Pesan Cepat'){
            var btSetuju = new Ext.Button({text: 'Setujui Pesanan', width: 100, height: 30,handler:function(){
                Ext.getCmp('window-konfirmasi').destroy();
                tampilWindowAksi(record.get('ID'));
            }});
            tampilWindowKonfirmasi(btSetuju, record.get('ID'));
        } else if (data == 'Pesan'){
            btSetuju = new Ext.Button({text: 'Setujui Pesanan', width: 100, height: 30,handler:function(){
                Ext.getCmp('window-konfirmasi').destroy();
                tampilWindowAksi(record.get('ID'));
                reloadStore('panel-grid-pemesanan-admin');
            }});
            tampilWindowKonfirmasi(btSetuju, record.get('ID'));
            //Ext.example.msg('Notifikasi', 'Pesan');
        } else if(data == 'Setuju'){
            //Ext.example.msg('Notifikasi', 'Setuju');
            var btPjm = new Ext.Button({text: 'Pinjam', width: 100, height: 30, handler: function(){
                    Ext.getCmp('window-konfirmasi').destroy();
                    tampilWindowPinjam(record.get('ID'), record.get('Nomor'));
            }});
            tampilWindowKonfirmasi(btPjm, record.get('ID'));
        }
    });
    data.load({start:0});
    return grid;
}
function mulaiUpdatePemesanan(){
    var update = function(){
            reloadStore('panel-grid-pemesanan-admin');
        }
        Ext.TaskMgr.start({
            run: update,
            interval: 15000
        });
}