Ext.QuickTips.init();

function showAddCD(path){
    var textID = new Ext.form.TextField({
        fieldLabel : 'ID CD/DVD',
        name : 'idkaset',
        id : 'idkasetID',
        width : 100
    });
    var textJudul = new Ext.form.TextField({
        fieldLabel: 'Judul',
        name: 'judulkaset',
        id:'judulID',
        width:200
    });
    var textKeterangan = new Ext.form.TextArea({
        fieldLabel: 'Keterangan',
        name: 'keterangan',
        id:'keteranganID',
        width:200
    });
    var cmbCpor = new Ext.form.ComboBox({
        fieldLabel: 'Cp / Or',
        name: 'cpor',
        id: 'cporID',
        width:150,
        typeAhead: true,
        triggerAction: 'all',
        forceSelection: true,
        value:'Copy',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'cporId',
                'displayText'
            ],
            data: [[1, 'Copy'], [2, 'Original']]
        }),
        valueField: 'cporId',
        displayField: 'displayText'
    });
    var cmbJenis = new Ext.form.ComboBox({
        fieldLabel: 'Jenis',
        name: 'jenis',
        id: 'jenisID',
        width:150,
        typeAhead: true,
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'jenisId',
                'displayText'
            ],
            data: [[1, 'CD'], [2, 'DVD']]
        }),
        valueField: 'jenisId',
        displayField: 'displayText'
    });
    var doSubmit = function (){
        Ext.getCmp('addKaset-form').getForm().submit({
            success:function(form, action){
                Ext.example.msg('Sukses',action.result.msg);
		Ext.getCmp('addKaset-form').getForm().reset();
		Ext.getCmp('window-addKaset').destroy();
            },
            failure:function(form, action){
                Ext.example.msg('Gagal',action.result.msg);
                if (action.result.error == 1){
                    Ext.getCmp('idKasetID').focus(true);
                }
            }
        });
    };
    var formAddNewKaset = new Ext.FormPanel({
        frame: true,
        url:path,
        id:'addKaset-form',
        labelAlign: 'left',
        fileUpload:true,
        labelWidth: 100,
        width:350,
        waitMsgTarget: true,
        items: [
        new Ext.form.FieldSet({
	autoHeight: true,
	defaultType: 'textfield',
	items: [textID,textJudul,textKeterangan,cmbCpor,cmbJenis,
                {
                        xtype: 'fileuploadfield',
                        id: 'gambarID',
                        width:200,
                        emptyText: 'Pilih Gambar',
                        fieldLabel: 'Gambar',
                        name: 'gambarKaset',
                        buttonText: 'Lihat'
                    }],
                buttons: [{
                    text:'Ok',
                    handler: doSubmit
                },{
                    text: 'Cancel',
                    handler: function(){
                        winAddNewKaset.destroy();
                    }
                }]
        })]
    });

    var winAddNewKaset = new Ext.Window({
        title: 'Tambah CD/DVD Baru',
        layout:'vbox',
        id:'window-addKaset',
        width:365,
        height:300,
        resizable:false,
        closeAction:'close',
        plain: true,
	modal: true,
        items: [formAddNewKaset]
    });
    return winAddNewKaset;
}