function loadPemesananPeminjaman(){
    Ext.TaskMgr.start({
            run: mulai_update_pepi,
            interval: 10000
        });
}

function mulai_update_pepi(){
    var mgrPath = baseUrl + '';
    Ext.Ajax.request({
        url: mgrPath,
        method: 'get',
        success: function(res){
                   var obj = Ext.decode(res.responseText);
                   var text = '';
                   var i = 0;
                   for (i=0; i<obj.jumlah; i++){
                        text += '<li>' + obj.notifikasi[i].kategori + ' dengan id ' + obj.notifikasi[i].id_kat +' yang ' + Cookies.get('pengguna') + ' pesan telah tersedia' + '</li><hr>';
                   }
                   Ext.getCmp('panel-notifikasi').body.dom.innerHTML = text;
                   rubahNotifikasi(true, cast_angka(obj.jumlah));
               },
        failure: function(res){
            alert(res.responseText);
        }
    });
}