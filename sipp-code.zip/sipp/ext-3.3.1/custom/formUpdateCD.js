Ext.QuickTips.init();

function showUpdateCD(path){
    var textID = new Ext.form.TextField({
        fieldLabel : 'ID CD/DVD',
        name : 'ID',
        id : 'idkasetID',
        width : 100,
        disabled: true
    });
    var textJudul = new Ext.form.TextField({
        fieldLabel: 'Judul',
        name: 'Judul',
        id:'judulID',
        width:200
    });
    var textKeterangan = new Ext.form.TextArea({
        fieldLabel: 'Keterangan',
        name: 'Keterangan',
        id:'keteranganID',
        width:200
    });
    var cmbCpor = new Ext.form.ComboBox({
        fieldLabel: 'Cp / Or',
        name: 'Cp_Or',
        id: 'cporID',
        width:150,
        typeAhead: true,
        triggerAction: 'all',
        forceSelection: true,
        value:'Copy',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'cporId',
                'displayText'
            ],
            data: [[1, 'Copy'], [2, 'Original']]
        }),
        valueField: 'cporId',
        displayField: 'displayText'
    });
    var cmbJenis = new Ext.form.ComboBox({
        fieldLabel: 'Jenis',
        name: 'Jenis',
        id: 'jenisID',
        width:150,
        typeAhead: true,
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'jenisId',
                'displayText'
            ],
            data: [[1, 'CD'], [2, 'DVD']]
        }),
        valueField: 'jenisId',
        displayField: 'displayText'
    });
    var cmbStatus = new Ext.form.ComboBox({
        fieldLabel: 'Status',
        name: 'Status',
        width:150,
        typeAhead: true,
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            fields: ['id','value'],
            data: [['Tersedia','Tersedia'],['Pesan', 'Pesan'], ['Pinjam', 'Pinjam'],['Hapus', 'Hapus']]
        }),
        valueField: 'id',
        displayField: 'value'
    });
    var formUpdateCD = new Ext.FormPanel({
                    frame: true,
                    id: 'form-update-kaset',
                    labelAlign: 'left',
                    fileUpload:true,
                    labelWidth: 100,
                    width:350,
                    height: 250,
                    reader: new Ext.data.XmlReader({record: 'data', success: '@success'}, ['ID', 'Cp_Or', 'Status', 'Judul', 'Jenis', 'Keterangan']),
                    waitMsgTarget: true,
                    items: [textID, textJudul, textKeterangan, cmbCpor, cmbJenis, cmbStatus,{
                            xtype: 'fileuploadfield',
                            id: 'gambarID',
                            width:200,
                            emptyText: 'Pilih Gambar',
                            fieldLabel: 'Gambar',
                            name: 'gambar',
                            buttonText: 'Lihat'
                        }]
		});

                var winUpdateCD = new Ext.Window({
                title: 'Ubah CD',
                layout:'fit',
                width:370,
                closeAction:'close',
                plain: true,
		modal: true,

                items: [formUpdateCD],
                buttons: [{
                    text:'Ok',
                    handler: function(){
                        textID.enable();
                        var path = baseUrl + 'kaset/rubah/';
                        formUpdateCD.getForm().submit({
                            url: path,
                            waitMsg: 'Perubahan sedang diproses',
                            method: 'post',
                            success: function(f, a){
                                Ext.example.msg('Notifikasi', a.result.msg);
                                reloadStore('panel-grid-kaset-admin');
                                winUpdateCD.destroy();
                            },
                            failure: function(f, a){
                                Ext.example.msg('Notifikasi', a.result.msg);
                                winUpdateCD.destroy();
                            }
                        });
                    }
                },{
                    text: 'Cancel',
                    handler: function(){
                        winUpdateCD.destroy();
                    }
                }]
            });
            return winUpdateCD;
}