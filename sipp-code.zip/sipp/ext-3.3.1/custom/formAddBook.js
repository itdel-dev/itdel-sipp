Ext.QuickTips.init();

function showAddBook(path){
    var textIDBuku = new Ext.form.TextField({
        fieldLabel :'ID Buku',
        name : 'id_buku',
        id : 'id_bukuID',
        width:100
    });
    var textJudulBuku = new Ext.form.TextField({
        fieldLabel: 'Judul Buku',
        name: 'judul',
        id: 'judul_bukuID',
        width:200
    });
    var textBahasa = new Ext.form.TextField({
        fieldLabel: 'Bahasa',
        name: 'bahasa',
        id:'bahasaID',
        width:200
    });
    var textEdisi = new Ext.form.TextField({
        fieldLabel: 'Edisi',
        name: 'edisi',
        id:'edisiID',
        width:200
    });
    var textPengarang = new Ext.form.TextField({
        fieldLabel: 'Pengarang',
        name: 'pengarang',
        id:'pengarangID',
        width:200
    });
    var textDeskripsi = new Ext.form.TextArea({
        fieldLabel : 'Deskripsi',
        name: 'deskripsi',
        id:'deskripsiID',
        width:200,
        height:100
    });
    var textJenis = new Ext.form.TextField({
        fieldLabel: 'Jenis',
        name: 'jenis',
        id:'jenisID',
        width:200
    });
    var textPenerbit = new Ext.form.TextField({
        fieldLabel: 'Penerbit',
        name: 'penerbit',
        id: 'penerbitID',
        width:150
    });
    var textKlasifikasi = new Ext.form.TextField({
        fieldLabel: 'Klasifikasi',
        name: 'klasifikasi',
        id: 'klasifikasiID',
        width:150
    });
    var cmbLokasi = new Ext.form.ComboBox({
        fieldLabel: 'Lokasi',
        name: 'lokasi',
        id: 'lokasiID',
        width:150,
        typeAhead: true,
        forceSelection: true,
        value:'L1',
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'lokasiId',
                'displayText'
            ],
            data: [[1, 'L1'], [2, 'L2']]
        }),
        valueField: 'lokasiId',
        displayField: 'displayText'
    });
    var textISBN = new Ext.form.TextField({
        fieldLabel: 'ISBN',
        name: 'isbn',
        id:'isbnID',
        width:100
    });
    var textTahun = new Ext.form.TextField({
        fieldLabel: 'Tahun',
        name: 'tahun',
        id:'tahunID',
        width:100
    });
    var cmbStatus = new Ext.form.ComboBox({
        fieldLabel: 'Status',
        name: 'status',
        id: 'statusID',
        width:150,
        typeAhead: true,
        forceSelection: true,
        value : 'Baik',
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'statusId',
                'displayText'
            ],
            data: [[1, 'Baik'], [2, 'Rusak']]
        }),
        valueField: 'statusId',
        displayField: 'displayText'
    });
    var cmbCpor = new Ext.form.ComboBox({
        fieldLabel: 'CP / OR',
        name: 'cpor',
        id: 'cporID',
        width:150,
        typeAhead: true,
        forceSelection: true,
        value:'Copy',
        triggerAction: 'all',
        lazyRender:true,
        mode: 'local',
        store: new Ext.data.ArrayStore({
            id: 0,
            fields: [
                'cporId',
                'displayText'
            ],
            data: [[1, 'Copy'], [2, 'Original']]
        }),
        valueField: 'cporId',
        displayField: 'displayText'
    });
    var doSubmit = function (){
        Ext.getCmp('tambahBuku-form').getForm().submit({
            waitMsg: 'Menambah Data',
            success:function(form, action){
                //alert(Ext.encode(action.result));
		Ext.example.msg('Sukses',action.result.msg);
                Ext.getCmp('tambahBuku-form').getForm().reset();
                Ext.getCmp('window-tambah-buku').destroy();
            },
            failure:function(form, action){
                Ext.example.msg('Notifikasi Error', action.result.msg);
                if (action.result.error == 1){
                    Ext.getCmp('id_bukuID').focus(true);
                } else if (action.result.error == 2){
                    Ext.getCmp('tahunID').focus(true);
                }
            }
        });
    };
    var formAddNewBook = new Ext.FormPanel({
        frame: true,
        url:path,
        fileUpload:true,
        id:'tambahBuku-form',
        labelAlign: 'left',
        labelWidth: 100,
        width:350,
        waitMsgTarget: true,
        items: [
            new Ext.form.FieldSet({
                autoHeight: true,
		defaultType: 'textfield',
		items: [textIDBuku,textBahasa,textJudulBuku, textEdisi,textPengarang,textDeskripsi,textJenis,textPenerbit,textKlasifikasi,cmbLokasi,textISBN,textTahun,cmbStatus,cmbCpor,
                        {
                        xtype: 'fileuploadfield',
                        id: 'gambarID',
                        width:200,
                        emptyText: 'Pilih Gambar',
                        fieldLabel: 'Gambar',
                        name: 'gambar',
                        buttonText: 'Lihat'
                    }],
                buttons: [{
                            text:'Tambah Buku',
                            handler : doSubmit
                        },{
                            text: 'Batal',
                            handler: function(){
                                winAddNewBook.destroy();
                            }
                    }]
        })]
    });
    var winAddNewBook = new Ext.Window({
        title: 'Tambah Buku Baru',
        id:'window-tambah-buku',
        layout:'vbox',
        width:350,
        height:570,
        resizable :false,
        closeAction:'close',
        plain: true,
	modal: true,
        items: [formAddNewBook]
    });
    return winAddNewBook;
}