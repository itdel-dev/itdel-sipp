Ext.QuickTips.init();

function showUpdateAdmin(path){
    var textAdminName = new Ext.form.TextField({
                    fieldLabel: 'Admin Name',
                    name: 'adminname',
                    width:200
                });
                var textPassword = new Ext.form.TextField({
                    fieldLabel: 'Password',
                    inputType: 'password',
                    name: 'password',
                    width:200
                });
                var textFungsiAdmin = new Ext.form.TextField({
                    fieldLabel: 'Fungsi Admin',
                    name: 'fungsiadmin',
                    width:200
                });
                var formUpdateAdmin = new Ext.FormPanel({
                    frame: true,
                    labelAlign: 'left',
                    labelWidth: 130,
                    width:380,
                    waitMsgTarget: true,
                    items: [
                        new Ext.form.FieldSet({
			autoHeight: true,
			defaultType: 'datefield',
			items: [textAdminName,textPassword,textFungsiAdmin,{
                        fieldLabel: 'Masa Jabatan Admin',
                        name: 'jbtanadmin',
                        id: 'jbtanadmin',
                        width :150,
                        vtype: 'daterange',
                        endDateField: 'enddt' // id of the end date field
                      }]
                    })]
		});

                var winUpdateAdmin = new Ext.Window(
                title: 'Ubah Admin',
                layout:'vbox',
                width:400,
                height:210,
                closeAction:'hide',
                plain: true,
				modal: true,

                items: [formUpdateAdmin],
                buttons: [{
                    text:'Ok'
                },{
                    text: 'Cancel',
                    handler: function(){
                        winUpdateAdmin.hide();
                    }
                }]
            });
    return winUpdateAdmin;

}