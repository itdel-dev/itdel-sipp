var pathUpdate;
function showWindowInfo(url, title){
    pathUpdate = baseUrl + url;
    var pane = new Ext.Panel({
        width: 'auto',
        id: 'panel-info-trans',
        title: title,
        preventBodyReset: true,
        autoLoad: {url: pathUpdate}
    });

    var win = new Ext.Window({
        layout: 'fit',
        title: 'Daftar Transaksi Anda',
        id: 'window-detail-trans-buku',
        width: 280,
        height: 200,
        x: 100, y: 50,
        closeAction: 'close',
        modal: false,
        resizable: true,
        items: [pane]
    });
    win.show();
}
function buatPopUp(layout, judul, id, m, i, bt){
    var win = new Ext.Window({
        layout: layout,
        title: judul,
        id: id,
        width: 350,
        height: 400,
        closeAction: 'close',
        modal: m,
        resizable: false,
        items: i,
        autoScroll: true,
        buttons: bt
    });
    return win;
}
function perbaharuiWindowInfo(){
    var updater = Ext.getCmp('panel-info-trans').getUpdater();
    updater.update({url: pathUpdate});
    var paramAkhir = Ext.getCmp('panel-grid-buku').getStore().lastOptions;
    Ext.getCmp('panel-grid-buku').getStore().load(paramAkhir);
}
function hancurkanWindowInfo(){
    if(Ext.getCmp('window-detail-trans-buku') != undefined){
        Ext.getCmp('window-detail-trans-buku').destroy();
    }
}
function batal_pesan(jenis, idB){
    var path = baseUrl + 'pengguna/batal_pesan';
    var params = {id_jenis:jenis, id:idB, pengguna: Cookies.get('id')};
    var sf = function(){
		Ext.example.msg('Pemberitahuan', 'Pesanan telah dibatalkan');
                perbaharuiWindowInfo();
            }
    var ff = function (res){alert(res.responseText);};
    ajaxReqParams(path, sf, ff, params);
}
function buatWindowDetailPengguna(path, pengguna, stat){
    var pane = new Ext.Panel({
        autoLoad: path,
        width: 500,
        autoScroll: true,
        preventBodyReset: true
    });
    var btTutup = new Ext.Button({
        text: 'Tutup',
        width: 100,
        handler: function(){Ext.getCmp('window-detail-pengguna').destroy()}
    });
    var btRubah = new Ext.Button({
        text: 'Rubah',
        width: 100,
        handler: function(){
            var win = showUpdateUser(baseUrl + 'pengguna/rubah/');
            Ext.getCmp('form-update-pengguna').getForm().load({url: baseUrl + 'pengguna/get_data_update/' + pengguna});
            win.show();
            Ext.getCmp('window-detail-pengguna').destroy();
        }
    });
    var btHapus = new Ext.Button({
        text: 'Hapus',
        width: 100,
        handler: function(){
            if (stat.toLowerCase() == 'tidak aktif'){
                Ext.example.msg('Notifikasi', 'Pengguna tidak aktif lagi');
            } else {
                var path = baseUrl + 'pengguna/hapus/';
                var f = function(res){
                    Ext.example.msg('Notifikasi', res.responseText);
                    Ext.getCmp('window-detail-pengguna').destroy();
                 }
                buatWindow('Apakah Anda yakin menghapus CD/DVD ini?', path, f, f, {username: pengguna});
            }
        }
    });
    var win = buatPopUp('fit', 'Detail Pengguna', 'window-detail-pengguna', true, pane, [btRubah, btHapus, btTutup]);
    return win;
}
