function buatGridUser(posUser, ps){
    var data = buatStore(rootUser, totalUser, ['Username', 'Status', 'Email', 'Batas_Buku', 'Nama'], posUser, true);
    data.setDefaultSort('Nama'); //default sort adalah ascending
    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header: 'Akun', dataIndex: 'Username', width:240},
                {header: 'Status', dataIndex: 'Status', width: 80},
                {header: 'Email', dataIndex: 'Email', id:'email'},
                {header: 'Batas Buku', dataIndex: 'Batas_Buku'},
                {header: 'Peran', dataIndex: 'Nama'}]
    });
    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['Username', 'Akun'], ['Status', 'Status'], ['Batas_Buku', 'Batas Buku'], ['Nama', 'Peran'], ['Email','Email']]
        });

    var tb = buatToolbar('Pengguna', 'Nama', data, store, ps);
    var grid = buatGrid('panel-grid-pengguna', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
            var record = grid.getStore().getAt(rowIndex);  // Get the Record
            var uname = record.get('Username');
            var path = baseUrl + '/pengguna/get_detail_pengguna/' + uname;
            var win = buatWindowDetailPengguna(path, record.get('Username'), record.get('Status'));
            win.show();
    });

    data.load({start:0});
    return grid;
}