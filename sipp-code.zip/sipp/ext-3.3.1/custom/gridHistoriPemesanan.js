function buatGridHistory(posHistory, ps){
    var data = buatStore(rootPeminjaman, totalPeminjaman, ['ID', 'ID_Pengguna', 'NI', 'Nama', 'Tgl_Pinjam', 'Tgl_Kembali', 'ID_Referensi_Kategori', 'Jenis_Kategori', 'Bahan', 'Denda'], posHistory, true)
    data.setDefaultSort('ID'); //default sort adalah ascending

    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 80, sortable: true},
            columns: [
                {header: 'ID', dataIndex: 'ID', width: 50, hidden: true},
                {header:'ID Pengguna', dataIndex: 'ID_Pengguna', width: 60, hidden: true},
                {header: 'No Induk', dataIndex: 'NI'},
                {header: 'Nama', dataIndex: 'Nama'},
                {header: 'Tanggal Pinjam', dataIndex: 'Tgl_Pinjam'},
                {header: 'Tanggal Kembali', dataIndex: 'Tgl_Kembali'},
                {header:'No Jenis', dataIndex: 'ID_Referensi_Kategori', hidden: true},
                {header:'Jenis', dataIndex: 'Jenis_Kategori'},
                {header: 'ID Bahan Pustaka', dataIndex: 'Bahan'},
                {header: 'Denda', datatIndex: 'Denda'}]
    });

    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['NI', 'No Induk'], ['Nama', 'Nama'], ['date(Tgl_Pinjam)', 'Tanggal Pinjam'], ['date(Tgl_Kembali)', 'Tanggal Kembali'], ['Jenis_Kategori', 'Jenis'], ['Bahan', 'ID Bahan'], ['Denda', 'Denda']]
        });
    var tb = buatToolbar('Sejarah', 'NI', data, store, ps);
    var grid = buatGrid('panel-grid-sejarah-peminjaman', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
        var record = grid.getStore().getAt(rowIndex);  // Get the Record
        var data = record.get('ID');
        tampilWindowHistory(data);
    });
    data.load({start: 0});
    return grid;
}