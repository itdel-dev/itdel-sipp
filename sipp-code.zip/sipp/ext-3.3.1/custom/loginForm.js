Ext.QuickTips.init();

function showLoginForm(path){
    var textUsername = new Ext.form.TextField({fieldLabel: 'Username',name: 'username',id: 'nameID', width:200, allowBlank: false, blankText: 'Field harus diisi'});
    var textPassword = new Ext.form.TextField({fieldLabel: 'Password',inputType: 'password',name: 'password', id:'passID', width:200, allowBlank: false, blankText: 'Field harus diisi'});

    textUsername.on('specialkey', function(txt, e){
        if (e.getKey() == e.ENTER){
            doSubmit();
        }
    });
    textPassword.on('specialkey', function (txt, e){
        if (e.getKey() == e.ENTER){
            doSubmit();
        }
    });

    var doSubmit = function (){
        Ext.getCmp('login-form').getForm().submit({
           url: path,
           method: 'post',
           success:function(form, action){
               var nama = Ext.getCmp('nameID').getValue();
               Cookies.set('pengguna', nama);
               Cookies.set('id', action.result.id);
               Cookies.set('global', action.result.global);
               Cookies.set('turunan', action.result.turunan);
               Cookies.set('nama_pengguna', action.result.nama_akun);
               if (action.result.global == true || action.result.turunan == true){
                    Ext.getCmp('body-page').destroy();
                    var path = baseUrl + 'lib/admin';
                    showWeb(path);
               } else {
                   Ext.getCmp('login-form').getForm().reset();
                   Ext.getCmp('submit').setText('Keluar');
                   Ext.getCmp('info-pengguna').show();
                   Ext.getCmp('west-panel').getLayout().setActiveItem('info-pengguna');
                   Ext.getCmp('teks-sambutan').setText('Selamat Datang ' + action.result.nama_akun);
                   Ext.getCmp('tombol-info-pinjam').setText('Barang-barang yang ' + action.result.nama_akun + ' pinjam');
                   Ext.getCmp('tombol-info-pesan').setText('Barang-barang yang ' + action.result.nama_akun + ' pesan');
                   Ext.getCmp('tombol-info-pesan-cepat').setText('Barang-barang yang harus diambil hari ini');
                   Ext.getCmp('window-login').hide();
                   Ext.getCmp('ganti-pass').show();
                   Ext.getCmp('tombol-notifikasi').show();
                   Ext.getCmp('panel-notifikasi').show();
                   Ext.getCmp('bt-pengembalian').show();
                   showPengembalian();
                   mulaiUpdate();
               }
            },
            failure:function(form, action){
                Ext.example.msg('Notifikasi Error', action.result.msg);
                Ext.getCmp('passID').setValue('');
                Ext.getCmp('nameID').setValue('');
                Ext.getCmp('nameID').focus(true);
            }
        });
    }

    var form = new Ext.form.FormPanel({
	id: 'login-form',
	title: 'Login Form',
	border: false,
        labelWidth: 55,
        width: 250,
        height: 300,
        waitMsgTarget: true,
	items: [new Ext.form.FieldSet({autoHeight: true,defaultType: 'textfield',items: [textUsername,textPassword]})],
	buttons: [{
            text: 'Login',
            handler: doSubmit
	},{
            text: 'Batal',
            handler: function(){
                Ext.getCmp('login-form').getForm().reset();
                Ext.getCmp('window-login').hide();
            }
	}]
    });

    var win = new Ext.Window({
        layout: 'fit',
        id: 'window-login',
        width: 300,
        height: 200,
        closeAction: 'hide',
        modal: true,
        resizable: false,
        items: form
    });
				
    return win;
}