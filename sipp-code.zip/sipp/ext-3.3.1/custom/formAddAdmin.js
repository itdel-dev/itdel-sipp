Ext.QuickTips.init();
function showAddAdmin(path){
    var textAdminName = new Ext.form.TextField({
                    fieldLabel: 'Admin Name',
                    name: 'adminname',
                    width:200
                });
                var fungsi = new Ext.form.CheckboxGroup({
                    id:'fungsiID',
                    xtype: 'checkboxgroup',
                    fieldLabel: 'Fungsi',
                    itemCls: 'x-check-group-alt',
                    columns: 3,
                    items: [
                        {boxLabel: 'Create Buku', name: 'cb-c-buku'},
                        {boxLabel: 'Create Kaset', name: 'cb-c-kaset'},
                        {boxLabel: 'Create User', name: 'cb-c-user'},
                        {boxLabel: 'View User', name: 'cb-v-user'},
                        {boxLabel: 'Update Buku', name: 'cb-u-buku'},
                        {boxLabel: 'Update Kaset', name: 'cb-u-kaset'},
                        {boxLabel: 'Delete Buku', name: 'cb-d-buku'},
                        {boxLabel: 'Delete Kaset', name: 'cb-d-kaset'},
                        {boxLabel: 'Delete User', name: 'cb-d-user'},
                        {boxLabel: 'Konfirmasi Pemesanan', name: 'cb-k-pemesanan'},
                        {boxLabel: 'Catat Peminjaman', name: 'cb-c-peminjaman'},
                        {boxLabel: 'Catat Pengembalian', name: 'cb-c-pengembalian'}
                    ]
                });
                var formAddNewAdmin = new Ext.FormPanel({
                    frame: true,
                    labelAlign: 'left',
                    url:path,
                    labelWidth: 100,
                    width:640,
                    waitMsgTarget: true,
                    items: [
                        new Ext.form.FieldSet({
			autoHeight: true,
			defaultType: 'datefield',
			items: [textAdminName,fungsi]
                    })]
		});

                var winAddNewAdmin = new Ext.Window({
                //applyTo:'hello-win',
                title: 'Tambah Admin Baru',
                layout:'vbox',
                resizable:false,
                width:655,
                height:220,
                closeAction:'close',
                plain: true,
                modal: true,
                items: [formAddNewAdmin],
                buttons: [{
                    text:'Ok',
                    handler: function(){
                        formAddNewAdmin.getForm().submit({
                            url: baseUrl + 'lib/tambah_admin',
                            method: 'post',
                            success: function(f, a){
                                Ext.example.msg();
                            },
                            failure: function (f, a){

                            }
                        });
                    }
                },{
                    text: 'Cancel',
                    handler: function(){
                        winAddNewAdmin.destroy();
                    }
                }]
            });
    return winAddNewAdmin;

}