function buatGridBukuAdmin(posBuku, ps){
    var data = buatStore(rootBuku, totalBuku, ['ID','Judul', 'Pengarang', 'Penerbit', 'Klasifikasi', 'Jenis','Status'], posBuku, true)
    data.setDefaultSort('ID'); //default sort adalah ascending

    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header:'ID Buku', dataIndex: 'ID', width: 60},
                {header: 'Judul', dataIndex: 'Judul', width:240},
                {header: 'Pengarang', dataIndex: 'Pengarang'},
                {header: 'Penerbit', dataIndex: 'Penerbit'},
                {header:'Jenis Buku', dataIndex: 'Jenis'},
                {header:'Status Buku', dataIndex: 'Status'},
                {header:'Klasifikasi', dataIndex: 'Klasifikasi'}]
    });

    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['ID', 'ID Buku'], ['Pengarang', 'Pengarang'], ['Judul', 'Judul'], ['Klasifikasi', 'Klasifikasi'], ['Penerbit', 'Penerbit']]
        });
    var tb = buatToolbar('Buku', 'ID_Buku', data, store, ps);
    var grid = buatGrid('panel-grid-buku-admin', data, colModel, tb);

    grid.on('cellclick', function(grid, rowIndex){
            var record = grid.getStore().getAt(rowIndex);  // Get the Record
            var data = record.get('ID');
            var teks;
            var path = baseUrl + 'buku/status_trans_detail/'+data;
            ajaxReq(path, function(res){
                teks = res.responseText;
                //load data yang akan ditampilkan dari server
                path = baseUrl + 'buku/tampil_detail_buku_adm/' + data;
                var scBack = function (response){
                    var hasil = response.responseText;
                    var stt = record.get('Jenis');
                    var trans = (stt != null && stt.toLowerCase() == 'tandon') ? false : true;
                    showDetailBukuAdmin(hasil, teks, data, trans);
                }
                ajaxReq(path, scBack, function(response){Ext.Msg.alert(response.responseText)});
            }, function(res){alert(res.responseText)});
    });
    data.load({start:0});
    return grid;
}