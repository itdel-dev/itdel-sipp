Ext.QuickTips.init();
function showAddArticle(path){
    var textJudul = new Ext.form.TextField({
        fieldLabel: 'Judul Artikel',
        name: 'judul',
	id: 'judulID',
        width:400
    });
	var isiArtikel =  new Ext.form.HtmlEditor({
		width: 800,
		name: 'isi',
		id: 'isiID',
		height: 300
	});
	var doSubmit = function (){
        Ext.getCmp('artikel-form').getForm().submit({
           success:function(form, action){
                                Ext.example.msg('Sukses','Artikel Berhasil di tambah');
				Ext.getCmp('artikel-form').getForm().reset();
				Ext.getCmp('window-tambah-artikel').destroy();
            },
            failure:function(){
                Ext.example.msg('Gagal','Artikel tidak Berhasil di tambah');
                Ext.getCmp('isiID').setValue('');
                Ext.getCmp('judulID').focus(true);
            }
        });
    }
	
    var formAddArticle = new Ext.FormPanel({
		frame: true,
		url: path,
		id: 'artikel-form',
        labelAlign: 'left',
        labelWidth: 70,
        width:920,
        waitMsgTarget: true,
        items: [
		new Ext.form.FieldSet({
                    autoHeight: true,
                    defaultType: 'textfield',
                    items: [textJudul,isiArtikel],
                    buttons: [{
                        text:'Ok',
                        handler : doSubmit
                    },{
                        text: 'Cancel',
                        handler: function(){
                            winAddArticle.destroy();
                        }
                    }]
            })
		]
	});
    var winAddArticle = new Ext.Window({
		title: 'Tambah Article',
		id: 'window-tambah-artikel',
        layout:'vbox',
        width: 935,
        resizable :false,
        height: 445,
        closeAction:'hide',
        plain: true,
		modal: true,
		items: [formAddArticle]
	});
    return winAddArticle;
}