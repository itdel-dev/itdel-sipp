Ext.QuickTips.init();

function showUpdateBook(path){
    var textID = new Ext.form.TextField({fieldLabel: 'ID Buku', id: 'textFieldRubahID', name: 'ID', width: 200, disabled: true});
    var textIDM = new Ext.form.Hidden({name: 'ID_Master_Buku', width: 200});
    var textBahasa = new Ext.form.TextField({fieldLabel: 'Bahasa',name: 'Bahasa', width: 200});
    var textJudulBuku = new Ext.form.TextField({
                    fieldLabel: 'Judul Buku',
                    name: 'Judul',
                    width:200
                });
                var textEdisi = new Ext.form.TextField({
                    fieldLabel: 'Edisi',
                    name: 'Edisi',
                    width:200
                });
                var textPengarang = new Ext.form.TextField({
                    fieldLabel: 'Pengarang',
                    name: 'Pengarang',
                    width:200
                });
                var textDeskripsi = new Ext.form.TextArea({
                    fieldLabel : 'Deskripsi',
                    name: 'Deskripsi',
                    width:200,
                    height:100
                });
                var textJenis = new Ext.form.TextField({
                    fieldLabel: 'Jenis',
                    name: 'Jenis',
                    width:200
                });
                var textPenerbit = new Ext.form.TextField({
                    fieldLabel: 'Penerbit',
                    name: 'Penerbit',
                    width:150
                });
                var cmbKlasifikasi = new Ext.form.TextField({
                    fieldLabel: 'Klasifikasi',
                    name: 'Klasifikasi',
                    width:150
                });
                var cmbLokasi = new Ext.form.ComboBox({
                    store: new Ext.data.ArrayStore({
                        fields: ['id', 'value'],
                        data: [['L1', 'L1'], ['L2', 'L2']]
                    }),
                    fieldLabel: 'Lokasi',
                    name: 'Lokasi',
                    forceSelection: true,
                    mode: 'local',
                    displayField: 'value',
                    triggerAction: 'all',
                    width:150
                });
                var cmbCo = new Ext.form.ComboBox({
                    store: new Ext.data.ArrayStore({
                        fields: ['id', 'value'],
                        data: [['Copy', 'Copy'], ['Original', 'Original']]
                    }),
                    fieldLabel: 'Keaslian',
                    name: 'Cp_Or',
                    forceSelection: true,
                    mode: 'local',
                    displayField: 'value',
                    triggerAction: 'all',
                    width:150
                });
                var textISBN = new Ext.form.TextField({
                    fieldLabel: 'ISBN',
                    name: 'ISBN',
                    width:100
                });
                var textTahun = new Ext.form.TextField({
                    fieldLabel: 'Tahun',
                    name: 'Tahun',
                    width:100
                });
     var doUpdate = function(){
         textID.enable();
         Ext.getCmp('form-rubah-buku').getForm().submit({
             url: path,
             waitMsg: 'Mengubah Data',
             method: 'post',
             success: function(f, a){
                //alert(Ext.encode(a.result));
                Ext.example.msg('Notifikasi', a.result.msg);
                Ext.getCmp('window-update-buku').destroy();
             },
             failure: function(f, a){
                 //alert(Ext.encode(a.result));
                 Ext.example.msg('Notifikasi', a.result.msg);
                 Ext.getCmp('window-update-buku').destroy();
             }
         });
     }
                var formUpdateNewBook = new Ext.form.FormPanel({
                    frame: true,
                    labelAlign: 'left',
                    fileUpload:true,
                    labelWidth: 100,
                    id: 'form-rubah-buku',
                    width:350,
                    waitMsgTarget: true,
                    reader: new Ext.data.XmlReader({record: 'data', success: '@success'}, ['ID', 'Judul', 'Edisi', 'Pengarang', 'Tahun', 'ISBN', 'Lokasi', 'Klasifikasi', 'Penerbit', 'Deskripsi', 'Cp_Or', 'Jenis', 'ID_Master_Buku', 'Bahasa']),
                    items: [
                        new Ext.form.FieldSet({
			autoHeight: true,
			defaultType: 'textfield',
			items: [textIDM, textID, textJudulBuku, textEdisi,textPengarang,textBahasa, textDeskripsi,textJenis,textPenerbit,cmbKlasifikasi,cmbLokasi,textISBN,textTahun,cmbCo,{
                                xtype: 'fileuploadfield',
                                id: 'gambarID',
                                width:200,
                                emptyText: 'Pilih Gambar',
                                fieldLabel: 'Gambar',
                                name: 'gambar',
                                buttonText: 'Lihat'
                            }]
                    })]
		});

                var winUpdateBook = new Ext.Window({
                title: 'Ubah Buku',
                layout:'vbox',
                id: 'window-update-buku',
                width:370,
                height:535,
                closeAction:'close',
                plain: true,
                modal: true,

                items: [formUpdateNewBook],
                buttons: [{
                    text:'Ok',
                    handler: doUpdate
                },{
                    text: 'Cancel',
                    handler: function(){
                        winUpdateBook.destroy();
                    }
                }]
            });
            return winUpdateBook;
    
}