function buatGridKasetAdmin(posKaset, ps){
    var data = buatStore(rootKaset, totalKaset, [ 'ID', 'Judul', 'Jenis', 'Status'], posKaset, true)
    data.setDefaultSort('ID');
    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [
                {header: 'ID CD/DVD', dataIndex: 'ID', width: 80},
                {header: 'Judul CD/DVD', dataIndex: 'Judul', width: 360},
                {header: 'Jenis CD/DVD', dataIndex: 'Jenis', width: 80, editor: new Ext.form.TextField({allowBlank: false})},
                {header: 'Status CD/DVD', dataIndex: 'Status'}]
    });
    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['ID', 'ID'], ['Judul', 'Judul'], ['Jenis', 'Jenis'], ['Status', 'Status']]
        });
    var tb = buatToolbar('CD/DVD', 'ID', data, store, ps);
    var grid = buatGrid('panel-grid-kaset-admin', data, colModel, tb);
    grid.on('cellclick', function(grid, rowIndex){
        var record = grid.getStore().getAt(rowIndex);  // Get the Record
        var data = record.get('ID');
        var teks = (record.get('Status') == 'Tersedia' ? 'Pinjam' : 'Pesan');
        tampilDetailKasetAdmin(data, teks);
    });
    data.load({start:0});
    return grid;
}