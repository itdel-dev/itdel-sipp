function buatPanelLinkArtikel(store){
    var tab = new Array();
    var i = 0;

    for (i=0; i<store.getCount(); i++){
        var bt = new Ext.Button({text: store.getAt(i).get('Judul'), width: '100%', height: 35, id: store.getAt(i).get('ID')});
        //alert(store.getAt(i).get('ID'));
        tab.push(bt);
    }
    var links = new Ext.Panel({
        title: 'Artikel',
        items:tab,
        autoScroll: true
    });
    return links;
}