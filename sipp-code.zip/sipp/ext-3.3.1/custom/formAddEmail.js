Ext.QuickTips.init();

function showAddEmail(path){
    var subject = new Ext.form.TextField({
                    fieldLabel: 'Subject',
                    name: 'article',
                    width:400
                });
				var isiEmail =  new Ext.form.HtmlEditor({
					width: 800,
					height: 300
				});
                var formAddEmail = new Ext.FormPanel({
                    frame: true,
					url: path,
					id: 'email-form',
                    labelAlign: 'left',
                    labelWidth: 70,
                    width:820,
                    waitMsgTarget: true,
                    items: [
                        new Ext.form.FieldSet({
							autoHeight: true,
							defaultType: 'textfield',
							items: [subject,isiEmail]
                    	})]
				});

                var winAddEmail = new Ext.Window({
                title: 'Tambah Email',
                layout:'vbox',
                width: 840,
                height: 450,
                resizable :false,
                closeAction:'hide',
                plain: true,
				modal: true,

                items: [formAddEmail],
                buttons: [{
                    text:'Ok'
                },{
                    text: 'Cancel',
                    handler: function(){
                        winAddEmail.destroy();
                    }
                }]
            })
    return winAddEmail;
}