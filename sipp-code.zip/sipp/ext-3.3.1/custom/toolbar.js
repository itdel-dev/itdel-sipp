function buatToolbar(text, val, data, store, ps){
    var cb = new Ext.form.ComboBox({
        store: store,
        displayField: 'value',
        editable: false,
        valueField: 'id',
        mode: 'local',
        forceSelection: true,
        triggerAction: 'all',
        emptyText: 'Kriteria',
        width: 100,
        queryParam: 'kriteria',
        value: val
    });
    cb.on('specialkey', function(txt, e){
        if (e.getKey() == e.ENTER){
            cari();
        }
    });
    var tbPag = new Ext.PagingToolbar({
        store: data,
        displayInfo: true,
        afterPageText:'dari {0}',
        beforePageText: 'Hal',
        pageSize: ps,
        autoWidth: true,
        width: 'auto',
        height: 30,
        displayMsg: '{0} - {1} dari {2} '+text,
        emptyMsg: 'Tidak ada ' + text + ' yang tersedia'
    });
    var btCoba = new Ext.Button({text: 'Coba', width: 50});
    var sField = new Ext.form.TextField({width: 100, value: ''});
     sField.on('specialkey', function(txt, e){
        if (e.getKey() == e.ENTER){
            cari();
        }
    });
    var tb = new Ext.Toolbar({
        width: 'auto',
        height: 40,
        items:['Cari:', ' ',sField, cb, btCoba, tbPag]
    });
    btCoba.on('click', function(){
        cari();
    });
    function cari(){
        var paramAkhir = data.lastOptions;
        data.baseParams = data.baseParams || {};
        data.baseParams['value'] = sField.getValue();
        data.baseParams['kriteria'] = cb.getValue();
        data.reload(paramAkhir);
    }
    /*data.on('beforeload', function(t, o){
        alert(Ext.encode(o));
    });*/
    
    return tb;
}
