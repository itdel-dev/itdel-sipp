function getHeaderArtikel(posArtikel){
    var data = new Ext.data.Store({
        reader: new Ext.data.JsonReader({
            root: 'artikel',
            totalProperty: 'jumlahArtikel',
            fields: ['ID', 'Judul']
        }),
        proxy: new Ext.data.HttpProxy({
            url: posArtikel,
            method: 'POST'
        }),
        remoteSort: true
    });
    data.setDefaultSort('ID', 'DESC');
    return data;
}

function getDetailArtikel(){

}