Ext.QuickTips.init();

function showChangePassForm(path){
    var textOldPassword = new Ext.form.TextField({fieldLabel: 'Masukan password lama',inputType: 'password',name: 'passLama', id:'oldPassID', width:250, allowBlank: false, blankText: 'Field harus diisi'});
    var textNewPassword = new Ext.form.TextField({fieldLabel: 'Masukan password baru',inputType: 'password',name: 'passBaru', id:'newPassID', width:250, allowBlank: false, blankText: 'Field harus diisi'});
    var textConfirmPassword = new Ext.form.TextField({fieldLabel: 'Masukan lagi password baru',inputType: 'password',name: 'confirmPassword', id:'confirmPassID', width:250, allowBlank: false, blankText: 'Field harus diisi'});
    textOldPassword.on('specialkey', function(elt, e){if (e.getKey() == e.ENTER)doSubmit()});
    textNewPassword.on('specialkey', function(elt, e){if (e.getKey() == e.ENTER)doSubmit()});
    textConfirmPassword.on('specialkey', function(elt, e){if (e.getKey() == e.ENTER)doSubmit()});
    var idForm = new Ext.form.Hidden({name: 'pengguna', value: Cookies.get('id')});
    var form = new Ext.form.FormPanel({
	id: 'changePass-form',
	url: path,
	border: false,
        labelAlign: 'left',
        labelWidth: 150,
        width: 380,
        height: 150,
	items: [new Ext.form.FieldSet({autoHeight: true,defaultType: 'textfield',items: [idForm, textOldPassword,textNewPassword,textConfirmPassword]})],
	buttons: [{
            text: 'Ganti Password',
            handler: function(){
                doSubmit();
            }
	},{
            text: 'Batal',
            handler: function(){
                Ext.getCmp('changePass-form').getForm().reset();
                Ext.getCmp('window-ganti-password').destroy();
            }
	}]
    });

    var doSubmit = function(){
        if(textNewPassword.getValue() == textConfirmPassword.getValue()){
                    form.getForm().submit({
                        url: path,
                        method: 'post',
                        success: function(form, action){
                            Ext.getCmp('window-ganti-password').destroy();
                            Ext.example.msg('Notifikasi Ganti Password', 'Password telah diganti');
                        },
                        failure: function(frm, action){
                            textOldPassword.setValue('');
                            textOldPassword.focus();
                        },
                        waitMsg: 'Permintaan ganti password sedang diproses'
                    });
                } else {
                    textConfirmPassword.setValue('');
                    textConfirmPassword.focus();
                }
    }
    var win = new Ext.Window({
        title: 'Ganti Password',
	layout: 'fit',
        id: 'window-ganti-password',
        width: 450,
        height: 170,
        closeAction: 'hide',
        modal: true,
        resizable: false,
        items: form
    });
    win.show();
}