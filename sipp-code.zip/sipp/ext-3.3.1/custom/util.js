function buatStore(root, total, list, path, sort){
    var str = new Ext.data.Store({
        reader: new Ext.data.JsonReader({
            root: root,
            totalProperty: total,
            fields: list
        }),
        proxy: new Ext.data.HttpProxy({
            url: path,
            method: 'post'
        }),
        remoteSort: sort
    })
    return str;
}
function showWeb(web){
    document.location.href = web;
}
function buatLinkButton(text, href){
    var bt = new Ext.Button({text: text, width: 120});
    bt.on('click', function(){showWeb(href)});
    return bt;
}
function tampilWindowAksi(aksi){
    var param = {id: aksi}
    var tan = function(res){
        Ext.example.msg('Notifikasi', res.responseText);
        Ext.getCmp('panel-grid-pemesanan-admin').getStore().reload();
    }
    buatWindow('Anda yakin akan menyetujui pemesanan ini?', baseUrl+'transaksi/setujui_pesanan', tan, tan, param);
}
function tampilWindowKembali(pm, jen, id_b){
    var path = baseUrl + 'transaksi/get_denda/'+jen +'/' + id_b + '/' + pm;
    var detail = new Ext.Panel({
        width: 150,
        height: 100,
        preventBodyReset: true,
        autoLoad: path
    });
    var btKem = new Ext.Button({
        text: 'Setuju',
        handler: function(){
            var param = {peminjam: pm, jenis: jen, id: id_b};
            var tan = function(res){
                Ext.example.msg('Notifikasi', res.responseText);
                Ext.getCmp('panel-grid-peminjaman-admin').getStore().reload();
                Ext.getCmp('window-pengembalian-barang').destroy();
            }
            buatWindow('Anda yakin?', baseUrl+'transaksi/kembali_barang', tan, tan, param);
        }
    });
    var btBat = new Ext.Button({
        text: 'Batal',
        handler: function(){
            Ext.getCmp('window-pengembalian-barang').destroy();
        }
    });

    if (Ext.getCmp('window-pengembalian-barang') != undefined)
        Ext.getCmp('window-pengembalian-barang').destroy();
    var win = new Ext.Window({
        title: 'Form Pengembalian Buku',
        layout: 'fit',
        id: 'window-pengembalian-barang',
        items: detail,
        buttons: [btKem, btBat]
    });
    win.show();
}
function tampilWindowHistory(id){
    var panel = new Ext.Panel({
        width: 400,
        height: 350,
        autoScroll: true,
        autoLoad: baseUrl + '/history/get_detail_peminjaman/' + id
    });
    var btTutup = new Ext.Button({text: 'Tutup', width: 100, handler: function(){
        Ext.getCmp('window-history-peminjaman').destroy();
    }});
    if (Ext.getCmp('window-history-peminjaman') != undefined)
        Ext.getCmp('window-history-peminjaman').destroy();
    var win = new Ext.Window({
        title: 'Detil History Peminjaman',
        layout: 'fit',
        items: panel,
        id: 'window-history-peminjaman',
        closeAction: 'close',
        buttons: [btTutup]
    });
    win.show();
}
function tampilWindowPinjam(id, master){
    var dt = new Date();
    dt = dt.add(Date.DAY, 7);
    var temp = dt.format('Y-m-d');
    var text = new Ext.form.TextField({fieldLabel: 'ID Buku', width: 150, name: 'id_bar', allowBlank: false});
    var date = new Ext.form.DateField({editable: false, fieldLabel: 'Tanggal Kembali', width: 150, name: 'tgl_kembali', format: 'Y-m-d', value: temp});
    var hComp = new Ext.form.Hidden({name: 'id_trans', value: id});
    var hMaster = new Ext.form.Hidden({name: 'id_m', value: master});
    var pinjam = function(){
        Ext.getCmp('form-peminjaman').getForm().submit({
            url: baseUrl + 'transaksi/pinjam_barang/',
            method: 'post',
            success: function(f, a){
                Ext.example.msg('Notifikasi', a.result.msg);
                Ext.getCmp('window-konfirmasi-peminjaman').destroy();
                reloadStore('panel-grid-pemesanan-admin');
                reloadStore('panel-grid-peminjaman-admin');
            },
            failure: function(f, a){
                Ext.example.msg('ERROR', a.result.msg);
            }
        });
    }
    var form = new Ext.form.FormPanel({
        height: 120,
        width: 260,
        id: 'form-peminjaman',
        items: [text, date, hComp, hMaster],
        buttons: [{
            text: 'Kirim',
            handler: pinjam
        },{
            text: 'Batal',
            handler: function(){
                Ext.getCmp('window-konfirmasi-peminjaman').destroy();
            }
        }]
    });
    if (Ext.getCmp('window-konfirmasi-peminjaman') != undefined){
        Ext.getCmp('window-konfirmasi-peminjaman').destroy();
    }
    var window = new Ext.Window({
        title: 'Konfirmasi Peminjaman',
        layout: 'fit',
        items: form,
        modal: false,
        id: 'window-konfirmasi-peminjaman',
        closeAction: 'close'
    });
    window.show();
}
function tampilWindowKonfirmasi(bt1, id){
    var f = function(res){Ext.example.msg('Notifikasi', res.responseText)};
    var btBatal = new Ext.Button({
        text: 'Batalkan Pesanan',
        width: 100,
        height: 30,
        handler: function(){
            Ext.getCmp('window-konfirmasi').destroy();
            ajaxReqParams(baseUrl+'transaksi/batal/', f, f, {id: id});
            reloadStore('panel-grid-pemesanan-admin');
        }
    });
    var win = new Ext.Window({
        title: 'Konfirmasi Pemesanan',
        layout: 'hbox',
        id: 'window-konfirmasi',
        width: 210,
        closeAction: 'close',
        modal: true,
        items: [bt1, btBatal]
    });
    win.show();
}
function tampilDetailKasetAdmin(id, teks){
    var panel = new Ext.Panel({
        autoLoad: baseUrl + 'kaset/detail_kaset_admin/' + id,
        autoScroll: true
    });
    var btTeks = new Ext.Button({
        text: teks,
        handler: function(){
            if(Cookies.get('pengguna') == null || Cookies.get('pengguna') == 'null'){
                var handler = function (){
                Ext.getCmp('window-login').show();
                    Ext.getCmp('nameID').focus(false,100);
                }
                tampil_error('Permintaan tidak bisa diproses.<br>Anda Harus Login', 'Error', Ext.MessageBox.ERROR, handler);
            } else {
                //pengguna telah login
                var params = {
                    pemesan: Cookies.get('id'),
                    pesanan: id,
                    jumlah: 1,
                    id: 2
                };
                var path;
                if (teks == 'Pesan'){
                    path = baseUrl + 'pengguna/pesan_kaset/1';
                    pesan_barang(path, params, 'Pemesanan kaset telah diproses');
                    Ext.getCmp('window-detail-kaset-admin').destroy();
                } else if (teks == 'Pinjam'){
                    path = baseUrl + 'pengguna/pesan_kaset/4';
                    pesan_barang(path, params, 'Peminjaman kaset telah diproses');
                    Ext.getCmp('window-detail-kaset-admin').destroy();
                }
            }
        }
    });
    var btHapus = new Ext.Button({
        text: 'Hapus',
        handler: function(){
            var path = baseUrl + 'kaset/hapus';
            var f = function(res){
                Ext.example.msg('Notifikasi', res.responseText);
                Ext.getCmp('window-detail-kaset-admin').destroy();
                reloadStore('panel-grid-kaset-admin');
            }
            buatWindow('Anda yakin menghapus CD/DVD ini?', path, f, f, {id: id});
        }
    });
    var btRubah = new Ext.Button({
        text: 'Rubah',
        handler: function(){
            var path = baseUrl + 'kaset/rubah/';
            var win = showUpdateCD(path);
            Ext.getCmp('form-update-kaset').load({url: baseUrl + 'kaset/get_data_update/' + id});
            win.show();
            Ext.getCmp('window-detail-kaset-admin').destroy();
        }
    });
    if (Ext.getCmp('window-detail-kaset-admin') != undefined)
        Ext.getCmp('window-detail-kaset-admin').destroy();
    var win = new Ext.Window({
        title: '',
        autoDestroy: true,
        width: 400,
        height: 350,
        id: 'window-detail-kaset-admin',
        layout: 'fit',
        items: panel,
        buttons: [btHapus, btRubah, btTeks, new Ext.Button({text: 'Tutup',handler: function(){Ext.getCmp('window-detail-kaset-admin').destroy();}})]
    });
    win.show();
}
function buatWindow(mes, path, tanS, tanF, par){
    Ext.Msg.show({
        title: 'Konfirmasi Persetujuan',
        msg: mes,
        buttons: Ext.MessageBox.YESNOCANCEL,
        fn: function(text){
            if (text == 'yes'){
                ajaxReqParams(path, tanS, tanF, par);
            }
        },
        icons: Ext.MessageBox.QUESTION
    });
}
function buatGrid(idg, data, colModel, tb){
    return new Ext.grid.EditorGridPanel({
        store: data,
        id: idg,
        colModel: colModel,
        viewConfig: {forceFit: true},
        tbar: tb,
        width: 'auto',
        stripeRow: true,
        autoHeight: true,
        height: 'auto',
        autoScroll: true,
        loadMask: true,
        clicksToEdit: 1
    });
}
function cast_angka(text){
    var str = new String(text);
    var number = str.charCodeAt(0) - 48;
    return number;
}
function reloadStore(id){
    var str = Ext.getCmp(id).getStore();
    var param = str.lastOption;
    str.reload(param);
}
function buatLinkTtgPerpus(){
    //Link menuju Peraturan perpus
    var btUserGuide = buatLinkButton('Panduan Pengguna', baseUrl + "userguide");
    //Link menuju User Guide
    var btPeraturan = buatLinkButton('Peraturan Perpustakaan', baseUrl + "rule");
    var btTentangPerpus = new Ext.Button({minWidth:120, text:'Tentang Perpus', menu:[btUserGuide, btPeraturan]});
    return btTentangPerpus;
}