Ext.QuickTips.init();

function showUpdateUser(path){
    var textNI = new Ext.form.TextField({
        fieldLabel : 'Nomor Induk',
        name : 'NI',
        id: 'indukID',
        width : 100
    });
    var textUsername = new Ext.form.Hidden({name: 'Username'});
    var textNama = new Ext.form.TextField({
        fieldLabel : 'Nama',
        name : 'Nama',
        width: 150
    });
    var textEmail = new Ext.form.TextField({
        fieldLabel: 'Email',
        name: 'Email',
        id: 'emailID',
        width:200
    });
    var textNoHP= new Ext.form.TextField({
        fieldLabel : 'No. HP',
        name : 'No_HP',
        width: 100
    });
    var textAlamat = new Ext.form.TextArea({
        fieldLabel:'Alamat',
        name : 'Alamat',
        height : 50,
        width : 200
    });
    var cmbStatus = new Ext.form.ComboBox({
        fieldLabel: 'Status',
        name: 'Status',
        store: new Ext.data.ArrayStore({
            fields: ['id', 'value'],
            data: [['Akfit', 'Aktif'], ['Tidak Aktif', 'Tidak Aktif']]
        }),
        forceSelection: true,
        mode: 'local',
        displayField: 'value',
        triggerAction: 'all',
        width: 150
    });
    var textBatasBuku = new Ext.form.TextField({
        fieldLabel: 'Batas Buku',
        name: 'Batas_Buku',
        id:'jlhID',
        width:50
    });
    var formUpdateUser = new Ext.form.FormPanel({
        frame: true,
        reader: new Ext.data.XmlReader({record: 'data', success: '@success'}, ['Username', 'NI', 'Nama', 'Alamat', 'No_HP', 'Status', 'Email', 'Batas_Buku']),
        id: 'form-update-pengguna',
        labelAlign: 'left',
        labelWidth: 100,
        width:350,
        height: 450,
        autoScroll: true,
        waitMsgTarget: true,
        items: [textUsername,textNI,textNama,cmbStatus,textEmail,textAlamat,textNoHP,textBatasBuku]
    });

    var winUpdateUser = new Ext.Window({
        title: 'Rubah Pengguna',
        layout:'vbox',
        width:370,
        height:350,
        closeAction:'close',
	modal: true,
        items: [formUpdateUser],
        buttons: [{
                text:'Ok',
                handler: function(){
                    formUpdateUser.getForm().submit({
                        url: path,
                        method: 'post',
                        success: function(f, a){
                            Ext.example.msg('Notifikasi berhasil', a.result.msg);
                            winUpdateUser.destroy();
                            reloadStore('panel-grid-pengguna');
                        },
                        failure: function(f, a){
                            Ext.example.msg('Notifikasi gagal', a.result.msg);
                            winUpdateUser.destroy();
                        }
                    });
                }
            },{
                text: 'Cancel',
                handler: function(){
                    winUpdateUser.destroy();
                }
            }]
        });
        return winUpdateUser;
    
}