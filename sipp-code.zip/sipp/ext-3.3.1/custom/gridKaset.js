function buatGridKaset(posKaset, ps){
    var data = buatStore(rootKaset, totalKaset, ['ID', 'Judul', 'Jenis', 'Status'], posKaset, true)
    data.setDefaultSort('ID');
    var colModel = new Ext.grid.ColumnModel({
            defaults:{width: 120, sortable: true},
            columns: [{header: 'No CD/DVD', dataIndex: 'ID', width: 80},
                {header: 'Judul CD/DVD', dataIndex: 'Judul', width: 360},
                {header: 'Jenis CD/DVD', dataIndex: 'Jenis'},
                {header: 'Status CD/DVD', dataIndex: 'Status'}]
    });
    var store = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields:['id', 'value'],
            data:[['ID', 'ID'], ['Judul', 'Judul'], ['Jenis', 'Jenis']]
        });
    var tb = buatToolbar('Kaset', 'Judul', data, store, ps);

    var grid = buatGrid('panel-grid-kaset', data, colModel, tb);

    grid.on('cellclick', function(grid, rowIndex){
        var record = grid.getStore().getAt(rowIndex);  // Get the Record
        var data = record.get('ID');
        var teks = (record.get('Status') == 'Tersedia' ? 'Pinjam' : 'Pesan');
        //showDetailKaset(elmt, teks, data)
        showDetailKaset(data, teks);
    });
    data.load({start:0});
    return grid;
}