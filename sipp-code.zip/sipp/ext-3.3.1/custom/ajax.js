function ajaxReq(path, scBack, fcBack){
    Ext.Ajax.request({
    url: path,
    method: 'POST',
    success: scBack,
    failure: fcBack
   });
}

function ajaxReqParams(path, scBack, fcBack, params){
    Ext.Ajax.request({
        url: path,
        method: 'POST',
        success: scBack,
        failure: fcBack,
        params: params
   });
}