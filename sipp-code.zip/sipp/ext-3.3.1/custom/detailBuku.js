function tampil_pesan(text, judul, ico){
    Ext.example.msg(judul, text);
    perbaharuiWindowInfo();
}

function tampil_error(text, judul, ico, handler){
	Ext.Msg.show({
			title: judul,
			msg: text,
			buttons: Ext.MessageBox.OK,
			icon: ico,
			fn: handler
	});
}

function pesan_barang(path, params, pesan){
    var sf;
    var ff;
    
    sf = function(res){
        tampil_pesan(pesan, 'Notifikasi Pesanan', Ext.MessageBox.INFO);
    }
    ff = function(res){Ext.Msg.alert(res.responseText);}
    ajaxReqParams(path, sf, ff, params);
}

function showDetailBuku(elmt, teks, data, trans){
    if (Ext.getCmp('window-trans-buku') != undefined){
        Ext.getCmp('window-trans-buku').destroy();
    }
    var form = new Ext.form.FormPanel({
        width:500,
        height:50,
        autoDestroy: true,
        buttons:[{text: teks,
                handler: function(){
                    //konfirmasi pemesanan ataupun peminjaman
                    if(Cookies.get('pengguna') == null || Cookies.get('pengguna') == 'null'){
                        var handler = function (){
                            Ext.getCmp('window-login').show();
                            Ext.getCmp('nameID').focus(false,100);
                        }
                        tampil_error('Permintaan tidak bisa diproses.<br>Anda Harus Login', 'Error', Ext.MessageBox.ERROR, handler);
                    }else if(trans){
                        var path = baseUrl + 'pengguna/is_batas_buku/' + Cookies.get('id');
                        var suc = function (response){
                            if(response.responseText == 'TRUE'){
                                //simpan data transaksi
                                var params = {pemesan: Cookies.get('id'),pesanan: data,jumlah: 1,id: 1};
                                var path;
                                if (teks == 'Pesan'){
                                    path = baseUrl + 'pengguna/pesan_buku/1';
                                    pesan_barang(path, params, 'Pemesanan buku telah diproses');
                                } else if (teks == 'Pinjam'){
                                    path = baseUrl + 'pengguna/pesan_buku/4';
                                    pesan_barang(path, params, 'Peminjaman buku telah diproses');
                                }
                            } else {
                                tampil_error('Jumlah pesanan dan pinjaman ' + response.responseText, 'Jumlah Maksimal',Ext.MessageBox.WARNING, null);
                            }
                        }
                        ajaxReq(path, suc);
                    } else Ext.example.msg('Notifikasi', 'Buku tidak bisa dipinjam/dipesan');
                    Ext.getCmp('window-trans-buku').destroy();
                }
            },{text: 'Batal', handler: function(){
                Ext.getCmp('window-trans-buku').destroy();
            }}]
    });

    var element = new Ext.Panel({
        width: 500,
        height: 500,
        layout: 'fit',
        bodyStyle: 'padding: 5 5',
        html: elmt,
        autoScroll:true
    });
    var win = new Ext.Window({
        layout: 'vbox',
        title: 'Window Transaksi Buku',
        id: 'window-trans-buku',
        width: 520,
        height: 580,
        closeAction: 'hide',
        modal: true,
        resizable: true,
        items: [element, form]
    });

    win.show();
}