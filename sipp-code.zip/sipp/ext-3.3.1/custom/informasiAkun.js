function buatInformasiAkun(){
    var paneInfoPengguna = new Ext.Panel({
            title: 'Informasi Akun Anda',
            id: 'info-pengguna',
            layout: 'vbox',
            items:[
                new Ext.form.Label({id:'teks-sambutan', text:'Selamat Datang ' + Cookies.get('nama_pengguna'), height: 30, cls:'teks-panel-sambutan'}),
                new Ext.Button({id:'tombol-info-pinjam',text:'Bahan-bahan pustaka yang ' + Cookies.get('nama_pengguna') + ' pinjam', height: 30, cls:'tombol-panel-pinjam'}),
                new Ext.Button({id:'tombol-info-pesan', text:'Bahan-bahan pustaka yang ' + Cookies.get('nama_pengguna') + ' pesan', height: 30, cls:'tombol-panel-pesan'}),
                new Ext.Button({id:'tombol-info-pesan-cepat', text:'Bahan-bahan pustaka yang harus diambil hari ini' , height: 30, cls:'tombol-panel-pesan-cepat'})],
            hidden: false
    });
    return paneInfoPengguna;
}
function setAksiTombol(path, judul){
    hancurkanWindowInfo();
    var pathInfo = path;
    showWindowInfo(pathInfo, judul);
}
function setAksiTombolAkun(idt, path, judul){
    Ext.getCmp(idt).on('click', function(){
            setAksiTombol(path, judul);
    });
}