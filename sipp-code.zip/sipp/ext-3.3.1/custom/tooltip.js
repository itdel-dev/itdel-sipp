 function initTips(){
    new Ext.ToolTip({
        target: 'teks-info-pesan',
        autoHide: false,
        closable: true,
        width: '100',
        html: 'test telur'
    });
 }