function showDetailKaset(id, teks){
    var panel = new Ext.Panel({
        autoLoad: baseUrl + 'kaset/detail_kaset_admin/' + id,
        autoScroll: true
    });
    var btTeks = new Ext.Button({
        text: teks,
        handler: function(){
            if(Cookies.get('pengguna') == null || Cookies.get('pengguna') == 'null'){
                var handler = function (){
                Ext.getCmp('window-login').show();
                    Ext.getCmp('nameID').focus(false,100);
                }
                tampil_error('Permintaan tidak bisa diproses.<br>Anda Harus Login', 'Error', Ext.MessageBox.ERROR, handler);
            } else {
                //pengguna telah login
                var params = {
                    pemesan: Cookies.get('id'),
                    pesanan: id,
                    jumlah: 1,
                    id: 2
                };
                var path;
                if (teks == 'Pesan'){
                    path = baseUrl + 'pengguna/pesan_kaset/1';
                    pesan_barang(path, params, 'Pemesanan kaset telah diproses');
                    Ext.getCmp('window-detail-kaset-admin').destroy();
                } else if (teks == 'Pinjam'){
                    path = baseUrl + 'pengguna/pesan_kaset/4';
                    pesan_barang(path, params, 'Peminjaman kaset telah diproses');
                    Ext.getCmp('window-detail-kaset-admin').destroy();
                }
            }
        }
    });
    if (Ext.getCmp('window-detail-kaset-admin') != undefined)
        Ext.getCmp('window-detail-kaset-admin').destroy();
    var win = new Ext.Window({
        title: 'Detail CD/DVD',
        autoDestroy: true,
        width: 400,
        height: 350,
        id: 'window-detail-kaset-admin',
        layout: 'fit',
        items: panel,
        buttons: [btTeks, new Ext.Button({text: 'Tutup',handler: function(){Ext.getCmp('window-detail-kaset-admin').destroy();}})]
    });
    win.show();
}