<?php
require_once(dirname(__FILE__).'/crudable_model.php');

class App_Model extends Model implements Crudable_Model{
    var $_model_name = NULL;
    var $_table_name = NULL;
	
    function App_Model() {
        parent::Model();
        date_default_timezone_set('Asia/Jakarta');
    }

    /**
     * blok setter dan getter
     */
    public function set_model_name($model_name = NULL) {
        $this->_model_name = $model_name;
    }
	
    public function get_model_name() {
        return ($this->_model_name);
    }
	
    public function set_table_name($table_name = NULL) {
        $this->_table_name = $table_name;
    }
	
    public function get_table_name() {
        return ($this->_table_name);
    }
    //akhir blok setter dan getter

    //BLOK method tambahan
    public function call_procedure($procedure_name = NULL, $arguments = array()){
		$sql = '';
		$sql .= 'CALL ';
		$sql .= $procedure_name;
		$escaped_arguments = array();
		$question_marks = array();
		foreach($arguments as $argument){
			if(is_string($argument)){
				$escaped_arguments[] = $this->db->escape($argument);
			}else{
				$escaped_arguments[] = $argument;
			}
			$question_marks[] = '?';
		}
		$sql .= ('(' . implode(', ', $escaped_arguments) . ')');
		return($this->db->query($sql));
    }

    public function call_function($func_name, $params=array(), $alias='fn'){
        $sql = 'SELECT ' . $func_name;
        $args = array();
        foreach($params as $v){
            if (is_string($v)){
                $args[] = $this->db->escape($v);
            } else {
                $args[] = $v;
            }
        }
        $sql .= '(' . implode(', ', $args) . ') AS ' . $alias;
        return $this->db->query($sql);
    }

    //Mengembalikan jumlah record pada tabel model
    function getJumlahTotal(){
	$hasil = $this->db->get($this->_table_name);
	return $hasil->num_rows();
    }

    function get_waktu_skrg(){
        $waktu = getdate();
        $tgl = $this->get_tgl_skrg() . ' ' . $waktu['hours'] . ':' . $waktu['minutes'] . ':' . $waktu['seconds'];
        return $tgl;
    }

    static function eksekusi($qry){
        $ci = &get_instance();
        $hasil = $ci->db->query($qry);
        if (is_object($hasil)){
            $temp = array('jumlah'=>$hasil->num_rows());
            if ($temp['jumlah'] > 0){
                $temp['data'] = array();
                foreach ($hasil->result_array() as $rows){
                    $temp['data'][] = $rows;
                }
            }
            return $temp;
        }
    }

    function get_tgl_skrg(){
        $waktu = getDate();
        $tgl = $waktu['year'] . '-' . $waktu['mon'] . '-' . $waktu['mday'];
        return $tgl;
    }

    //Akhir blok method tambahan

        //blok overriden method
        public function tambah($field){
            if (is_array($field))
                $this->add_record($field);
        }
        
        public function rubah($fields, $kriteria){
            $this->update_record($fields, $kriteria);
        }
        public function hapus($kriteria){
            if(is_array($kriteria))
                $this->delete_record($kriteria);
        }
        public function baca($fields=NULL, $kriteria=Array(), $sorting=NULL, $mulai=0, $selesai=0){
            $hasil = $this->get($fields, $kriteria, $sorting, $mulai, $selesai);
            return $hasil;
        }
        public function baca_where($fields = NULL, $kriteria=Array(), $mulai=0, $selesai=0){
            $this->set_field_from($fields);
            $this->db->where($this->toWhere($kriteria));
            return $this->db->get();
        }
        //akhir blok overriden method

        /**
         * Mengambil seluruh field dari tabel yang sesuai dengan kriteria
         * @param mixed $fields, field-field yang akan diambil dari database
         * @param array $kriteria, kriteria yang digunakan pada where klause
         * @return resultset
         */
        public function baca_detail($fields=NULL, $kriteria=Array()){
            return $this->get_detail($fields, $kriteria);
        }

        /**
         * Melakukan join 2 buah tabel dan memilih record-record yang diinginkan
         * @param string $tabel, nama tabel ke-2
         * @param string $on, field yang menjadi patokan untuk join
         * @param string $tipe, tipe join yang digunakan, default value inner join
         * @param mixed $fields, field-field yang akan diambil
         * @param array $kriteria, kriteria yang akan digunakan pada where klause
         * @return resultset
         */
        public function baca_komplit($tabel, $on, $tipe='inner', $fields = NULL, $kriteria=NULL){
            $this->set_field_from($fields);
            $this->db->join($tabel, $on, $tipe);
            $this->db->where($this->toWhere($kriteria), NULL, FALSE);
            return $this->db->get();
        }

        public function baca_join($tabel, $on, $fields, $order = NULL, $kriteria = NULL, $mulai=0, $akhir=0, $tipe='INNER'){
            $this->set_field_from($fields);
            $this->db->join($tabel, $on, $tipe);
            if($kriteria) $this->db->where($this->toWhere($kriteria), NULL, FALSE);
            $this->set_order_limit($order, $mulai, $akhir);
            return $this->db->get();
        }

        /**
         * Mengambil nilai sebuah field pada sebuah tabel
         * @param string $field, nama field yang akan diambil
         * @param array $kriteria, kriteria yang akan digunakan pada where klause
         * @return string, nilai dari field yang diinginkan
         */
        public function baca_field($field, $kriteria=Array()){
            $hasil = $this->baca_detail($field, $kriteria);
            $hasil = $hasil->row_array();
            return (count($hasil) > 0) ? $hasil[$field] : NULL;
        }

        /**
         *
         * @param mixed $field, field-field yang akan diambil
         * @param array $kriteria, kriteria yang akan digunakan pada where klause
         * @return numeric, jumlah record yang dipilih sesuai dengan kriteria
         */
        public function baca_total_field($field, $kriteria=Array()){
            $hasil = $this->baca_detail($field, $kriteria);
            $hasil = $hasil->row_array();
            return $hasil[$field];
        }

        /**
         * Mengambil jumlah field pada resultset $result
         * @param resultset $result, hasil dari eksekusi query select
         * @return numeric, jumlah record pada $result
         */
        public function ambil_total($result){
            return $result->num_rows();
        }

        public function ambil_field($result, $field){
            $hasil = $result->row_array();
            return $hasil[$field];
        }


    /**
		Blok private method
		Method yang hanya digunakan dari dalam class ini
	*/
	
    /*
	* this method is incredibly simple!
	* any retrieval may be done just by invoking this method.
	* the first argument defines selected fields.
	* the second argument defines the search criterias.
	* the third and fourth for limiting records.
	* for example, if we have a table called my_table('id', 'name', 'accepted_date', 'address', 'phone') and assume if there are about a hundred record persisted
	* then if we want to retrieve all records ['id' and 'name'] and has 'name' = 'uriel' and 'accepted_date' = '06/07/2010'
	* start from record number 21 and return 30 first met record then we write:
	* my_table->get(
	*	array(	// set the retrieval field
	*		'id',
	*		'name',
	*	),
	*	array(	// set the search criterias
	*		'name'			=> 'uriel',
	*		'accepted_date'	=> '06/07/2010',
	*	),
	*	30,	// number of return retrieval
	*	20	// start from the record after 20, in otherwords, the record number 21
	* );
	*/
	private function get($fields = NULL, $criterias = array(), $sorting = NULL, $offset = 0, $limit = 0){
            $this->set_field_from($fields);
            if(is_array($criterias)){    
                $this->db->like($criterias);
            }
            $this->set_order_limit($sorting, $offset, $limit);
            $hasil = $this->db->get();
            return ($hasil);
	}

        private function get_detail($fields = NULL, $criterias = array()){
            $this->set_field_from($fields);
            if(is_array($criterias)){
                $this->db->where($criterias);
            }
            $hasil = $this->db->get();
            return ($hasil);
        }

        private function toWhere($kriteria){
            $sql = '';
            $batas = count($kriteria);
            $index = 0;
            foreach ($kriteria as $k=>$v){
                $index ++;
                $delim = ' AND ';
                if ($v == NULL){
                    $sql .= $k . ' IS NULL ' . $v;
                } else {
                    if(is_array($v)){
                        if (count($v) == 3){
                            $delim = $v[2];
                        }
                        $sql .= $k . " {$v[0]} " . $v[1];
                    } else $sql .= $k . " = '$v'";
                }
                if($index < $batas){
                    $sql .= $delim;
                }
            }
            return $sql;
        }

        private function is_perbandingan($opr){
            return ($opr == '<' || $opr == '>' || $opr == '>=' || 'opr' == '<=' || $opr == '=');
        }

        /**
         * Menset nilai dari field yang akan dipilih dan tabel sumber
         * @param mixed $fields, nama-nama field yang akan dipilih
         */
        private function set_field_from($fields){
            if(is_array($fields)){
                $sql = implode(', ', $fields);
                $this->db->select($sql);
            } else if($fields != NULL){
                $this->db->select($fields, FALSE);
            }
            $this->db->from($this->_table_name);
        }

         /**
         * Menset nilai dari order by klause dan limit klause dari sql.
         * @param array $sorting, array yang berisi field pengurutan dan arah pengurutan
         * @param integer $offset, indek pertama dimana record akan mulai diambil
         * @param integer $limit, indek akhir batas record akan diambil.
         */
        private function set_order_limit($sorting = NULL, $offset=0, $limit=0){
            if (is_array($sorting)){
                    $this->db->order_by($sorting[0], $sorting[1]);
                }

            if($limit > 0){
                $this->db->limit($limit,$offset);
            }
        }

        // DELETE
	// the criteria may consists of more than one, in an array
	// the criteria
	private function delete_record($criterias = NULL){
		$sql = 'DELETE FROM ' . $this->get_table_name();
//		print_r($criterias);

		if(is_array($criterias)){
			$arr_criteria = array();
			$keys = array_keys($criterias);
			foreach($keys as $key){
				if(!is_array($criterias[$key])){
					$arr_criteria [] = ($key . '=\'' . $criterias[$key] . '\'');
				}else{
					$arr_criteria [] = ($key . ' IN('. implode(', ', $criterias[$key]) .')');
				}
			}
			$sql .= ' WHERE ' . implode(' AND ', $arr_criteria);
		}
//		echo($sql);
		return ($this->db->query($sql));
	}

        // UPDATE
	// the criteria may consists of more than one, in an array
	// the criteria
	private function update_record($record = NULL, $criterias = NULL){
		if(is_array($criterias) && is_array($record)){
			$keys = array_keys($criterias);
			foreach($keys as $key){
				$this->db->where($key, $criterias[$key]);
			}
			$this->db->update($this->_table_name, $record);
		}
	}

        //ADD
	private function add_record($record = NULL, $tabel = NULL){
		if($record != NULL){
			if ($tabel == NULL){
				$this->db->insert($this->_table_name, $record);
			} else {
				$this->db->insert($tabel, $record);
			}
		}
	}
}

?>
