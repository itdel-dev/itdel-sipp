<?php
/**
 * Description of App_Trans_Model
 *
 * @author Roy Inganta Ginting
 * File   : app_loan_model.php
 * Dibuat : Senin, 23 Mei 2011
 */
require_once(dirname(__FILE__).'/app_model.php');
require_once(dirname(__FILE__).'/loanable_model.php');

class App_Loan_Model extends App_Trans_Model implements Loanable_Model{

    function pinjam($peminjam, $id_cat, $pinjaman){
	
    }

    function selesaiPinjam($peminjam, $id_cat, $item){
		
    }
	
}
?>
