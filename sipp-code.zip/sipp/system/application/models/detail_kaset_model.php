<?php
/***
 * @author Roy Inganta Ginting
 * File      : detail_kaset_model.php
 * Tipe      : Model
 * depedensi : app_loan_model.php
 * Dibuat    : Minggu, 23 Mei 2011
 * Deskripsi : Class yang menampung seluruh data detail buku, melakukan proses pengambilan detail buku dari database sehingga menjadi
 * jembatan bagi controller buku untuk memperoleh detail data buku dari database.
 * 
 */

require_once(dirname(__FILE__).'/app_trans_model.php');

class Detail_Kaset_Model extends App_Trans_Model {

    function Detail_Kaset_Model() {
        parent::App_Trans_Model();
        $this->set_model_name('Detail_Kaset');
        $this->set_table_name('t_d_kaset');
    }

}
?>
