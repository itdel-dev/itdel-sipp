<?php
/***
 * @author Roy Inganta Ginting
 * File      : detail_denda_model.php
 * Tipe      : Model
 * depedensi : app_model.php
 * Dibuat    : Senin, 23 Mei 2011
 * 
 */

require_once(dirname(__FILE__).'/app_model.php');

class Detail_Denda_Model extends App_Model {

    function Detail_Denda_Model() {
        parent::App_Model();
        $this->set_model_name('Detail_Denda');
        $this->set_table_name('t_d_denda');
    }

}
?>
