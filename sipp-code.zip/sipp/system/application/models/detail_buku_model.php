<?php
/***
 * @author Roy Inganta Ginting
 * File      : detail_buku_model.php
 * Tipe      : Model
 * depedensi : app_loan_model.php
 * Dibuat    : Minggu, 23 Mei 2011
 * Deskripsi : Class yang menampung seluruh data detail buku, melakukan proses pengambilan detail buku dari database sehingga menjadi
 * jembatan bagi controller buku untuk memperoleh detail data buku dari database.
 * 
 */

require_once(dirname(__FILE__).'/app_trans_model.php');

class Detail_Buku_Model extends App_Trans_Model{

    function Detail_Buku_Model() {
        parent::App_Trans_Model();
        $this->set_model_name('Detail_Buku');
        $this->set_table_name('t_d_buku');
        $this->set_header(new Pesan_Pinjam_Model());
        $this->set_detail_pesan(new Detail_Pemesanan_Model());
        $this->set_detail_pinjam(new Detail_Peminjaman_Model());
    }

}
?>
