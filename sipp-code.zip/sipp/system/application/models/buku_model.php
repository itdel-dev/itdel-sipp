<?php
/***
 * @author Roy Inganta Ginting
 * File      : buku_model.php
 * Tipe      : Model
 * depedensi : app_order_model.php
 * Dibuat    : Selasa, 10 Mei 2011 11:39
 * Deskripsi : Class yang menampung seluruh data buku, melakukan proses pengambilan buku dari database sehingga menjadi
 * jembatan bagi controller buku untuk memperoleh data buku dari database.
 * 
 */

require_once(dirname(__FILE__).'/app_trans_model.php');
require_once(dirname(__FILE__).'/pesan_pinjam_model.php');
require_once(dirname(__FILE__).'/detail_pemesanan_model.php');
require_once(dirname(__FILE__).'/detail_peminjaman_model.php');

class Buku_Model extends App_Trans_Model {

    function Buku_Model() {
        parent::App_Trans_Model();
        $this->set_model_name('Buku');
        $this->set_table_name('t_m_buku');
        $this->set_header(new Pesan_Pinjam_Model());
        $this->set_detail_pesan(new Detail_Pemesanan_Model());
        $this->set_detail_pinjam(new Detail_Peminjaman_Model());
    }

}
?>
