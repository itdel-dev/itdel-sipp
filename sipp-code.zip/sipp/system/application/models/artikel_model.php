<?php
/**
 * Description of artikel_model
 *
 * @author Roy Inganta Ginting
 * File   : artikel_model.php
 * tipe   : Model
 * Dibuat : Rabu 25 Mei 2011, 11:44
 *
 */

require_once(dirname(__FILE__).'/app_model.php');
class Artikel_Model extends App_Model{

    function Artikel_Model(){
        parent::App_Model();
        $this->set_model_name('Artikel');
        $this->set_table_name('t_m_artikel');
    }
}
?>
