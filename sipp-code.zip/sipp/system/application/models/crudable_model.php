<?php

/**
 *
 * @author Roy Inganta Ginting
 * Dibuat : Sabtu, 21 Mei 2011, 14:44
 * File   : crudable.php
 * Interface yang mendefinisikan fungsi-fungsi untuk proses CRUD (Create, Read, Update, Delete).
 * fungsi-fungsi yang di dukung yaitu:
 *  1. tambah, menambah record baru ke dalam tabel
 *  2. rubah, merubah record tertentu pada tabel
 *  3. hapus, menghapus record tertentu dari tabel
 *  4. baca, mengembalikan tabel yang sesuai
 */
interface Crudable_Model {

    /**
     * Menambah record baru ke dalam tabel.
     * @param array $field, Array yang berisi pasangan nama field dan data yang akan diinsert.
     */
    public function tambah($field);


    /**
     * Merubah record tertentu pada tabel.
     * @param array $fields, array yang berisi pasangan nama field dan nilai baru dari field tersebut.
     * @param array $kriteria, array yang berisi pasangan nama field dan nilai yang akan digunakan untuk memfilter
     *        recordset yang akan dirubah.
     */
    public function rubah($fields, $kriteria);


    /**
     * Menghapus record tertentu dari tabel
     * @param array $kriteria, berisi pasangan nama field dan value yang akan digunakan pada where clause.
     */
    public function hapus($kriteria);

    
    /**
     * Mengembalikan record-record tertentu dari tabel.
     * @param array $fields, berisi field-field yang akan dimbil dari tabel. Default NULL yang berari * pada sql.
     * @param array $kriteria, berisi pasangan nama field dan value yang akan digunakan pada where clause.
     *        Default Array kosong yang berarti tidak ada filter yang dilakukan terhadap tabel.
     * @param integer $mulai, index awal dimana record akan mulai diambil, default 0.
     * @param integer $selesai, index akhir dimana record akan selesai diambil, default 0.
     */
    public function baca($fields=NULL, $kriteria=Array(), $sorting=NULL, $mulai=0, $selesai=0);

}
?>
