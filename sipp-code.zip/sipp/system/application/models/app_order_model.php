<?php
/**
 * Description of App_Trans_Model
 *
 * @author Roy Inganta Ginting
 * File		 : app_order_model.php
 * depedensi : app_model.php dan orderable_model.php
 * Dibuat	 : Senin 23 Mei 2011
 */
require_once(dirname(__FILE__).'/app_trans_model.php');
require_once(dirname(__FILE__).'/orderable_model.php');

class App_Order_Model extends App_Trans_Model implements Orderable_Model{

    function App_Order_Model(){
        parent::App_Trans_Model();
    }

    function pesan($pemesan, $id_cat, $pesanan, $jumlah = 1){
	//bentuk array yang berisi data yang akan dimasukan ke tabel header
	$data_header = array();
	//tambah field pada tabel header
	$this->add_record($id);
    }

    function batal_pesan($pemesan, $id_cat, $item, $jumlah = 1){
	
    }

	
}
?>
