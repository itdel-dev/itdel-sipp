<?php
/***
 * @author Roy Inganta Ginting
 * File      : Admin_Model.php
 * Tipe      : Model
 * depedensi : app_model.php
 * Dibuat    : Minggu, 23 Mei 2011
 * 
 */

require_once(dirname(__FILE__).'/app_model.php');

class Admin_Model extends App_Model {

    function Admin_Model() {
        parent::App_Model();
        $this->set_model_name('Admin');
        $this->set_table_name('t_d_admin');
    }

}
?>
