<?php
/**
 * Description of App_Trans_Model
 *
 * @author Roy Inganta Ginting
 * File   : app_trans_model.php
 * Dibuat : Senin, 23 Mei 2011
 */
require_once(dirname(__FILE__).'/app_model.php');
require_once(dirname(__FILE__).'/loanable_model.php');
require_once(dirname(__FILE__).'/orderable_model.php');

abstract class App_Trans_Model extends App_Model implements Loanable_Model, Orderable_Model{
    //override method dari interface Transactional_Model
	var $_header = NULL; //model untuk header
	var $_detail_pesan = NULL; //model untuk detail pemesanan
        var $_detail_pinjam = NULL; //model untuk detail peminjaman
	
	public function App_Trans_Model(){
            parent::App_Model();
	}

	public function get_header(){
            return $this->_header;
	}

	public function get_detail_pesan(){
            return $this->_detail_pesan;
	}

        public function get_detail_pinjam(){
            return $this->_detail_pinjam;
	}

	public function set_header($header){
            $this->_header = $header;
	}

	public function set_detail_pesan($detail){
            $this->_detail_pesan = $detail;
	}

        public function set_detail_pinjam($detail){
            $this->_detail_pinjam = $detail;
	}


        //Override method pada interface Orderable_Model
        public function pesan($pemesan, $id_kat, $pesanan, $stat=1, $jumlah = 1) {
            //tambah data header transaksi pemesanan
            //kode untuk pemesanan adalah 1
           $pengguna = (int)$pemesan;
           $jenis = (int)$id_kat;
           $id = (int)$pesanan;
           $jumlah = (int)$jumlah;
           $stat = (int)$stat;
           $this->call_procedure('pesan_barang', array($pengguna, $jenis, $id, $jumlah, $stat));
        }

        public function pesan_arr($info){
            $pemesan = $info['pemesan'];
            $id_kat = $info['jenis'];
            $pesanan = $info['pesanan'];
            $jumlah = $info['jumlah'];
            $stat = $info['stat'];
            $this->pesan($pemesan, $id_kat, $pesanan, $stat, $jumlah);
        }

        public function  batal_pesan($pemesan, $id_kat, $pesanan, $jumlah = 1) {
            //ambil id detail pemesanan
            $data = array('ID_Status'=>3 );
            $this->_header->rubah();
        }

        //Override method pada interface loanable_model
        public function pinjam($peminjam, $id_kat, $pinjaman, $kembali, $jumlah = 1){
            //tambah data header transaksi peminjaman
            //kode untuk pemesanan adalah 2
            $hasil = 'GAGAL';
            $this->db->trans_begin();
            if($this->tambah_header($peminjam, 2, $jumlah)){
                if($this->tambah_pinjaman($peminjam, $pinjaman, $kembali, $id_kat, $jumlah)){
                    $this->db->trans_commit();
                    $hasil = 'BERHASIL';
                } else $this->db->trans_rollback();
            } else {
                $this->db->trans_rollback();
            }
            echo $hasil;
        }

        public function selesai_pinjam($peminjam, $id_kat, $pinjaman, $jumlah = 1){
            ;
        }

        private function isKosong($tlink, $on, $kriteria){
            $hasil = $this->_header->baca_komplit($tlink, $on, 'INNER', 'COUNT(*)', $kriteria);
            $hasil = $this->ambil_field($hasil, 'COUNT(*)');
            return $hasil == 0 ? TRUE : FALSE;
        }
        
	/**
	 * Memasukan data header transaksi ke dalam tabel header. Proses update akan dilakukan jika transaksi telah dilakukan sebelumnya.
	 * @param integer $pemesan, id dari pemesan
         * @param numeric $id_tran, id dari kategori barang yang dipesan
         * @param integer $jumlah, jumlah barang yang dipesan.
	 */
	private function tambah_header($pemesan, $id_tran, $jumlah){
            $id = $this->get_id_skrg($pemesan, $id_tran);
            if($id == NULL){
                $data = array('Tgl_Transaksi'=>$this->get_tgl_skrg(), 'Jumlah_Barang'=>$jumlah, 'ID_Jenis'=>$id_tran, 'ID_Pengguna'=>$pemesan);
                $this->_header->tambah($data);
                return true;
            } else {
                $jum = $this->_header->baca_field('Jumlah_Barang', array('ID'=>$id));
                $this->_header->rubah(array('Jumlah_Barang'=> $jum+$jumlah), array('ID'=> $id));
                return true;
            }
	}

        //Memasukan detail transaksi pemesanan
        private function tambah_pesanan($pemesan, $pesanan, $id_kat, $jumlah){
            $on = 't_t_pesan_pinjam.ID = t_d_pemesanan.ID_Trans_Pemesanan';
            $krit = array('t_t_pesan_pinjam.ID_Pengguna'=>$pemesan, 't_t_pesan_pinjam.ID_Jenis'=>1,
                    't_d_pemesanan.ID_Master_Barang'=>$pesanan, 'ID_Referensi_Kategori'=>$id_kat);
            $id = $this->get_id_skrg($pemesan, 1);

            if($this->isKosong('t_d_pemesanan', $on, $krit)){
                $data = array('ID'=>NULL, 'ID_Status'=>1, 'Tgl_Ganti_Status'=>$this->get_waktu_skrg(),
                    'Jumlah_Barang'=>$jumlah, 'ID_Referensi_Kategori'=>$id_kat, 'ID_Trans_Pemesanan'=>$id,
                    'ID_Master_Barang'=>$pesanan);
                $this->_detail_pesan->tambah($data);
                return true;
            } else {
                return false;
            }
        }

        //Memasukan detail transaksi peminjaman
        private function tambah_pinjaman($peminjam, $pinjaman, $kembali, $id_kat, $jumlah){
            $on = 't_t_pesan_pinjam.ID = t_d_peminjaman.ID_Trans_Peminjaman';
            $krit = array('t_t_pesan_pinjam.ID_Pengguna'=>$peminjam, 't_t_pesan_pinjam.ID_Jenis'=>2,
                    't_d_peminjaman.ID_Detail_Barang'=>$pinjaman, 'ID_Referensi_Kategori'=>$id_kat,
                    'Tgl_Kembali'=>NULL);

            if($this->isKosong('t_d_peminjaman', $on, $krit)){
                $id = $this->get_id_skrg($peminjam, 2);
                $data = array('ID'=>NULL, 'Tgl_Kembali'=>NULL, 'Rencana_Kembali'=>$kembali,
                    'ID_Trans_Peminjaman'=>$id, 'ID_Detail_Barang'=>$pinjaman, 'ID_Referensi_Kategori'=>$id_kat, 'Jumlah_Barang'=>$jumlah);
                $this->_detail_pinjam->tambah($data);
                return true;
            } else {
                return false;
            }
        }

        //Mengambil id transaksi yang dilakukan oleh $pelaku pada hari ini
        private function get_id_skrg($pelaku, $jenis=NULL){
            $krit = array('ID_Pengguna'=>$pelaku, 'Tgl_Transaksi'=>$this->get_tgl_skrg());
            if($jenis){
                $krit['ID_Jenis'] = $jenis;
            }
            return $this->_header->baca_field('ID', $krit);
        }
}
?>
