<?php

class App_Controller extends Controller{

    function App_Controller(){
        parent::Controller();
        $this->load->library('session');
        $this->load->model('App_Model');
        $this->load->model('Pengguna_Model');
        $this->load->model('Peran_Fungsi_Model');
    }

    function get_params(){
        //variabel yang mungkin di post oleh pengguna yaitu: start, limit, value, kriteria, sort, dir
        //Tampung index awal dari kaset yang diminta oleh client.
        $mulai = $this->input->post('start');

        //parameter untuk proses pengurutan
        $sort = $this->input->post('sort');
        $dir = $this->input->post('dir');

        $mulai = (int)$mulai;

        //parameter untuk proses pencarian
        $krit = $this->input->post('kriteria');
        $val = $this->input->post('value');
        return array('d'=>$dir, 'k'=>$krit, 'm'=>$mulai, 's'=>$sort, 'v'=>$val);
    }

    //mengecek apakah pengguna adalah admin
    function is_admin(){
        $global = $this->is_global();
        $turunan = $this->is_turunan();
        return $global || $turunan;
    }

    function is_global(){
        return $this->session->userdata('global');
    }

    function is_turunan(){
        return $this->session->userdata('turunan');
    }

    //mengecek apakah id yang diberikan memiliki hak untuk menjalankan sebuah fungsi
    function berhak($fungsi){
        $hak = false;

        if ($this->is_global()){
            $hak = true;
        } else if ($this->is_turunan()){
            $hak = $this->is_hak($fungsi);
        }
        return $hak;
    }

    function get_id_fungsi($nm_fungsi){
        
        $qry = "SELECT ID FROM t_m_fungsi WHERE Nama_Fungsi = " . $this->db->escape($nm_fungsi);
        $hasil = App_Model::eksekusi($qry);
        $fn = 0;
        if ($hasil['jumlah'] == 1){
           $fn = $hasil['data'][0]['ID'];
        }
        return $fn;
    }

    function is_hak($fn){
        $pengguna = $this->session->userdata('nama');
        $pm = new Pengguna_Model();
        $ppm = new Peran_Fungsi_Model();
        $id = $this->get_id_fungsi($fn);
        $peran = $pm->baca_field("ID_role", array("Username"=>$pengguna));
        $hasil = $ppm->baca_field("ID", array("ID_Fungsi"=>$id, "ID_Role"=>$peran));
        $hasil = $hasil == NULL ? false : true;
        return $hasil;
    }
    function to_xml($tag, $data){
        return "<$tag>$data</$tag>";
    }
}

?>