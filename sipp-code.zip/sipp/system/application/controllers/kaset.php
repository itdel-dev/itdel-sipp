<?php


/***
 * File      : kaset.php
 * Tipe      : Controller
 * Dibuat    : Rabu, 11 Mei 2011 16:50
 * Deskripsi : Class yang menangani operasi yang dilakukan terhadap kaset oleh semua pengguna Sistem Informasi.
 * Operasi yang didukung yaitu:
 *  1. tampil, menampilkan daftar kaset yang tersedia pada perpustakaan.
 *  2. tambah, menambah data kaset baru ke dalam database jika kaset yang akan ditambah belum ada.
 *  3. rubah, merubah data kaset yang dipilih.
 *  4. hapus, menghapus data kaset yang dipilih dari database.Menghapus berarti mengubah jumlah kaset menjadi 0.
 *  5. pesan, melakukan proses administrasi pemesanan kaset. Mengurangi jumlah kaset yang tersedia sebanyak jumlah yang
 *     dipesan (default 1) dan menyimpan log pemesanan pada tabel pemesanan. Pemesanan akan dibatalkan secara otomatis jika
 *     tidak dikonfirmasi setelah jangka waktu yang ditetapkan (1 hari). Pemesanan akan menjadi peminjaman ketika dilakukan
 *     konfirmasi oleh admin dan data pemesanan akan disimpan kembali pada tabel peminjaman.
 *  6. pinjam, melakukan peminjaman kaset.
 *  7. batalPesan, membatalkan pemesanan kaset yang telah dilakukan.
 *  8. detail, menampilkan detail kaset yang diinginkan
 */
require_once(dirname(__FILE__).'/app_controller.php');
class Kaset extends App_Controller{

    function Kaset(){
        parent::App_Controller();
        $this->load->model('Kaset_Model');
        $this->load->model('Detail_Kaset_Model');
        $this->load->helper('url');
    }

    function detail_kaset($id){
        $kaset = new Kaset_Model();
        $fields = array('ID', 'Judul', 'Jenis', 'Jumlah_Kaset', 'Keterangan', 'Jumlah_Pesan', 'Jumlah_Pinjam');
        $hasil = $kaset->baca_detail($fields, array('ID'=>$id));
        $hasil = $hasil->row_array();
        echo "<div>";
        foreach($hasil as $k=>$v){
            if ($k == 'Jumlah_Kaset'){
                $k = 'Jumlah Kaset';
            } else if ($k == 'Jumlah_Pesan'){
                $k = 'Jumlah Pesan';
            } else if ($k == 'Jumlah_Pinjam'){
                $k = "Jumlah Pinjam";
            }
            echo '<span style="font-weight: bold">' .$k . "</span>".":<br>";
            echo $v . "<br><br>";
        }
        echo "</div>";
    }

    function detail_kaset_admin($id){
        $hasil = $this->get_data($id);
        $image = $hasil['Gambar'];
        echo "<center><img src= '".PATH_GAMBAR_CD_DVD."$image' width='120'></img></center>";
        echo "<span style='font-weight: bold'>ID:</span><br>{$hasil['ID']}<br><br>";
        echo "<span style='font-weight: bold'>ID Master CD:</span><br>{$hasil['ID_Master_CD']}<br><br>";
        echo "<span style='font-weight: bold'>Jenis:</span><br>{$hasil['Jenis']}<br><br>";
        echo "<span style='font-weight: bold'>Judul:</span><br>{$hasil['Judul']}<br><br>";
        echo "<span style='font-weight: bold'>Keterangan:</span><br>{$hasil['Keterangan']}<br><br>";
        echo "<span style='font-weight: bold'>Keaslian:</span><br>" . ($hasil['Cp_Or'] == "Cp" ? "Copy" : "Original") ."<br><br>";
        echo "<span style='font-weight: bold'>Tanggal Masuk:</span><br>". ($hasil['Tgl_Masuk'] == NULL ? "Tidak Terdaftar" : $hasil['Tgl_Masuk']) . "<br><br>";
        echo "<span style='font-weight: bold'>Status:</span><br>{$hasil['Status']}<br><br>";
    }

    /**
     * menampilkan data kaset dalam format XML
     * @param string $id id detail dari kaset
     */
    function get_data_update($id){
        header('content-type: text/xml');
        $temp = "";
        $hasil = $this->get_data($id);
        foreach ($hasil as $k=>$v){
            $temp .= $this->to_xml($k, $v);
        }
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        echo "<message success=\"true\">";
        echo "<data>";
        echo $temp;
        echo "</data>";
        echo "</message>";
    }

    /**
     * Mengganti Status kaset menjadi Hapus
     */
    function hapus(){
        if ($this->berhak("Delete Kaset")){
            $kaset = new Detail_Kaset_Model();
            $id = $this->input->post('id');
            $kaset->rubah(array('Status'=>'Hapus'), array('ID'=>$id));
            echo "CD/DVD dengan ID $id telah dihapus";
        } else {
            echo "Anda tidak berhak menghapus CD/DVD $temp";
        }
    }
    function test(){
        $id = '10';
        $judul = 'Judul';
        $ket = 'Keterangan';
        $cpor = 'Cp_Or';
        $jenis = 'Jenis';
        $stat = 'Status';
        $mk = new Kaset_Model();
        $md = new Detail_Kaset_Model();
        $m = $md->baca_field("ID_Master_CD", array("ID"=>$id));
        $mk->rubah(array("Judul"=>$judul, "Keterangan"=>$ket, "Jenis"=>$jenis), array("ID"=>$m));
        //update data detail
        $md->rubah(array("Cp_Or"=>$cpor, "Status"=>$stat), array("ID"=>$id));
    }

    //Merubah data kaset
    function rubah(){
        $hasil = array('success'=>false, 'msg'=>'Server Error');
        if ($this->berhak("Update Kaset")){
            $id = $this->input->post('ID');
            $judul = $this->input->post('Judul');
            $ket = $this->input->post('Keterangan');
            $cpor = $this->input->post('Cp_Or');
            $jenis = $this->input->post('Jenis');
            $stat = $this->input->post('Status');
            //$hasil['msg'] = $id . $judul . $ket .$cpor .$jenis .$stat;
            //update data master
            $mk = new Kaset_Model();
            $md = new Detail_Kaset_Model();
            $m = $md->baca_field("ID_Master_CD", array("ID"=>$id));
            $mk->rubah(array("Judul"=>$judul, "Keterangan"=>$ket, "Jenis"=>$jenis), array("ID"=>$m));

            //update data detail
            $md->rubah(array("Cp_Or"=>$cpor, "Status"=>$stat), array("ID"=>$id));
            $eks = $this->get_ekstensi($_FILES['gambar']['name']);
            $fname = $m. "." .$eks;
            $asal = $_FILES['gambar']['tmp_name'];
            $tujuan = "./images/cd_dvd/$fname";
            $hasil['success'] = true;
            $hasil['msg'] = 'Data CD/DVD erhasil dirubah';
            if ($asal){
                if (copy($asal, $tujuan)){
                        $mk->rubah(array("Gambar"=>$fname), array("ID"=>$m));
                        $hasil['success'] = true;
                        $hasil['msg'] = "Data dan gambar CD/DVD berhasil dirubah";
                } else {
                    $hasil['success'] = false;
                    $hasil['msg'] = 'Gambar tidak berhasil dirubah, hanya data Cd/DVD';
                }
            }
        } else {
            $hasil['msg'] = "Anda tidak berhak merubah data CD/DVD";
        }
        echo json_encode($hasil);
    }

    function status_trans($id){
        $kaset = new Kaset_Model();
        $jum_kaset = $kaset->baca_field('Jumlah_Kaset', array('ID'=>$id));
        $jum_pinjam = $kaset->baca_field('Jumlah_Pinjam', array('ID'=>$id));
        $jum_pesan = $kaset->baca_field('Jumlah_Pesan', array('ID'=>$id));
        if (is_numeric($jum_kaset)&&  is_numeric($jum_pinjam) && is_numeric($jum_pesan)){
            if ($jum_kaset > $jum_pinjam + $jum_pesan){
                echo 'Pinjam';
            } else echo 'Pesan';
        }
    }

    function tambah(){
        $hasil = array('success'=>false, 'msg'=>'gagal');
        if ($this->berhak("Create Kaset")){
            $id = $this->input->post('idkaset');
            $judul = $this->input->post('judulkaset');
            $keterangan = $this->input->post('keterangan');
            $keterangan = $keterangan == false ? '' : $keterangan;
            $cpor = $this->input->post('cpor');
            $jenis = $this->input->post('jenis');
            if ($id && $judul && $cpor && $jenis){
                $kaset = new Kaset_Model();
                $kaset_detail = new Detail_Kaset_Model();
                $temp = $kaset_detail->baca_detail('ID',array('ID'=>$id));
                if ($temp->num_rows() == 0){
                    $result = $kaset->baca_where('ID', array('Judul'=>$judul));
                    $id_master = null;
                    if ($result->num_rows() > 0){
                        $id_master = $kaset->ambil_field($result, 'ID');
                    }
                    
                    if ($id_master == null){
                        $kaset->tambah(array('Judul'=>$judul,'Keterangan'=>$keterangan,'Jenis'=>$jenis));
                        $result = $kaset->baca_where('ID', array('Judul'=>$judul));
                        $id_master = $kaset->ambil_field($result, 'ID');
                    }
                    $kaset_detail->tambah(array('ID'=>$id,'Cp_Or'=>$cpor,'ID_Master_CD'=>$id_master));
                    
                    $kst = $_FILES['gambarKaset'];
                    $hasil['success']= true;
                    $hasil['msg']= "Data CD/DVD berhasil ditambah";
                    if ($kst['name']){
                        $eks = $this->get_ekstensi($kst['name']);
                        $fname = $id_master. "." .$eks;
                        $asal = $kst['tmp_name'];
                        $tujuan = "./images/cd_dvd/$fname";
                        if (copy($asal, $tujuan)){
                            $kaset->rubah(array("Gambar"=>$fname), array("ID"=>$id_master));
                            $hasil['msg'] .= ', Gambar berhasil ditambah';
                            if(unlink($asal)){
                                $hasil['msg'] .= ", temporari gambar berhasil dihapus";
                            }
                        } else {
                            $hasil['success']= false;
                            $hasil['msg']= 'Gambar tidak bisa diupload';
                        }
                    }
                }else {
                    $hasil['success']=false;
                    $hasil['msg']= 'ID kaset sudah ada didalam database';
                    $hasil['error']= 1;
                }
            } else {
                $hasil['success']=false;
                $hasil['msg']='Field tidak boleh kosong';
            }
        } else {
            $hasil['success']= false;
            $hasil['msg']= 'Anda tidak punya hak untuk menambah CD/DVD';
        }
        echo json_encode($hasil);
    }
    
    /***
     * Mengambil data kaset yang akan ditampilkan dari class Kaset_Model dan meng-encode data ke dalam format JSON
     * menggunakan fungsi json_encode. Jumlah record dinyatakan oleh 'jumlahKaset' dan elemen root berupa 'kaset'.
     * aksi pengguna yang ditangani meliputi load data untuk pertama kali, mencari kaset berdasarkan kriteria tertentu,
     * dan sort kaset.
     */
    function tampil(){
        $kaset = new Kaset_Model();
        $tmp_kaset = array();
        $tmp_kaset[ID_JUMLAH_KASET] = $kaset->getJumlahTotal();
        $tmp_kaset[ID_AKAR_KASET] = array();
        //variabel yang mungkin di post oleh pengguna yaitu: start, limit, value, kriteria, sort, dir
        //Tampung index awal dari kaset yang diminta oleh client.
        $mulai = $this->input->post('start');
        $mulai = (int)$mulai;
        //parameter untuk proses pengurutan
        $sort = $this->input->post('sort');
        $dir = $this->input->post('dir');
        //parameter untuk proses pencarian
        $k = $this->input->post('kriteria');
        $v = $this->input->post('value');
        $tab_krit = array($k => $v);
        //blok untuk perbaikan

        $sorting = array($sort, $dir);
        $fields = array('ID', 'Judul', 'Jenis', 'Jumlah_Kaset', 'Jumlah_Pinjam', 'Jumlah_Pesan');
        if(!empty($k) && !empty($v)){
            //Pengguna menggunakan menu cari, filter data yang tidak cocok dengan $kriteria dan $value
            $data_kaset = $kaset->baca($fields, $tab_krit, $sorting);
            $tmp_kaset[ID_JUMLAH_KASET] = $data_kaset->num_rows();
            $data_kaset = $kaset->baca($fields, $tab_krit, $sorting, $mulai, JUMLAH_KASET_PER_GRID);
        } else {
            //Load data tanpa filter sesuai dengan jumlah yang telah ditentukan
            //data mulai dari index ke $mulai
            $data_kaset = $kaset->baca($fields, NULL, $sorting, $mulai, JUMLAH_BUKU_PER_GRID);
        }
        $this->toArray($tmp_kaset[ID_AKAR_KASET], $data_kaset);
        echo json_encode($tmp_kaset);
    }

    function tampil_admin(){
        $tmp_kaset = array();
        //variabel yang mungkin di post oleh pengguna yaitu: start, limit, value, kriteria, sort, dir
        //Tampung index awal dari kaset yang diminta oleh client.
        $mulai = $this->input->post('start');
        $mulai = (int)$mulai;
        //parameter untuk proses pengurutan
        $sort = $this->input->post('sort');
        $dir = $this->input->post('dir');
        //parameter untuk proses pencarian
        $k = $this->input->post('kriteria');
        $v = $this->input->post('value');
        
        $k = ($k == 'Master' ? 'tmk.ID' : $k);
        $k = ($k == 'ID' ? 'tdb.ID' : $k);
        //blok untuk perbaikan


        $qry = "select tmk.ID as 'Master', tdb.ID as 'ID', Judul, Jenis, IF(tdb.Status IS NULL, 'Tersedia', tdb.Status) as 'Status' from t_d_kaset as tdb inner join t_m_kaset as tmk on tdb.ID_Master_CD = tmk.ID";

        $sorting = "ORDER BY $sort $dir";
        $limit = "LIMIT $mulai," . (JUMLAH_KASET_PER_GRID);
        
        $qry .= ($v&&$k) ? " WHERE $k LIKE '%$v%'" : '';
        $hasil = App_Model::eksekusi($qry);
        $tmp_kaset[ID_JUMLAH_KASET] = $hasil['jumlah'];
        $tmp_kaset[ID_AKAR_KASET] = array();
        if ($hasil['jumlah'] > 0){
            $qry .= " $sorting $limit";
            $hasil = App_Model::eksekusi($qry);
            $tmp_kaset[ID_AKAR_KASET] = ($hasil['data']);
            $tmp_kaset[ID_AKAR_KASET][0]['Jenis'] .= $v;
            echo json_encode($tmp_kaset);
        } else echo json_encode($tmp_kaset);
    }


    /**
     * Mengubah object hasil baca dari database ke dalam bentuk array untuk selanjutanya dienkripsi dengan format JSON
     *
     * @param array out $tab,array penampung record-record dari database
     * @param object $hasil, object hasil kembalian dari proses baca
     */
    private function toArray(&$tab, $hasil){
        $tmp = array();
        foreach ($hasil->result_array() as $row){
            //buang 3 field dari belakang dan tambahkan field Status
            $tmp = array_slice($row, 0, -3);
            $tmp['Status'] = ($row['Jumlah_Pinjam']+$row['Jumlah_Pesan'] >= $row['Jumlah_Kaset']) ? 'Habis' : 'Tersedia';
            array_push($tab, $tmp);
        }
    }

    private function get_data($id){
        $dkm = new Detail_Kaset_Model();
        $kr = $dkm->get_table_name();
        $kn = "t_m_kaset";
        $on = "$kr.ID_Master_CD = $kn.ID";
        $tipe = 'INNER';
        $fields = array("$kr.ID","$kr.ID_Master_CD", "Jenis", "Keterangan", "Judul", "Cp_Or", "Tgl_Masuk", "$kr.Status","$kn.Gambar");
        $krit = array("$kr.ID"=>$id);
        $hasil = $dkm->baca_komplit($kn, $on, $tipe, $fields, $krit);
        $hasil = $hasil->row_array();
        return $hasil;
    }
    function get_ekstensi($str){
        if (is_string($str)){
            $eks = explode(".", $str);
            return $eks[count($eks)-1];
        } else return false;
    }
}
?>
