<?php

class Notifikasi extends Controller{
    
    public function Notifikasi(){
        parent::Controller();
        $this->load->library('session');
        $this->load->model('Detail_Pemesanan_Model');
        $this->load->model('Referensi_Kategori_Model');
    }

    /**
     * Menangani seluruh notifikasi yang dikirimkan oleh admin kepada anggota perpustakaan
     * Notifikasi akan dikirim ke anggota dengan format json yang terdiri dari 4 bagian yaitu:
     * 1. ganti, menyatakan apakah ada notifikasi baru atau tidak.
     * 2. jumlah_baru, jumlah notifikasi baru, 0 jika tidak ada.
     * 3. jumlah, jumlah seluruh notifikasi
     * 4. notifikasi, detail dari notifikasi yang akan dikirim ke anggota perpustakaan
     * Untuk mengetahui apakah ada perubahan maka dilakukan cache terhadap data lama
     */
    public function lihat_notifikasi($id){
        $tmp_trans = $this->ambil_trans($id);
        
        $temp = array();
        $jumlah = count($tmp_trans);
        $temp['jumlah'] = $jumlah;
        $temp['notifikasi'] = $tmp_trans;
        echo json_encode($temp);
    }

    function lihat_pengembalian($id){
        $qry = "select tmp.Nama, trk.Jenis_Kategori, datediff(curdate(),Rencana_Kembali) as 'Telat', trk.Denda_Per_Hari
from t_d_peminjaman as tdp
inner join t_t_pesan_pinjam as ttp
on tdp.ID_Trans_Peminjaman = ttp.ID
inner join t_r_kategori as trk
on trk.ID = tdp.ID_Referensi_Kategori
inner join t_m_pengguna as tmp
on tmp.ID = ttp.ID_Pengguna
where tdp.Tgl_Kembali is null and
ttp.ID_Pengguna = $id and datediff(curdate(), Rencana_Kembali) >= -1";
        $hasil = App_Model::eksekusi($qry);
        $temp = array('jumlah'=>$hasil['jumlah']);
        $temp['notifikasi'] = array();
        $batas = (int)$hasil['jumlah'];

        for ($i=0; $i<$batas; $i++){
            $hari = $hasil['data'][$i]['Telat'];
            $denda = ($hari * $hasil['data'][$i]['Denda_Per_Hari']);
            $denda = $denda > 0 ? $denda : 0;
            $temp['notifikasi'][] = array("keterangan"=>$hasil['data'][$i]['Jenis_Kategori'] . " yang " .$hasil['data'][$i]['Nama'] . " pinjam harus dikembalikan " .($hari == -1 ? 'besok' : 'hari ini dengan denda Rp. '.$denda));
        }
        echo json_encode($temp);
    }

    private function ambil_trans($id){
        $trans = new Detail_Pemesanan_Model();
        $ref = new Referensi_Kategori_Model();
        $on = 't_t_pesan_pinjam.ID = '. $trans->get_table_name() . '.ID_Trans_Pemesanan';
        $tipe = 'INNER';
        $fields = array('t_d_pemesanan.ID','ID_Referensi_Kategori', 'ID_M_Buku', 'ID_M_Kaset');
        $kriteria = array('ID_Status'=>5, 't_t_pesan_pinjam.ID_Pengguna'=>$id,
            'ID_Jenis'=>1);
        $data_trans = $trans->baca_join('t_t_pesan_pinjam', $on, $fields, NULL, $kriteria);
        $arr = array();
        foreach($data_trans->result_array() as $row){
            $temp = array();
            $temp['ID'] = $row['ID'];
            $temp['kategori'] = $ref->baca_field('Jenis_Kategori', array('ID'=>$row['ID_Referensi_Kategori']));
            $temp['id_kat'] = ($row['ID_M_Buku'] == NULL ? $row['ID_M_Kaset']: $row['ID_M_Buku']);
            $arr[] = $temp;
        }
        return $arr;
    }
}
?>
