<?php

/***
 * File      : artikel.php
 * Tipe      : Controller
 * Dibuat    : Kamis, 19 Mei 2011 10:34
 * 
 */

class Artikel extends Controller{

    function Artikel(){
        parent::Controller();
        $this->load->model('Artikel_Model');
    }

    /**
     * Fungsi yang menyediakan artikel yang akan ditampilkan pada tampilan utama.
     * @param string $judul, judul dari artikel yang akan ditampilkan
     * @param string $nomor, nomor urut dari artikel
     */
    function ambil($nomor){
        $artikel = new Artikel_Model();
        $isi = $artikel->baca_field('Isi', array('ID' =>$nomor));
        $tgl_buat = $artikel->baca_field('Tgl_Dibuat', array('ID' =>$nomor));
        $jum_lihat = $artikel->baca_field('Jumlah_Lihat', array('ID' =>$nomor));
        echo $isi . "<br><br><div align='left'>Dibuat $tgl_buat dan dilihat sebanyak $jum_lihat kali</div>";
    }

    function ambil_semua_judul(){
        $artikel = new Artikel_Model();
        $judul = $artikel->baca('ID, Judul');
        $hasil = array();
        $hasil['jumlahArtikel'] = 0;
        $hasil['artikel'] = array();
        $this->toArray($hasil['artikel'], $judul);
        echo json_encode($hasil);
    }

    /**
     * Mengubah object hasil baca dari database ke dalam bentuk array untuk selanjutanya dienkripsi dengan format JSON
     *
     * @param array out $tab,array penampung record-record dari database
     * @param object $hasil, object hasil kembalian dari proses baca
     */
    private function toArray(&$tab, $hasil){
        $tmp = array();
        foreach ($hasil->result_array() as $row){
            array_push($tab, $row);
        }
    }
    public function tambah_artikel($id) {
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $id= (int) $id;
        if ($judul && $isi){
            $tambah = new Artikel_Model();
            $tambah->tambah(array('Judul'=>$judul,'Isi'=>$isi,'ID_Pembuat'=>$id));
        } else echo "{ success : false, msg : 'Field Tidak Boleh Kosong'}";
    }
}
?>
