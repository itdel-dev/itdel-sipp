<?php
    class Rule extends Controller{
        function Rule(){
                parent::Controller();
                $this->load->helper('url');
        }

        //Fungsi yang dipanggil ketika pengguna mengakses halaman administrator
        //Mengecek session admin, jika telah terbentuk maka akan menampilkan halaman admin jika tidak maka redirect ke halamaan depan
        function index(){
            $this->load->view('rule');
        }
    }
?>