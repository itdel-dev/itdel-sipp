<?php
/***
 * File      : buku.php
 * Tipe      : Controller
 * Dibuat    : Selasa, 10 Mei 2011 11:21
 * Sejarah perubahan:
 *  1. Kamis, 12 Mei 2011 09:16
 * Deskripsi : Class yang menangani operasi yang dilakukan terhadap buku oleh semua pengguna Sistem Informasi.
 * Operasi yang didukung yaitu:
 *  1. tampil, menampilkan daftar buku yang tersedia pada perpustakaan.
 *  2. tambah, menambah data buku baru ke dalam database jika buku yang akan ditambah belum ada.
 *  3. rubah, merubah data buku yang dipilih.
 *  4. hapus, menghapus data buku yang dipilih dari database.Menghapus berarti mengubah jumlah buku menjadi 0.
 *  5. pesan, melakukan proses administrasi pemesanan buku. Mengurangi jumlah buku yang tersedia sebanyak jumlah yang
 *     dipesan (default 1) dan menyimpan log pemesanan pada tabel pemesanan. Pemesanan akan dibatalkan secara otomatis jika
 *     tidak dikonfirmasi setelah jangka waktu yang ditetapkan (1 hari). Pemesanan akan menjadi peminjaman ketika dilakukan
 *     konfirmasi oleh admin dan data pemesanan akan disimpan kembali pada tabel peminjaman.
 *  6. pinjam, melakukan peminjaman buku.
 *  7. batalPesan, membatalkan pemesanan buku yang telah dilakukan.
 *  8. detail, menampilkan detail buku yang diinginkan
 */

require_once (dirname(__FILE__).'/app_controller.php');
class Buku extends App_Controller{
    
    function Buku(){
        parent::App_Controller();
        $this->load->model('Buku_Model');
        $this->load->model('Detail_Buku_Model');
        $this->load->helper('url');
        $this->load->library('session');
    }

    function detailBuku($id){
        $buku = new Buku_Model();
        $fields = array('ID', 'Judul', 'Edisi', 'Pengarang', 'Penerbit', 'Jumlah_Buku', 'Jenis', 'Deskripsi');
        $hasil = $buku->baca_detail($fields, array('ID'=>$id));
        $hasil = $hasil->row_array();
        echo "<div>";
        foreach($hasil as $k=>$v){
            if ($k == 'Jumlah_Buku'){
                $k = 'Jumlah Buku';
            }

                echo '<span style="font-weight: bold">' .$k . "</span>".":<br>";
                echo $v . "<br><br>";
        }
        echo "</div>";
    }

    function tampil_detail_buku_adm($id){
        $hasil = $this->get_detail_buku($id);
        $image = $hasil['Gambar'];
        echo "<center><img src= '".PATH_GAMBAR_BUKU."$image' width='120'></img></center>";
        foreach ($hasil as $k=>$v){
            if($k!='Gambar')
                echo '<span style="font-weight: bold">' .$k . "</span>".":<br>$v<br><br>";
        }
    }
    
    /**
     * Menampilkan buku baru yang dimasukan
     */
    function get_buku_baru(){
        $qry = "select mb.Judul, mb.Pengarang, mb.Penerbit, db.Klasifikasi from t_d_buku as db inner join t_m_buku as mb on db.ID_Master_Buku = mb.ID where NOT Tgl_Masuk IS NULL AND Tgl_Masuk >= date_sub(curdate(), interval 1 week);";
        $hasil = App_Model::eksekusi($qry);
        echo json_encode($hasil);
    }

    /**
     * Mengembalikan data buku yang akan diedit dalam format json
     * @param $id string, id detail buku
     */
    function get_data_edit($id){
        header('content-type: text/xml');
        $temp = "";
        $hasil = $this->get_detail_buku($id);
        foreach ($hasil as $k=>$v){
            $temp .= $this->to_xml($k, $v);
        }
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        echo "<message success=\"true\">";
        echo "<data>";
        echo $temp;
        echo "</data>";
        echo "</message>";
    }

    /**
     * Menampilkan daftar buku yang paling sering dipinjam pada bulan ini
     */
    function get_rating(){
        $qry = "select Judul, Pengarang, Bahasa, jumlah
            from viewRatingBuku as vrb inner
            join t_m_buku as tmb on vrb.idm = tmb.ID
            ORDER BY jumlah DESC";
        $hasil = App_Model::eksekusi($qry);
        echo json_encode($hasil);
    }

    //menghapus buku dari tabel
    function hapus(){
        if ($this->berhak("Delete Buku")){
        $global = $this->session->userdata('global');
        $turunan = $this->session->userdata('turunan');
        $id = $this->input->post('id');
            $buku = new Buku_Model();
            $buku->call_procedure("hapus_buku", array($id));
            echo "Buku dengan ID $id berhasil dihapus";
        } else echo "Anda Tidak berhak menghapus buku";
    }

    /***
     * Menampilkan daftar buku yang tersedia pada perpustakaan.
     * Memanfaatkan fungsi tampil untuk menampilkan data buku.
     */
    function index(){
        $this->load->view('halaman_depan');
    }

    function status_trans($id){
        $buku = new Buku_Model();
        $jum_buku = $buku->baca_field('Jumlah_Buku', array('ID'=>$id));
        $jum_pinjam = $buku->baca_field('Jumlah_Pinjam', array('ID'=>$id));
        $jum_pesan = $buku->baca_field('Jumlah_Pesan', array('ID'=>$id));
        if (is_numeric($jum_buku)&&  is_numeric($jum_pinjam) && is_numeric($jum_pesan)){
            if ($jum_buku > $jum_pinjam + $jum_pesan){
                echo 'Pinjam';
            } else echo 'Pesan';
        }
    }

    function status_trans_detail($id){
        $buku = new Buku_Model();
        $qry = "select get_id_master(get_buku(), '$id') as fn";
        $hasil = App_Model::eksekusi($qry);
        $this->status_trans($hasil['data'][0]['fn']);
    }

    
    /***
     * Mengambil data buku yang akan ditampilkan dari ModelBuku dan meng-encode data ke dalam format JSON
     * menggunakan fungsi json_encode. Jumlah record dinyatakan oleh 'jumlahBuku' dan elemen root berupa 'buku'.
     * aksi pengguna yang ditangani meliputi load data untuk pertama kali, mencari buku berdasarkan kriteria tertentu,
     * dan sort buku.
     */
    function tampil(){
        $buku = new Buku_Model();
        $tmp_buku = array();
        $tmp_buku[ID_AKAR_BUKU] = array();
        
        //variabel yang mungkin di post oleh pengguna yaitu: start, limit, value, kriteria, sort, dir
        //Tampung index awal dari buku yang diminta oleh client.
        $mulai = $this->input->post('start');

        //parameter untuk proses pengurutan
        $sort = $this->input->post('sort');
        $dir = $this->input->post('dir');

        $mulai = (int)$mulai;
        $temp_key = '';
        foreach ($_POST as $k=>$v){
            $temp_key .= ';'.$k.$v;
        }
       
        //parameter untuk proses pencarian
        $k = $this->input->post('kriteria');
        $v = $this->input->post('value');
        $tab_krit = array($k => $v);
        //blok untuk perbaikan
        
        $sorting = array($sort, $dir);
        $fields = array('ID', 'Judul', 'Edisi', 'Pengarang', 'Bahasa', 'Jenis', 'Jumlah_Buku', 'Jumlah_Pinjam', 'Jumlah_Pesan');

        if($k && $v){
            //Pengguna menggunakan menu cari, filter data yang tidak cocok dengan $kriteria dan $value
            $data_buku = $buku->baca($fields, array($k=>$v), $sorting);
            $tmp_buku[ID_JUMLAH_BUKU] = $data_buku->num_rows();
            $data_buku = $buku->baca($fields, $tab_krit, $sorting, $mulai, JUMLAH_BUKU_PER_GRID);
        } else {
            //Load data tanpa filter sesuai dengan jumlah yang telah ditentukan
            //data mulai dari index ke $mulai
            $tmp_buku[ID_JUMLAH_BUKU] = $buku->getJumlahTotal();
            $data_buku = $buku->baca($fields, NULL, $sorting, $mulai, JUMLAH_BUKU_PER_GRID);
        }
        $this->toArray($tmp_buku[ID_AKAR_BUKU], $data_buku, $temp_key);
        echo json_encode($tmp_buku);
    }

    function tampil_buku_adm(){
        $buku = new Buku_Model();
        $tmp_buku = array();
        $tmp_buku[ID_AKAR_BUKU] = array();

        //variabel yang mungkin di post oleh pengguna yaitu: start, limit, value, kriteria, sort, dir
        //Tampung index awal dari buku yang diminta oleh client.
        $mulai = $this->input->post('start');

        //parameter untuk proses pengurutan
        $sort = $this->input->post('sort');
        $dir = $this->input->post('dir');

        $mulai = (int)$mulai;
        //parameter untuk proses pencarian
        $k = $this->input->post('kriteria');
        $v = $this->input->post('value');
        
        //$sorting = array($sort, $dir);
        $sorting = array($sort, $dir);
        $tbl = 't_d_buku';
        $asl = $buku->get_table_name();
        $k = ($k == 'ID' ? "$tbl.$k" : $k);
        
        $tab_krit = array($k => array('LIKE', "'%$v%'"));
        $on = "$asl.ID = $tbl.ID_Master_Buku";
        $fields = array("$tbl.ID_Master_Buku", "$tbl.ID", "$asl.Judul", "$asl.Pengarang", "$asl.Penerbit", "Jenis", "$tbl.Klasifikasi","$tbl.Status");
        $akhir = 0;
        if($k && $v){
            $temp = $buku->baca_join($tbl, $on, $fields, $sorting, $tab_krit);
            $tmp_buku[ID_JUMLAH_BUKU] = $buku->ambil_total($temp);
            $akhir = JUMLAH_BUKU_PER_GRID;
            $hasil = $buku->baca_join($tbl, $on, $fields, $sorting, $tab_krit, $mulai, $akhir);
        } else {
            $temp = $buku->baca_join($tbl, $on, 'count(*) as fn');
            $tmp_buku[ID_JUMLAH_BUKU] = $buku->ambil_field($temp, 'fn');
            $hasil = $buku->baca_join($tbl, $on, $fields, $sorting, array('Status'=>array('NOT IN (', "'Hapus', 'Pinjam')")), $mulai, JUMLAH_BUKU_PER_GRID);
        }
        $this->ke_array($tmp_buku[ID_AKAR_BUKU], $hasil);
        echo json_encode($tmp_buku);
    }
    
    function tambah_buku() {
		/*$temp ['success'] = true;
		$temp ['msg'] = $_FILES['gambar']['name'];
		echo json_encode($temp);*/
        //t_m_buku

        $hasil = array('success'=>false, 'msg'=>'gagal');
        if ($this->berhak("Create Buku")){
			$edisi= $this->input->post('edisi');
                        $edisi = $edisi == false ? '' : $edisi;
			$pengarang = $this->input->post('pengarang');
			$deskripsi = $this->input->post('deskripsi');
                        $deskripsi = ($deskripsi == false) ? '' : $deskripsi;
			$jenis = $this->input->post('jenis');
			$penerbit = $this->input->post('penerbit');
			$judul = $this->input->post('judul');
			$bahasa = $this->input->post('bahasa');
			//t_d_buku
			$ID = $this->input->post('id_buku');
			$isbn = $this->input->post('isbn');
			$klasifikasi = $this->input->post('klasifikasi');
			$lokasi = $this->input->post('lokasi');
			$cpor = $this->input->post('cpor');
			$tahun = $this->input->post('tahun');
			$status = $this->input->post('status');
                        $hasil['success'] = true;
			
			if ($ID && $pengarang && $jenis && $penerbit && $judul && $bahasa && $isbn && $klasifikasi && $lokasi && $cpor && $tahun && $status){
				$master_buku = new Buku_Model();
				$detail_buku = new Detail_Buku_Model();
				$result = $master_buku->baca_where('ID', array('Judul'=>$judul));
				$id_master = null;
                                if ($result->num_rows() > 0){
                                    $id_master = $master_buku->ambil_field($result, 'ID');
                                }
				$temp = $detail_buku->baca_detail('ID',array('ID'=>$ID));
                                
				if ($temp->num_rows()==0){
					if((int)$tahun > 1900 && (int)$tahun < 2100){
						if ($id_master == null){
							$master_buku->tambah(array('Edisi'=>$edisi,'Pengarang'=>$pengarang,'Deskripsi'=>$deskripsi,'Jenis'=>$jenis,'Penerbit'=>$penerbit,'Judul'=>$judul,'Bahasa'=>$bahasa));
							$result = $master_buku->baca_where('ID', array('Judul'=>$judul));
							$id_master = $master_buku->ambil_field($result, 'ID');
							$detail_buku->tambah(array('ID'=>$ID,'ISBN'=>$isbn,'Klasifikasi'=>$klasifikasi,'Lokasi'=>$lokasi,'Cp_Or'=>$cpor,'Tahun'=>$tahun,'Status'=>$status,'ID_Master_Buku'=>$id_master));
                                                        $hasil['msg'] = 'Hai semua';
						}else {
							$detail_buku->tambah(array('ID'=>$ID,'ISBN'=>$isbn,'Klasifikasi'=>$klasifikasi,'Lokasi'=>$lokasi,'Cp_Or'=>$cpor,'Tahun'=>$tahun,'Status'=>$status,'ID_Master_Buku'=>$id_master));
						}
						$eks = $this->get_ekstensi($_FILES['gambar']['name']);
						$fname = $id_master. "." .$eks;
						$asal = $_FILES['gambar']['tmp_name'];
						$tujuan = "./images/buku/$fname";
                                                if ($asal){
                                                    if (copy($asal, $tujuan)){
                                                            $master_buku->rubah(array("Gambar"=>$fname), array("ID"=>$id_master));
                                                            $hasil['success']= true;
                                                            $hasil['msg'] = 'Data dan gambar buku berhasil ditambah';
                                                    } else {
                                                            $hasil['success']= true;
                                                            $hasil['msg']= 'Hanya teks buku yang berhasil ditambah';                                                    }
                                                } else {
                                                    $hasil['success'] = true;
                                                    $hasil['msg'] = 'Data buku berhasil ditambah';
                                                }
					} else {
                                            $hasil['success'] = false;
                                            $hasil['msg'] ='Format Tahun Salah';
                                            $hasil['error'] = 2 ;
                                        }
				} else {
                                    $hasil['success']=false;
                                    $hasil['msg']=  'Buku sebelumnya sudah terdaftar';
                                    $hasil['error']= 1;
                                };
			} else {
                            $hasil['success']= false;
                            $hasil['msg']= 'Semua Field harus di isi';
                        }
        } else {
            $hasil['success'] = false;
            $hasil['msg']= 'Anda tidak punya hak untuk menambah buku';
        }
        echo json_encode($hasil);
    }
    
    // Mengubah data buku
    public function rubah(){
        $hasil = array('success'=>false);
        $hasil['msg'] = "Server Error";
        if ($this->berhak("Update Buku")){
            $id_d = $this->input->post('ID');
            $id_m = $this->input->post('ID_Master_Buku');
            $edisi = $this->input->post('Edisi');
            $judul = $this->input->post('Judul');
            $pengarang = $this->input->post('Pengarang');
            $deskripsi = $this->input->post('Deskripsi');
            $jenis = $this->input->post('Jenis');
            $penerbit = $this->input->post('Penerbit');
            $klasifikasi = $this->input->post('Klasifikasi');
            $lokasi = $this->input->post('Lokasi');
            $isbn = $this->input->post('ISBN');
            $tahun = $this->input->post('Tahun');
            $cpor = $this->input->post('Cp_Or');
            $bahasa = $this->input->post('Bahasa');
           
            
            $buku = new Buku_Model();
            $detail_buku = new Detail_Buku_Model();
            $buku->rubah(array('Deskripsi'=>$deskripsi,'Jenis'=>$jenis, 'Edisi'=>$edisi, 'Pengarang'=>$pengarang, 'Penerbit'=>$penerbit, 'Judul'=>$judul, 'Bahasa'=>$bahasa), array('ID'=>$id_m));
            $detail_buku->rubah(array('Klasifikasi'=>$klasifikasi, 'ISBN'=>$isbn, 'Tahun'=>$tahun, 'Cp_Or'=>$cpor, 'Lokasi'=>$lokasi), array('ID'=>$id_d));
            $hasil['success'] = true;
            $eks = $this->get_ekstensi($_FILES['gambar']['name']);
            $fname = $id_m. "." .$eks;
            $asal = $_FILES['gambar']['tmp_name'];
            $tujuan = "./images/buku/$fname";
            $hasil['msg'] = 'Data buku berhasil dirubah';
            if ($asal){
                if (copy($asal, $tujuan)){
                        //$buku->rubah(array("Gambar"=>$fname), array("ID"=>$id_m));
                        $hasil['success'] = true;
                        $hasil['msg'] = "Data dan gambar buku berhasil dirubah";
                } else {
                    $hasil['msg'] = 'Gambar tidak berhasil diperbaharui';
                }
            }
        } else {
            $hasil['msg'] = "Anda tidak punya hak untuk mengubah buku";
        }
        echo json_encode($hasil);
    }

    //mengambil klasifikasi buku dari id master yang diberikan
    private function get_klasifikasi($id){
        $db = new Detail_Buku_Model();
        $klas = $db->baca_field('Klasifikasi', array('ID_Master_Buku'=>$id));
        return $klas;
    }

    private function ke_array(&$tab, $hasil, $debug=NULL){
        $tmp = array();
        foreach ($hasil->result_array() as $row){
            //$row['Jenis'] .= $debug;
            array_push($tab, $row);
        }
    }
	
	function get_ekstensi($str){
		$eks = explode(".", $str);
		return $eks[count($eks)-1];
	}

    //Mengambil detail buku berdasarkan id yang diberikan
    private function get_detail_buku($id){
        $buku = new Buku_Model();
        $tbl = 't_d_buku';
        $asl = $buku->get_table_name();
        $on = "$asl.ID = $tbl.ID_Master_Buku";
        $fields = array("$tbl.ID_Master_Buku","$tbl.ID","$asl.Judul","$asl.Pengarang","$asl.Deskripsi","$asl.Jenis","$asl.Edisi","$tbl.ISBN","$tbl.Klasifikasi","$tbl.Lokasi","$tbl.CP_OR","$tbl.Tahun","$asl.Gambar");
        $hasil = $buku->baca_join($tbl, $on, $fields, NULL, array("$tbl.ID"=>$id));
        $hasil = $hasil->row_array();
        return $hasil;
    }
    /**
     * Mengubah object hasil baca dari database ke dalam bentuk array untuk selanjutanya dienkripsi dengan format JSON
     *
     * @param array out $tab,array penampung record-record dari database
     * @param object $hasil, object hasil kembalian dari proses baca
     */
    private function toArray(&$tab, $hasil, $deb=true){
        $tmp = array();
        foreach ($hasil->result_array() as $row){
            //buang 3 field dari belakang dan tambahkan field Status
            $tmp = array_slice($row, 0, -3);
            $tmp['Status'] = ($row['Jumlah_Pinjam']+$row['Jumlah_Pesan'] >= $row['Jumlah_Buku']) ? 'Habis' : 'Tersedia';
            $tmp['Klasifikasi'] = $this->get_klasifikasi($row['ID']);
            array_push($tab, $tmp);
        }
    }
}

?>
