<?php

	class Userguide extends Controller{
		function Userguide(){
			parent::Controller();
                        $this->load->helper('url');
		}

                //Fungsi yang dipanggil ketika pengguna mengakses halaman userGuidePerpus
                function index(){
                    $this->load->view('about');
                }
                function page2(){
                    $this->load->view('about2');
                }
                function page3(){
                    $this->load->view('about3');
                }
                function page4(){
                    $this->load->view('about4');
                }
                function page5(){
                    $this->load->view('about5');
                }
	}
?>