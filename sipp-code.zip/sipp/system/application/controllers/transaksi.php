<?php
/**
 * Class yang menangani transaksi yang terjadi pada sistem informasi perpustakaan
 * Transaksi meliputi pemesanan dan peminjaman
 * @author Roy Inganta Ginting
 * Dibuat   : 09 Juni 2011, 20:06
 * File     : transaksi.php
 */
require_once(dirname(__FILE__).'/app_controller.php');
class Transaksi extends App_Controller{

    function Transaksi(){
        parent::App_Controller();
        $this->load->helper('url');
        $this->load->model('Detail_Pemesanan_Model');
        $this->load->model('Detail_Peminjaman_Model');
        $this->load->model('Pesan_Pinjam_Model');
        $this->load->model('Detail_Buku_Model');
        $this->load->model('Detail_Kaset_Model');
        $this->load->model('Pengguna_Model');
    }

    //index tidak bisa diakses, redirect pengguna ke halaman utama
    function index(){
        redirect(base_url());
    }

    //menangani pembatalan pemesanan
    function batal(){
        if ($this->is_admin()){
            if ($this->berhak("Konfirmasi Pemesanan")){
                //get id pemesanan
                $id = $this->input->post('id');
                $dpm = new Detail_Pemesanan_Model();
                $dpm->rubah(array('ID_Status'=>3), array('ID'=>$id));
                echo "Pemesanan telah dibatalkan";
            } else echo "Anda tidak berhak membatalkan pesanan";
        } else echo "Hanya admin yang dapat menjalankan fungsi ini";
    }

    /**
     * Mengambil data transaksi pemesanan barang yang aktif, meliputi kaset dan buku
     */
    function get_pesanan(){
        $sort = array($this->input->post('sort'), $this->input->post('dir'));
        $mulai = (int)$this->input->post('start');
        $krit = $this->input->post('kriteria');
        $val = $this->input->post('value');

        $where = "WHERE ID_Status IN (get_pesan(), get_pesan_cepat(), get_setuju())";
        if ($krit && $val){
            $krit = ($krit == 'Nama' ? 'tmp.Nama' : $krit);
            $krit = ($krit == 'Nomor' ? "IF (is_buku(ID_Referensi_Kategori), ID_M_Buku, ID_M_Kaset)" : $krit);
            $krit = ($krit == 'Status' ? 'trj.status' : $krit);
            $where .= " AND $krit LIKE '%$val%'";
        }
        $qry = "select tdp.ID, tmp.Nama, Jenis_Kategori, IF (is_buku(ID_Referensi_Kategori), ID_M_Buku, ID_M_Kaset) as 'Nomor', Tgl_Transaksi, trj.status
            FROM t_d_pemesanan as tdp
            INNER JOIN t_t_pesan_pinjam as ttp on tdp.ID_Trans_Pemesanan = ttp.ID
            INNER JOIN t_m_pengguna as tmp on ttp.ID_Pengguna = tmp.ID
            INNER JOIN t_r_kategori as trk on trk.ID = tdp.ID_Referensi_Kategori
            INNER JOIN t_r_jenis as trj on trj.ID = ID_Status
            $where
            ORDER BY {$sort[0]} {$sort[1]}
            LIMIT $mulai, ". ($mulai + JUMLAH_BUKU_PER_GRID);
        
        //$admin = $this->session->get_userdata('global');
        $temp['data'] = array();
        $hasil = App_Model::eksekusi($qry);
        $temp['jumlah'] = $hasil['jumlah'];
        if($temp['jumlah'] > 0){
            $temp['data'] = $hasil['data'];
        }
        echo json_encode($temp);
    }

    /**
     * Mengambil data transaksi peminjaman barang yang aktif, meliputi kaset dan buku
     */
    function get_pinjaman(){
        $sort = array($this->input->post('sort'), $this->input->post('dir'));
        $mulai = (int)$this->input->post('start');
        $krit = $this->input->post('kriteria');
        $val = $this->input->post('value');

        $where = "WHERE tdp.Tgl_Kembali IS NULL ";
        if ($krit && $val){
            $where .= " AND $krit LIKE '%$val%'";
        }
        
        $qry = "select ttp.ID_Pengguna, ID_Referensi_Kategori,tdp.Rencana_Kembali, trk.Jenis_Kategori, IF (is_buku(ID_Referensi_Kategori), ID_D_Buku, ID_D_Kaset) as 'id_bar', Nama
from t_d_peminjaman as tdp
inner join t_t_pesan_pinjam as ttp
on tdp.ID_Trans_Peminjaman = ttp.ID
inner join t_m_pengguna as tmp
	on ttp.ID_Pengguna = tmp.ID
inner join t_r_kategori as trk
	on trk.ID = tdp.ID_Referensi_Kategori
$where
 ORDER BY {$sort[0]} {$sort[1]} LIMIT $mulai, " . ($mulai + JUMLAH_PEMINJAMAN_PER_GRID);
        $temp = array();
        $temp['data'] = array();
        
        $hasil = App_Model::eksekusi($qry);
        $temp['jumlah'] = $hasil['jumlah'];
        if($temp['jumlah'] > 0){
            $temp['data'] = $hasil['data'];
        }
        echo json_encode($temp);
    }

    function kembali_barang(){
        $peminjam = $this->input->post('peminjam');
        $jenis = $this->input->post('jenis');
        $id = $this->input->post('id');

        if ($peminjam&&$jenis&&$id){
            $ppm = new Pesan_Pinjam_Model();
            $ppm->call_procedure('kembali_barang', array($peminjam, $jenis, $id, 1));
            echo "Proses pengembalian barang berhasil";
        }else {
            echo "error: $peminjam, $jenis, $id";
        }
    }
    function pinjam_barang(){
        if ($this->berhak("Catat Peminjaman")){
        $buku = new Detail_Buku_Model();
        $trans = $this->input->post('id_trans');
        $trans = ($trans == false) ? true : $trans;
        $barang = $this->input->post('id_bar');
        $barang = ($barang === false) ? '00' : $barang;
        $tgl = $this->input->post('tgl_kembali');
        $id_mas = $this->input->post('id_m');
        $id_mas = ($id_mas === true) ? 1 : $id_mas;
        $id_mas = ($id_mas === false) ? 0 : $id_mas;
        $peminjam = $buku->call_function('get_id_pemesan', array($trans));
        $peminjam = $buku->ambil_field($peminjam, 'fn');
        $jenis = $buku->call_function('get_jenis', array($barang));
        $jenis = $buku->ambil_field($jenis, 'fn');
        $hasil = array();

        if ($jenis > 0){
            if ($this->is_cocok($jenis, $barang, $id_mas) > 0){
                $buku->call_procedure('pinjam_barang', array($peminjam, $jenis, $barang, 1, $tgl));
                $hasil['success'] = true;
                $hasil['msg'] = "Peminjaman telah diproses $tgl";
            } else {
                $hasil['sucess'] = false;
                $hasil['msg'] = "Barang yang dipesan dan dipinjam tidak cocok $id_mas $jenis $barang";
            }
        } else {
            $hasil['success'] = false;
            $hasil['msg'] = "ID yang Anda masukan tidak valid $jenis";
        }
        } else {
            $hasil['success'] = false;
            $hasil['msg'] = "Anda tidak mempunyai hak untuk mencatat peminjaman bahan pustaka";
        }
        echo json_encode($hasil);
    }

    function pinjam_langsung(){
        if ($this->berhak("Catat Peminjaman")){
            $jenis = $this->input->post('jenis');
            $jenis = $jenis == 'Buku' ? 1 : 2;
            $tgl = $this->input->post('tglKembali');
            $jumlah = $this->input->post('jumlah');
            $ni = $this->input->post('nomorInduk');
            $barang = $this->input->post('idBuku');

            $pm = new Pengguna_Model();
            $peminjam = $pm->baca_field('ID', array('NI'=>$ni));
            $buku = new Detail_Buku_Model();
            $hasil = array();
            if ($this->is_buku_kaset($jenis, $barang)){
                $temp = $buku->call_function('jumlah_pesan', array($peminjam, 1));
                $jlh = $buku->ambil_field($temp, 'fn') == NULL ? 0 : $buku->ambil_field($temp, 'fn');
                $temp = $buku->call_function('jumlah_pinjam', array($peminjam, 1));
                $jlh += $buku->ambil_field($temp, 'fn') == NULL ? 0 : $buku->ambil_field($temp, 'fn');
                $total = $pm->baca_field('Batas_Buku', array('ID'=>$peminjam));
                if ($total > $jlh){
                    $buku->call_procedure('pinjam_barang', array($peminjam, $jenis, $barang, 1, $tgl));
                    $hasil['success'] = true;
                    $hasil['msg'] = "Peminjaman telah diproses";
                } else {
                    $hasil['success'] = false;
                    $hasil['msg'] = "Jumlah Peminjaman Anda telah mencapati batas ($total buah)";
                }
            } else {
                $hasil['success'] = false;
                $hasil['msg'] = "ID yang Anda masukan dan jenis tidak cocok";
            }
        } else {
            $hasil['success'] = false;
            $hasil['msg'] = "Anda tidak mempunyai hak untuk mencatat peminjaman bahan pustaka";
        }
        echo json_encode($hasil);
    }

    function is_cocok($jenis, $detail, $master){
        if($jenis == 1){
            //buku
            $tbl = 't_d_buku';
            $field = "ID_Master_Buku";
        } else if ($jenis == 2){
            //kaset
            $tbl = 't_d_kaset';
            $field = "ID_Master_CD";
        }
        $qry = "SELECT COUNT(*) as 'jlh' FROM $tbl WHERE $field = '$master' AND ID = '$detail'";
        $hasil = App_Model::eksekusi($qry);
        $hasil = $hasil['data'][0]['jlh'];
        return $hasil;
    }

    function setujui_pesanan(){
        if ($this->berhak("Konfirmasi Pemesanan")){
            $id = $this->input->post('id');
            $ppm = new Pesan_Pinjam_Model();
            $ppm->call_procedure('setuju', array($id));
            echo "Pesanan telah disetujui";
        } else {
            echo "Anda tidak punya hak untuk menyetujui pesanan";
        }
    }

    function get_detail_history($id){
        $qry = "SELECT tmp.NI, tmp.Nama, tmr.Nama AS 'Peran', trk.Jenis_Kategori, IF(is_buku(tdp.ID_Referensi_Kategori), tdp.ID_D_Buku, tdp.ID_D_Kaset) AS 'ID_Barang', tdp.Tgl_Pinjam, tdp.Tgl_Kembali, IF(tdd.Besar_denda IS NULL, 0, tdd.Besar_denda) AS 'Denda' FROM t_d_peminjaman AS tdp INNER JOIN t_t_pesan_pinjam AS ttp ON tdp.ID_Trans_Peminjaman= ttp.ID INNER JOIN t_m_pengguna AS tmp ON tmp.ID = ttp.ID_Pengguna INNER JOIN t_m_peran AS tmr ON tmr.ID = tmp.ID_role LEFT JOIN t_r_kategori AS trk ON trk.ID = tmp.ID_role LEFT JOIN t_d_denda AS tdd ON tdd.ID_Detail_Peminjaman = tdp.ID WHERE tdp.ID = $id";

        $hasil = App_Model::eksekusi($qry);
        echo json_encode($hasil);
    }

    function get_denda($jenis, $id, $peminjam){
        $ddm = new Pengguna_Model();
        $hasil = $ddm->call_function('get_denda', array($jenis, $id, $peminjam));
        $hasil = $ddm->ambil_field($hasil, 'fn');
        $nim = $ddm->baca_field('NI', array('ID'=>$peminjam));
        echo "ID Bahan Pustaka : <span style='font-weight: bold'>$id</span><br>";
        echo "NIM Peminjam &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span style='font-weight: bold'>$nim</span><br><hr>";
        echo "<div align='center'>Denda yang harus dibayar<br><span style='font-size: 13pt; font-weight: bold'>Rp.$hasil,00</span></div>";
        return $hasil;
    }

    function is_buku_kaset($jenis, $id){
        $tbl = 't_d_buku';
        if($jenis == 1){
            //buku
            $tbl = 't_d_buku';
        } else if ($jenis == 2){
            //kaset
            $tbl = 't_d_kaset';
        }
        $qry = "SELECT COUNT(*) as 'jlh' FROM $tbl WHERE ID = '$id'";
        $hasil = App_Model::eksekusi($qry);
        $hasil = $hasil['data'][0]['jlh'];
        return $hasil;
    }
}
?>
