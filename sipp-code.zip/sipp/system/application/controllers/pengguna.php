<?php
    /**
     *
     * @author Roy Inganta Ginting
     * File    : Pengguna.php
     * Tipe    : Controller
     * sejarah :
     *  - Rabu, 25 Mei 2011, 09:18
     *      1. Mengganti nama kelas menjadi Pengguna
     * Class yang menangani proses-proses yang berhubungan dengan pengguna olis.
     */
    require_once (dirname(__FILE__).'/app_controller.php');
    class Pengguna extends App_Controller{

        public function  Pengguna() {
            parent::App_Controller();
            $this->load->helper('url');
            $this->load->library('session');
            $this->load->model('Pengguna_Model');
            $this->load->model('Pesan_Pinjam_Model');
            $this->load->model('Buku_Model');
            $this->load->model('Kaset_Model');
            $this->load->model('Artikel_Model');
        }

        function index(){
            if ($this->session->userdata('global') == true || $this->session->userdata('turunan') == true){
                $path = base_url() . 'index.php/lib/admin';
                redirect($path);
            } else {
                $this->load->view('halaman_depan');
            }
        }

        function get_detail_pengguna($username){
            $result = $this->get_data($username);
            foreach ($result->row_array() as $k => $v){
                if ($k == "No_HP")
                    $k = "No Handphone";
                else if ($k == "Batas_Buku")
                    $k = "Batas Buku";
                else if ($k == "NI")
                    $k = "Nomor Induk";
                echo "<span style='font-weight: bold'>$k:</span><br>";
                echo "$v<br><br>";

            }
        }

        function get_data_update($username){
            header('content-type: text/xml');
            $hasil = $this->get_data($username);
            $temp = '';
            foreach ($hasil->row_array() as $k=>$v){
                $temp .= $this->to_xml($k, $v);
            }
            echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            echo "<message success=\"true\">";
            echo "<data>";
            echo $temp;
            echo "</data>";
            echo "</message>";
        }
        /**
         * Menangani proses login pengguna.
         * Data login ditampung menggunakan cookies dan session.
         */
        function login(){
            $user = $this->input->post('username');
            $pass = $this->input->post('password');
            
            if($user && $pass){
                $pengguna = new Pengguna_Model();
                $pwd = $pengguna->baca_field('Password', array('Username'=>$user));
                $usr = $pengguna->baca_field('Username', array('Username'=>$user));
                $id = $pengguna->baca_field('ID', array('Username'=>$user));
                $nama_peng = $pengguna->baca_field('Nama', array('Username'=>$user));
                $pass = md5($pass);
                $temp = array();
                if ($user === $usr){
                    if ($pwd == $pass){
                        $stat = $pengguna->baca_field("Status", array("Username"=>$user));
                        if ($stat == "Aktif"){
                            $temp['success'] = true;
                            $temp['id'] = $id;
                            $temp['global'] = false;
                            $temp['turunan'] = false;
                            $peran = $pengguna->baca_field('ID_Role', array('Username'=>$user));
                            $temp['peran'] = $peran;
                            if ($this->is_admin_global($peran)){
                                //set session
                                $this->session->set_userdata(array('global'=>true));
                                $temp['global'] = true;
                                $this->hapus_exp_pemesanan();
                            }else if($this->is_admin_turunan($peran)){
                                $this->session->set_userdata(array('turunan'=>true));
                                $temp['turunan'] = true;
                                $this->hapus_exp_pemesanan();
                            }
                            $this->session->set_userdata(array('nama'=>$user));
                            $temp['nama_akun'] = $nama_peng;
                            //kembalikan data dalam encode json
                            echo json_encode($temp);
                        } else {
                            echo "{success: false, msg: 'Username Anda tidak aktif lagi<br>Silakan hubungi administrator'}";
                        }
                    } else {
                        echo "{success: false, msg: 'Password tidak cocok'}";
                    }
                } else {
                    echo "{success: false, msg: 'Username tidak valid'}";
                }
            }else echo "{success: false, msg: 'Password dan username harus diisi'}";
        }

        function logout(){
            if ($this->is_admin()){
                $this->session->unset_userdata('global');
                $this->session->unset_userdata('turunan');
            }
            $this->session->unset_userdata('nama');
        }

        function hapus(){
            if ($this->berhak("Delete User")){
                $username = $this->input->post('username');
                $peran = $this->get_peran($username);
                if ($this->is_admin_global($peran)){
                    echo "Admin global tidak bisa dihapus";
                } else if ($this->is_admin_turunan($peran)){
                    if ($this->is_global()){
                        $pm = new Pengguna_Model();
                        //$pm->rubah(array("Status"=>"Tidak Aktif"), array("Username"=>$username));
                        echo "Pengguna(Admin turunan) telah dihapus";
                    } else {
                        echo "Anda tidak berhak menghapus admin lain";
                    }
                } else {
                    $pm = new Pengguna_Model();
                    //$pm->rubah(array("Status"=>"Tidak Aktif"), array("Username"=>$username));
                    echo "Pengguna telah dihapus $peran;";
                    print_r($_POST);
                }
            } else echo "Anda tidak berhak untuk menghapus pengguna";
        }
		
	function is_admin_global($id){
            $pengguna = new Pengguna_Model();
            $adm = $pengguna->call_function('get_admin');
            $adm = $pengguna->ambil_field($adm, 'fn');
            if ($id == $adm){
                return true;
            } else return false;
	}

        function is_admin_turunan($id){
            $pengguna = new Pengguna_Model();
            $adm = $pengguna->call_function('is_admin_turunan', array($id));
            $adm = $pengguna->ambil_field($adm, 'fn');
            return ($adm == '1' ? TRUE : FALSE);
        }

        function get_peran($usr){
            $pm = new Pengguna_Model();
            $peran = $pm->baca_field("ID_role", array('Username'=>$usr));
            return $peran;
        }

        /**
         * Mengecek apakah pengguna telah mencapai jumlah buku yang dapat dipinjam.
         * @param mixed $id, id dari pengguna yang akan dicek.
         * @return boolean true, jika jumlah buku telah mencapai batas dan false lainnya.
         */
        function is_batas_buku($id){
            if(is_numeric($id)){
                $pengguna = new Pengguna_Model();
                $trans = new Pesan_Pinjam_Model();
                
                //ambil jumlah maksimal buku yang bisa dipinjam atau dipesan
                $batas = $pengguna->baca_field('Batas_Buku', array('ID'=>$id));
                $stok = $pengguna->call_function('ambil_jumlah', array((int)$id, 1));
                $stok = $pengguna->ambil_field($stok, 'fn');
                if ($batas > $stok){
                    echo 'TRUE';
                } else echo $batas;
            }
        }

        public function pesan_buku($stat=4){
            $temp = $this->info_pesan();
            $buku = new Buku_Model();
            $temp['stat'] = $stat;
            $buku->pesan_arr($temp);
        }

        public function pesan_kaset($stat=4){
            $temp = $this->info_pesan();
            $kaset = new Kaset_Model();
            $temp['stat'] = $stat;
            $kaset->pesan_arr($temp);
        }

        public function lihat_artikel(){
            $judul = trim($this->input->post('judul'));
            $art = new Artikel_Model();
            $art->call_procedure('naikan_jumlah_lihat', array($judul));
        }

        public function ambil_daftar_pinjam($id){
            $ppm = new Pesan_Pinjam_Model();
            $on = 't_d_peminjaman.ID_Trans_Peminjaman = t_t_pesan_pinjam.ID';
            $fields = array('t_d_peminjaman.Rencana_Kembali', 't_d_peminjaman.ID_D_Buku', 't_d_peminjaman.ID_D_Kaset', 't_d_peminjaman.Tgl_Pinjam');
            $where = array('t_d_peminjaman.Tgl_Kembali'=>NULL,
                't_t_pesan_pinjam.Jumlah_Barang'=>array('>', 0),
                't_t_pesan_pinjam.ID_Jenis'=>2, 't_t_pesan_pinjam.ID_Pengguna'=>$id);
            $hasil = $ppm->baca_komplit('t_d_peminjaman', $on, 'inner', $fields, $where);
            echo "<span style='font-weight:bold'>Jumlah Barang</span> : {$hasil->num_rows()}<br><hr>";
            if ($hasil->num_rows() > 0){
                echo "<table border='0' style='text-align: center; font-size: 8pt'; padding: '5 5 5 5'>";
                echo "<tr>";
                echo "<th>No</th><th>Batas Pengembalian</th><th>Kategori</th><th>ID Barang</th><th>Waktu Peminjaman</th>";
                echo "</tr>";
                $no = 1;
                foreach ($hasil->result_array() as $temp){
                    $tgl = $temp['Rencana_Kembali'];
                    $jenis = ($temp['ID_D_Buku'] == NULL ? 'Kaset' : 'Buku');
                    $id = ($temp['ID_D_Buku'] == NULL ? $temp['ID_D_Kaset'] : $temp['ID_D_Buku']);
                    echo "<tr><td>$no</td>";
                    echo "<td>$tgl</td>";
                    echo "<td>" . $jenis . '</td>';
                    echo "<td>" . $id . "</td>";
                    echo "<td>" . $temp['Tgl_Pinjam'] . "</td>";
                    echo "</tr>";
                    $no++;
                }
                echo "</table>";
            }
        }

        public function ambil_daftar_pesan($id, $stat){
            $ppm = new Pesan_Pinjam_Model();
            $on = 't_d_pemesanan.ID_Trans_Pemesanan = t_t_pesan_pinjam.ID';
            $fields = array('t_d_pemesanan.Tgl_Ganti_Status', 't_d_pemesanan.ID_M_Buku', 't_d_pemesanan.ID_M_Kaset');
            $krit = ($stat == 4 ? array('IN (', $stat . ", 5)") : $stat);
            $where = array('t_d_pemesanan.ID_Status'=>$krit,
                't_t_pesan_pinjam.Jumlah_Barang'=>array('>', 0),
                't_t_pesan_pinjam.ID_Jenis'=>1, 't_t_pesan_pinjam.ID_Pengguna'=>$id);
            $hasil = $ppm->baca_komplit('t_d_pemesanan', $on, 'inner', $fields, $where);
            $no = 1;
            echo "<span style='font-weight: bold; font-size: 9pt'>Jumlah Barang: " . $hasil->num_rows() . "</span><hr>";
            if($hasil->num_rows() > 0){
                echo "<table border='0' style='text-align: center; font-size: 8pt'; padding: '5 5 5 5'>";
                echo "<tr>";
                echo "<th>No</th><th>Waktu Pemesanan</th><th>Kategori</th><th>ID Barang</th><th>Action</th>";
                echo "</tr>";
                $path = base_url() . 'pengguna/batal_pinjam';
                foreach ($hasil->result_array() as $temp){
                    $tgl = $temp['Tgl_Ganti_Status'];
                    $jenis = ($temp['ID_M_Buku'] == NULL ? 'Kaset' : 'Buku');
                    $id_jenis = ($temp['ID_M_Buku'] == NULL ? 2 : 1);
                    $id = ($temp['ID_M_Buku'] == NULL ? $temp['ID_M_Kaset'] : $temp['ID_M_Buku']);
                    echo "<tr><td>$no</td>";
                    echo "<td>$tgl</td>";
                    echo "<td>" . $jenis . '</td>';
                    echo "<td>" . $id . "</td>";
                    echo "<td>" . "<a href=\"javascript: batal_pesan($id_jenis, $id);\">Batalkan</a>" . "</td>";
                    echo "</tr>";
                    $no++;
                }
            echo "</table>";
            }
        }

        public function batal_pesan(){
            $id_jen = (int)$this->input->post('id_jenis');
            $id = (int)$this->input->post('id');
            $pengguna = (int)$this->input->post('pengguna');
            $buku = new Buku_Model();
            $buku->call_procedure('batal_pesan', array($pengguna, $id_jen, $id));
        }

        public function ganti_pass(){
            $passLama = $this->input->post('passLama');
            $pass = $this->input->post('passBaru');
            $pengguna = $this->input->post('pengguna');
            
            if($this->is_password($passLama, $pengguna)){
                $pm = new Pengguna_Model();
                $pm->rubah(array('Password'=>md5($pass)), array('ID'=>$pengguna));
                echo "{success: true}";
            } else{
                echo "{success: false}";
            }
        }

        private function is_password($pass, $id){
            $pm = new Pengguna_Model();
            $passLm = $pm->baca_field('Password', array('ID'=>$id));
            if ($passLm === md5($pass)){
                return true;
            } else return false;
        }

        private function info_pesan(){
            $pemesan = $this->input->post('pemesan');
            $pesanan = $this->input->post('pesanan');
            $id = $this->input->post('id');
            $jumlah = $this->input->post('jumlah');
            return array('pemesan'=>$pemesan, 'pesanan'=>$pesanan, 'jenis'=>$id, 'jumlah'=>$jumlah);
        }

        function rubah(){
            $hasil = array('success'=>false, 'msg'=>'Anda tidak berhak untuk merubah data pengguna');
            if ($this->berhak("Update User")){
                $ni = $this->input->post('NI');
                $nama = $this->input->post('Nama');
                $email = $this->input->post('Email');
                $nohp = $this->input->post('No_HP');
                $alamat = $this->input->post('Alamat');
                $status = $this->input->post('Status');
                $batas = $this->input->post('Batas_Buku');
                $username = $this->input->post('Username');
                //$hasil['msg'] = $ni . $nama . $email . $nohp .$alamat . $status .$batas . $username .$this->session->userdata('nama');
                $pm = new Pengguna_Model();
                $rubah = false;
                if ($this->is_turunan()){
                    $peran = $this->get_peran($this->session->userdata('nama'));
                    if ($this->is_admin_turunan($peran)){
                        if ($username == $this->session->userdata('nama')){
                            $rubah = true;
                        } else {
                            $hasil['msg'] = 'Anda tidak dapat mengubah data admin lain';
                        }
                    } else if ($this->is_admin_global($peran)){
                        $hasil['success'] = true;
                        $hasil['msg'] = 'Anda tidak dapat mengubah data admin global';
                    } else {
                        $rubah = true;
                    }
                } else if ($this->is_global()){
                    $rubah = true;
                }

                if ($rubah){
                    $pm->rubah(array('NI'=>$ni, 'Nama'=>$nama, 'Alamat'=>$alamat, 'No_HP'=>$nohp, 'Status'=>$status, 'Email'=>$email, 'Batas_Buku'=>$batas), array('Username'=>$username));
                    $hasil['success'] = true;
                    $hasil['msg'] = 'Data telah berhasil dirubah';
                }
            }
            echo json_encode($hasil);
        }
        
	public function tambah_pengguna_biasa(){
            if ($this->berhak("Create User")){
            $nomor = $this->input->post('induk');
            $pengguna = $this->input->post('nama');
            $email = $this->input->post('email');
            $username = substr($email,0,strpos($email,'@'));
            $sandi = md5($username);
            $alamat = $this->input->post('alamat');
            $hp = $this->input->post('nohp');
            $jlhBuku = $this->input->post('jumlahbuku');
            $cek = (int) $jlhBuku;
            if($nomor && $pengguna && $email && $alamat && $hp) {
                if ((int) $nomor != 0){
                    $tambah = new Pengguna_Model();
                    $temp = $tambah->baca_detail('NI',array('NI'=>$nomor));
                    if ($temp->num_rows() == 0){
                        if ($username){
                            if($cek >= 1 && $cek <= 7){
                                $tambah->tambah(array('NI'=>$nomor,'Nama'=>$pengguna,'Alamat'=>$alamat,'No_HP'=>$hp,'Username'=>$username,'Password'=>$sandi,'Status'=>'Aktif','Email'=>$email,'ID_role'=>1,'Batas_Buku'=>(int)$jlhBuku));
                            } else echo "{success: false, msg : 'Batas Buku tidak valid', error :4}";
                        }else echo "{success: false, msg : 'Alamat Email tidak valid', error :3}";
                    } else echo "{success: false, msg : 'Pengguna dengan nim ".$nomor." telah terdaftar'".", error :2}";
                } else echo "{success : false, msg: 'Masukan untuk Nomor Induk harus Angka', error :1}";
            } else echo "{success: false, msg: 'Semua Field harus diisi', error :5}";
            } else {
                echo "{success: false, msg: 'Anda tidak memiliki hak untuk menambah pengguna baru'}";
            }
        }
        
        public function tampil() {
            $sort = array($this->input->post('sort'), $this->input->post('dir'));
            $mulai = (int)$this->input->post('start');
            $k = $this->input->post('kriteria');
            $v = $this->input->post('value');

            $user = new Pengguna_Model();
            $tmp_user = array();
            $tmp_user[ID_JUMLAH_USER] = $user->getJumlahTotal();
            $tmp_user[ID_AKAR_USER] = array();
            $tbl = 't_m_peran';
            $asl = $user->get_table_name();
            $on = "$tbl.ID = $asl.ID_role";
            $k = ($k == 'Nama' ? "$tbl.Nama" : $k);
            $fields = array('Username', 'Status', 'Email', 'Batas_Buku', "$tbl.Nama");
            if ($k && $v){
                //pengguna menggunakan fasilitas cari
                $data_user = $user->baca_join($tbl, $on, $fields, $sort, array($k=>array('LIKE', "'%$v%'")),$mulai, JUMLAH_USER_PER_GRID);
                $tmp_user[ID_JUMLAH_USER] = $user->ambil_total($data_user);
            } else {
                $data_user = $user->baca_join($tbl, $on, $fields, $sort, null, $mulai, JUMLAH_USER_PER_GRID);
            }
            $this->toArray($tmp_user[ID_AKAR_USER], $data_user);
            echo json_encode($tmp_user);
        }
        public function tampilAdmin() {
            //$user = array(ID_JUMLAH_USER=>5,ID_AKAR_USER=>array(array('ID Pengguna'=>'dummy','Nama'=>'dummy','Email'=>'dummy','Status'=>'aktif','Batas Buku'=>4)));
            $user = new Pengguna_Model();
            $tmp_user = array();
            $tmp_user[ID_JUMLAH_ADMIN] = $user->getJumlahTotal();
            $tmp_user[ID_AKAR_ADMIN] = array();
            $fields = array('ID', 'Username', 'Status', 'Email', 'Batas_Buku');
            $data_user = $user->baca_where($fields, array('ID_ROLE'=>array('<>',1)) , 0, JUMLAH_ADMIN_PER_GRID);
            $this->toArray($tmp_user[ID_AKAR_ADMIN], $data_user);
            echo json_encode($tmp_user);

        }
        
   private function toArray(&$tab, $hasil){
        foreach ($hasil->result_array() as $row){
            array_push($tab, $row);
        }
   }
   private function hapus_exp_pemesanan(){
       $qry = "UPDATE t_d_pemesanan
set ID_Status = get_batal()
where ID_Status IN(get_pesan_cepat(), get_setuju())
AND datediff(curdate(), date(Tgl_Ganti_Status)) > 0";
       App_Model::eksekusi($qry);
   }

   private function get_data($username){
       $pm = new Pengguna_Model();
       $tbl = 't_m_peran';
       $asl = $pm->get_table_name();
       $on = "$tbl.ID = $asl.ID_role";
       $fields = array("NI", "$asl.Nama", "Username", "$tbl.Nama as 'Peran'", "Keterangan", "Alamat", "No_HP", "Status", "Email", "Batas_Buku");
       $krit = array("Username"=>$username);
       $result = $pm->baca_join($tbl, $on, $fields, null, $krit);
       return $result;
   }
}
?>
