<?php

require_once (dirname(__FILE__).'\app_controller.php');
class History extends App_Controller{
    function History(){
        parent::App_Controller();
        $this->load->helper('url');
        $this->load->model('App_Model');
    }

    function index(){
        redirect(base_url());
    }

    //Menampilkan seluruh history peminjaman peminjaman dengan format json
    function history_peminjaman(){
        $params = $this->get_params();
        $params['k'] = ($params['k'] == 'Bahan' ? "IF (is_buku(ID_Referensi_Kategori), ID_D_Buku, ID_D_Kaset)" : $params['k']);
        //gunakan data fiktif untuk testing
        //$params = array('d'=>'ASC', 'k'=>'ID_Pengguna', 'v'=>'_', 'm'=>0, 's'=>'Bahan');
        $qry = "select tdp.ID, ID_Pengguna, NI, Nama, date(Tgl_Pinjam) as 'Tgl_Pinjam', date(Tgl_Kembali) as 'Tgl_Kembali', ID_Referensi_Kategori, Jenis_Kategori, IF (is_buku(ID_Referensi_Kategori), ID_D_Buku, ID_D_Kaset) as 'Bahan', IF(tdd.Besar_denda IS NULL, 0, tdd.Besar_denda) AS 'Denda'
from t_d_peminjaman as tdp
inner join t_t_pesan_pinjam as ttp
	on tdp.ID_Trans_Peminjaman = ttp.ID
inner join t_m_pengguna as tmp
	on tmp.ID = ttp.ID_Pengguna
left join t_d_denda as tdd
	on tdd.ID = tdp.ID
inner join t_r_kategori as trk
	on trk.ID = tdp.ID_Referensi_Kategori
where NOT tdp.Tgl_Kembali IS NULL";
        $where = '';
        $temp = array();
        $temp[ID_AKAR_PEMINJAMAN] = array();
        if ($params['k'] && $params['v']){
            //mulai proses pencarian
            $where = " AND {$params['k']} LIKE '%{$params['v']}%'";
            $qry .= $where;
        }
        //ambil jumlah total peminjaman yang memenuhi kriteria
        $hasil = App_Model::eksekusi($qry);
        $temp_jlh = $hasil['jumlah'];
        $temp[ID_JUMLAH_PEMINJAMAN] = $hasil['jumlah'];

        //ambil data yang akan ditampilkan
        $sorting = " ORDER BY {$params['s']} {$params['d']}";
        $limit = " LIMIT {$params['m']}, " . ($params['m'] + JUMLAH_PEMINJAMAN_PER_GRID);
        $qry .= $sorting . $limit;
        $hasil = App_Model::eksekusi($qry);
        //$hasil['data'][0]['NI'] .= $params['k']. $params['v'].$temp_jlh;
        $temp[ID_AKAR_PEMINJAMAN] = (count($hasil)>1 ? $hasil['data'] : array());
        echo json_encode($temp);
    }

    /**
     * Menampilkan detail dari history peminjaman dengan id $id
     * @param int $id id peminjaman yang akan ditampilkan detailnya
     */
    function get_detail_peminjaman($id){
        $qry = "SELECT tmp.NI, tmp.Nama, tmr.Nama AS 'Peran', ID_Referensi_Kategori, Jenis_Kategori, IF(is_buku(tdp.ID_Referensi_Kategori), tdp.ID_D_Buku, tdp.ID_D_Kaset) AS 'ID_Barang', tdp.Tgl_Pinjam, tdp.Tgl_Kembali, IF(tdd.Besar_denda IS NULL, 0, tdd.Besar_denda) AS 'Denda' FROM t_d_peminjaman AS tdp INNER JOIN t_t_pesan_pinjam AS ttp ON tdp.ID_Trans_Peminjaman= ttp.ID INNER JOIN t_m_pengguna AS tmp ON tmp.ID = ttp.ID_Pengguna INNER JOIN t_m_peran AS tmr ON tmr.ID = tmp.ID_role LEFT JOIN t_r_kategori AS trk ON trk.ID = tmp.ID_role LEFT JOIN t_d_denda AS tdd ON tdd.ID_Detail_Peminjaman = tdp.ID WHERE tdp.ID = $id";
        $hasil = App_Model::eksekusi($qry);
        if ($hasil['jumlah'] > 0){
            $hasil = $hasil['data'][0];
            echo "<span style='font-weight: bold;font-size: 10pt'>Nomor Induk Peminjam : </span><br>" ."<span style='font-size: 10pt'>".$hasil['NI']."</span><br><br>";
            echo "<span style='font-weight: bold'>Nama Peminjam : </span><br>" .$hasil['Nama']."<br><br>";
            echo "<span style='font-weight: bold'>Peran Peminjam : </span><br>" .$hasil['Peran']."<br><br>";
            echo "<span style='font-weight: bold'>Kategori Pinjaman : </span><br>" .($hasil['ID_Referensi_Kategori'] == 1 ? "Buku" : "CD/DVD")."<br><br>";
            echo "<span style='font-weight: bold'>ID Pinjaman : </span><br>".$hasil['ID_Barang']."<br><br>";
            echo "<span style='font-weight: bold'>Tanggal Peminjaman : </span><br>".$hasil['Tgl_Pinjam']."<br><br>";
            echo "<span style='font-weight: bold'>Tanggal Pengembalian : </span><br>" .$hasil['Tgl_Kembali']."<br><br>";
            echo "<span style='font-weight: bold'>Besar Denda : </span><br>" ."Rp ".$hasil['Denda'] . ",00";
        }
        //echo json_encode($hasil);
    }
}
?>
