<?php
require_once (dirname(__FILE__).'/app_controller.php');
	class Lib extends App_Controller{
		function Lib(){
			parent::App_Controller();
                        $this->load->library('session');
                        $this->load->helper('url');
		}

                //Fungsi yang dipanggil ketika pengguna mengakses halaman administrator
                //Mengecek session admin, jika telah terbentuk maka akan menampilkan halaman admin jika tidak maka redirect ke halamaan depan
		function admin(){
                    if ($this->session->userdata('global') == true || $this->session->userdata('turunan') == true){
                        $this->load->view('admin');
                    } else $this->index();
		}
                
		function index(){
                    $path = base_url();
                    redirect($path);
                }
                function about(){
                    $this->load->view('about');
                }
                function tambah_admin(){
                    $hasil = array('success'=>false, 'msg'=>'Anda tidak berhak menambah admin baru');
                    if ($this->is_global()){
                        
                    }
                    echo json_encode($hasil);
                }
	}
?>