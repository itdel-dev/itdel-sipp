<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ', 							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 					'ab');
define('FOPEN_READ_WRITE_CREATE', 				'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 			'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

/*
 * Dibuat oleh: Roy Inganta Ginting
 * Sejarah Modifikasi:
 *  - Rabu, 11 Mei 2011 20:20
 *  - Sabtu 04 Juni 2011 18:24
|------------------------------------------------------------------
| Mode Ext JS
|------------------------------------------------------------------
|Konstanta ini digunakan ketika berurusan dengan framework Ext JS.
*/
define ('ROOT', 'http://172.22.2.249/sipp/');
define ('EXT_ROOT', ROOT.'ext-3.3.1/');
define ('EXT3_CSS', EXT_ROOT.'resources/css/ext-all.css'); //src value untuk file css yang dibutuhkan Ext JS
define ('EXT3_ADAPTER', EXT_ROOT.'adapter/ext/ext-base.js'); //adapter untuk Ext JS
define ('EXT3_ALL', EXT_ROOT.'ext-all.js'); //core untuk Ext JS
define ('EXT3_CUSTOM', EXT_ROOT.'custom/'); //Path menuju folder custom (folder dimana seluruh file javascript diletakan)

/*
|------------------------------------------------------------------
| Mode Ext JS
|------------------------------------------------------------------
|Konstanta ini digunakan ketika berurusan dengan CSS.
*/
define ('CSS', ROOT. '/css/'); //src value untuk file CSS yang dibutuhkan file HTML


/**
 * Dibuat oleh: Roy Inganta Ginting
 * Dibuat tanggal: Rabu 11 Mei 2011 20:30
 * Sejarah Modifikasi
 |------------------------------------------------------------------------------
 | Mode Buku
 |------------------------------------------------------------------------------
 | Berisi konstanta yang berhubungan dengan pengolahan buku pada framework Ext JS.
 |
 */
define ('JUMLAH_BUKU_PER_GRID', 25); //Jumlah record yang akan ditampilkan pada GridPanel buku ataupun GridPanel kaset
define ('ID_JUMLAH_BUKU', 'jumlahBuku'); //id penanda dari jumlh buku
define ('ID_AKAR_BUKU', 'buku'); //id elemen root untuk buku


/**
 * Dibuat oleh : Roy Inganta Ginting
 * Dibuat tanggal: Sabtu 04 Juni 2011 18:20
 * Konstanta untuk menangani transfer data kaset antar client dengan server
 */
define('JUMLAH_KASET_PER_GRID', 25); //Jumlah kaset yang akan ditampung oleh setiap tampilan grid
define('ID_JUMLAH_KASET', 'jumlahKaset'); //ID untuk menyatakan jumlah kaset
define('ID_AKAR_KASET', 'kaset'); //ID element root untuk kaset


/**
 * Dibuat oleh : Roy Inganta Ginting
 * Dibuat tanggal: Rabu 15 Juni 2011 18:48
 * Konstanta untuk menangani transfer data history peminjaman
 */
define('JUMLAH_PEMINJAMAN_PER_GRID', 25); //Jumlah kaset yang akan ditampung oleh setiap tampilan grid
define('ID_JUMLAH_PEMINJAMAN', 'jumlahPeminjaman'); //ID untuk menyatakan jumlah kaset
define('ID_AKAR_PEMINJAMAN', 'peminjaman'); //ID element root untuk kaset

/**
 * Dibuat oleh : Fred Dryer R H Nainggolan
 * Dibuat tanggal: Sabtu 10 Juni 2011 08:53
 * Konstanta untuk menangani transfer data User antar client dengan server
 */

define('JUMLAH_USER_PER_GRID', 25); //Jumlah user yang akan ditampung oleh setiap tampilan grid
define('ID_JUMLAH_USER', 'jumlahUser'); //ID untuk menyatakan jumlah user
define('ID_AKAR_USER', 'user'); //ID element root untuk user

/**
 * Dibuat oleh : Fred Dryer R H Nainggolan
 * Dibuat tanggal: Sabtu 10 Juni 2011 10:45
 * Konstanta untuk menangani transfer data User antar client dengan server
 */

define('JUMLAH_ADMIN_PER_GRID', 25); //Jumlah user yang akan ditampung oleh setiap tampilan grid
define('ID_JUMLAH_ADMIN', 'jumlahAdmin'); //ID untuk menyatakan jumlah user
define('ID_AKAR_ADMIN', 'admin'); //ID element root untuk user

/**
 * Konstanta tambahan
 * Dibuat oleh: Roy Inganta Ginting
 * Dibuat tanggal: 10 Juni 2011 16:00
 * Edit:
 *	1. 22 juni 2011 9:04
 */
define ('PATH_GAMBAR_BUKU', ROOT.'images/buku/');
define ('PATH_GAMBAR_CD_DVD', ROOT.'images/cd_dvd/');
define ('DURASI_BUKU_BARU', 7);

/* End of file constants.php */
/* Location: ./system/application/config/constants.php */